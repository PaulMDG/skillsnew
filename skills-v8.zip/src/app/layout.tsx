import type { Metadata, Viewport } from "next";
import "./globals.css";
import { site } from "@/lib/site";

export const metadata: Metadata = {
  metadataBase: new URL(site.url),
  title: { default: `${site.name} | Professional training courses in Africa`, template: `%s | ${site.name}` },
  description: "Instructor-led professional training in project management, M&E, finance, data, leadership and more. New start dates every week, classroom and online.",
  openGraph: { type: "website", siteName: site.name, locale: site.locale },
  alternates: { canonical: "/" },
  robots: { index: true, follow: true },
};

export const viewport: Viewport = { themeColor: "#0b835c", width: "device-width", initialScale: 1 };

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en">
      <body>{children}</body>
    </html>
  );
}
