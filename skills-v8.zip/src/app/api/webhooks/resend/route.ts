import { NextResponse } from "next/server";
import type { EmailEventType } from "@prisma/client";
import { getEmailStore } from "@/lib/email/store";
import { verifySvix } from "@/lib/email/svix";

export const dynamic = "force-dynamic";

const TYPES: Record<string, EmailEventType> = {
  "email.sent": "SENT", "email.delivered": "DELIVERED", "email.delivery_delayed": "DELAYED",
  "email.bounced": "BOUNCED", "email.complained": "COMPLAINED", "email.opened": "OPENED", "email.clicked": "CLICKED",
};

interface ResendEvent { type?: string; created_at?: string; data?: { email_id?: string; bounce?: { type?: string }; [k: string]: unknown } }

/** Resend → us: delivery, bounce, complaint, open and click events (Svix-signed). */
export async function POST(req: Request) {
  const body = await req.text(); // raw body: the signature is computed over the exact bytes
  const ok = verifySvix({
    secret: process.env.RESEND_WEBHOOK_SECRET ?? "",
    id: req.headers.get("svix-id"), timestamp: req.headers.get("svix-timestamp"), signature: req.headers.get("svix-signature"), body,
  });
  if (!ok) return NextResponse.json({ error: "Invalid signature" }, { status: 401 });

  let evt: ResendEvent;
  try { evt = JSON.parse(body); } catch { return NextResponse.json({ error: "Bad JSON" }, { status: 400 }); }
  const type = evt.type ? TYPES[evt.type] : undefined;
  const messageId = evt.data?.email_id;
  if (!type || !messageId) return NextResponse.json({ ignored: true }); // event types we don't track: acknowledge so Resend stops retrying

  const result = await (await getEmailStore()).applyEvent({
    providerEventId: req.headers.get("svix-id")!, providerMessageId: messageId, type,
    occurredAt: evt.created_at ? new Date(evt.created_at) : new Date(),
    bounceType: evt.data?.bounce?.type ?? null, payload: { type: evt.type, bounce: evt.data?.bounce },
  });
  return NextResponse.json({ result });
}
