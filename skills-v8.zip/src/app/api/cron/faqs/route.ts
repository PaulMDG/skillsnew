import { NextResponse } from "next/server";
import { timingSafeEqual } from "node:crypto";
import { openAiConfigured } from "@/lib/faq/openai";
import { faqService } from "@/lib/faq/service";

export const dynamic = "force-dynamic";
export const maxDuration = 60;

function authorised(req: Request): boolean {
  const secret = process.env.CRON_SECRET;
  if (!secret) return false;
  const given = req.headers.get("authorization") ?? "", expected = `Bearer ${secret}`;
  return given.length === expected.length && timingSafeEqual(Buffer.from(given), Buffer.from(expected));
}

/** Daily: write FAQ drafts for new courses and for courses whose text changed. Spend is capped by FAQ_MAX_PER_RUN. */
export async function GET(req: Request) {
  if (!authorised(req)) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  if (!openAiConfigured()) return NextResponse.json({ skipped: "OPENAI_API_KEY not set" });
  return NextResponse.json(await (await faqService()).runBatch({ limit: Number(process.env.FAQ_MAX_PER_RUN ?? 5), budgetMs: 50_000 }));
}
