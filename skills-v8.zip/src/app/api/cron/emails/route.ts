import { NextResponse } from "next/server";
import { timingSafeEqual } from "node:crypto";
import { emailService } from "@/lib/email/service";

export const dynamic = "force-dynamic";
export const maxDuration = 60;

function authorised(req: Request): boolean {
  const secret = process.env.CRON_SECRET;
  if (!secret) return false;
  const given = req.headers.get("authorization") ?? "", expected = `Bearer ${secret}`;
  return given.length === expected.length && timingSafeEqual(Buffer.from(given), Buffer.from(expected));
}

/** Hourly: release due follow-ups (business hours only) and retry any queued/failed email. */
export async function GET(req: Request) {
  if (!authorised(req)) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  const svc = await emailService();
  const followUps = await svc.runFollowUps();
  const delivery = await svc.deliverQueued();
  return NextResponse.json({ followUps, delivery });
}
