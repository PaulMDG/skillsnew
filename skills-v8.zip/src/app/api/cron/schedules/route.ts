import { NextResponse } from "next/server";
import { timingSafeEqual } from "node:crypto";
import { prisma } from "@/lib/db";
import { rollAllSchedules } from "@/lib/schedules/engine";

export const dynamic = "force-dynamic";
export const maxDuration = 60;

function authorised(req: Request): boolean {
  const secret = process.env.CRON_SECRET;
  if (!secret) return false;
  const given = req.headers.get("authorization") ?? "";
  const expected = `Bearer ${secret}`;
  return given.length === expected.length && timingSafeEqual(Buffer.from(given), Buffer.from(expected));
}

// Vercel Cron: { "path": "/api/cron/schedules", "schedule": "0 21 * * *" }  (00:00 Nairobi)
export async function GET(req: Request) {
  if (!authorised(req)) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  const result = await rollAllSchedules(prisma);
  return NextResponse.json(result, { status: result.failures.length ? 207 : 200 });
}
