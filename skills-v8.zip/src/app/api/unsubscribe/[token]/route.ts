import { NextResponse } from "next/server";
import { getEmailStore } from "@/lib/email/store";

export const dynamic = "force-dynamic";

/** RFC 8058 one-click unsubscribe: mail apps POST here directly (no confirmation page). */
export async function POST(_: Request, { params }: { params: Promise<{ token: string }> }) {
  const { token } = await params;
  await (await getEmailStore()).unsubscribeByToken(token);
  return new NextResponse(null, { status: 200 }); // same answer for unknown tokens: no information leak
}
