import Link from "next/link";
import { Search, CalendarCheck, Award, Users2, Globe2, ArrowRight } from "lucide-react";
import { getRepo } from "@/lib/repo";
import { CourseCardView } from "@/components/course-card";
import { CategoryIcon } from "@/components/category-icon";
import { PostCardView } from "@/components/blog/post-card";
import { formatRange, lengthLabel, priceText } from "@/lib/format";

export const revalidate = 3600;

export default async function HomePage() {
  const repo = await getRepo();
  const [{ categories, featured, upcoming, totals }, { posts }] = await Promise.all([repo.getHomeData(), repo.listPosts({ page: 1, pageSize: 3 })]);

  return (
    <>
      <section className="relative overflow-hidden bg-brand-900 text-white">
        <div className="absolute inset-0 opacity-30" style={{ backgroundImage: "radial-gradient(circle at 20% 20%, #12a273 0, transparent 45%), radial-gradient(circle at 85% 70%, #f7b733 0, transparent 35%)" }} />
        <div className="relative mx-auto max-w-7xl px-4 py-20 sm:px-6 md:py-28">
          <p className="mb-4 inline-block rounded-full bg-white/10 px-3.5 py-1 text-xs font-semibold tracking-wide text-accent-400">NEW START DATES EVERY WEEK</p>
          <h1 className="max-w-3xl text-4xl font-extrabold leading-[1.1] tracking-tight sm:text-5xl md:text-6xl">Practical training that moves your career and organisation forward</h1>
          <p className="mt-5 max-w-2xl text-lg text-brand-100">{totals.courses}+ instructor-led courses across {totals.categories} fields. Join in the classroom at {totals.centers} centres or live online.</p>
          <form action="/courses" role="search" className="mt-8 flex max-w-2xl gap-2 rounded-2xl bg-white p-2 shadow-2xl">
            <label htmlFor="q" className="sr-only">Search courses</label>
            <div className="relative flex-1">
              <Search className="absolute left-3.5 top-1/2 h-5 w-5 -translate-y-1/2 text-muted" aria-hidden="true" />
              <input id="q" name="q" placeholder="Search e.g. project management, Excel, M&E…" className="w-full rounded-xl py-3.5 pl-11 pr-3 text-ink placeholder:text-muted/70 focus:outline-none" />
            </div>
            <button className="rounded-xl bg-accent-500 px-6 font-semibold text-brand-900 transition hover:bg-accent-400">Search</button>
          </form>
        </div>
      </section>

      <section className="border-b border-line bg-surface">
        <div className="mx-auto grid max-w-7xl gap-6 px-4 py-8 sm:grid-cols-2 sm:px-6 lg:grid-cols-4">
          {[
            [CalendarCheck, "52 start dates a year", "A new Monday start every week"],
            [Award, "Certificate of completion", "Recognised by employers"],
            [Users2, "Expert trainers", "Practitioners, not just academics"],
            [Globe2, "Classroom or online", `${totals.centers} centres + live virtual`],
          ].map(([Icon, t, d]) => {
            const I = Icon as typeof Award;
            return (
              <div key={t as string} className="flex items-start gap-3">
                <span className="grid h-10 w-10 shrink-0 place-items-center rounded-xl bg-white text-brand-700 shadow-sm"><I className="h-5 w-5" aria-hidden="true" /></span>
                <div><div className="text-sm font-semibold">{t as string}</div><div className="text-sm text-muted">{d as string}</div></div>
              </div>
            );
          })}
        </div>
      </section>

      <section id="categories" className="mx-auto max-w-7xl scroll-mt-20 px-4 py-16 sm:px-6">
        <div className="mb-8 flex items-end justify-between gap-4">
          <div><h2 className="text-3xl font-bold tracking-tight">Browse by category</h2><p className="mt-2 text-muted">Find the right programme for your field.</p></div>
          <Link href="/courses" className="hidden items-center gap-1 text-sm font-semibold text-brand-700 hover:underline sm:flex">All courses <ArrowRight className="h-4 w-4" /></Link>
        </div>
        <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
          {categories.map((c) => (
            <Link key={c.id} href={`/categories/${c.slug}`} className="group flex items-start gap-4 rounded-2xl border border-line p-5 transition hover:border-brand-200 hover:bg-brand-50/50 hover:shadow-md">
              <span className="grid h-12 w-12 shrink-0 place-items-center rounded-xl bg-brand-50 text-brand-700 transition group-hover:bg-brand-600 group-hover:text-white"><CategoryIcon name={c.iconKey} className="h-6 w-6" /></span>
              <div>
                <h3 className="font-semibold group-hover:text-brand-700">{c.name}</h3>
                <p className="mt-1 line-clamp-2 text-sm text-muted">{c.description}</p>
                <p className="mt-2 text-xs font-semibold text-brand-700">{c.courseCount} courses</p>
              </div>
            </Link>
          ))}
        </div>
      </section>

      <section className="bg-surface py-16">
        <div className="mx-auto max-w-7xl px-4 sm:px-6">
          <h2 className="text-3xl font-bold tracking-tight">Popular courses</h2>
          <p className="mt-2 text-muted">Most booked by professionals like you.</p>
          <div className="mt-8 grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
            {featured.map((c, i) => <CourseCardView key={c.id} course={c} priority={i < 3} />)}
          </div>
        </div>
      </section>

      <section id="upcoming" className="mx-auto max-w-7xl scroll-mt-20 px-4 py-16 sm:px-6">
        <h2 className="text-3xl font-bold tracking-tight">Starting soon</h2>
        <p className="mt-2 text-muted">Seats are limited. All courses run Monday to Friday.</p>
        <div className="mt-8 overflow-x-auto rounded-2xl border border-line">
          <table className="w-full min-w-[640px] text-left text-sm">
            <thead className="bg-surface text-xs uppercase tracking-wide text-muted">
              <tr><th className="px-5 py-3">Course</th><th className="px-5 py-3">Dates</th><th className="px-5 py-3">Length</th><th className="px-5 py-3">Fee</th><th className="px-5 py-3"><span className="sr-only">Action</span></th></tr>
            </thead>
            <tbody className="divide-y divide-line">
              {upcoming.map((u) => (
                <tr key={u.scheduleId} className="hover:bg-brand-50/40">
                  <td className="px-5 py-4 font-semibold"><Link href={`/courses/${u.courseSlug}`} className="hover:text-brand-700">{u.courseName}</Link></td>
                  <td className="px-5 py-4 text-muted">{formatRange(u.startDate, u.endDate)}</td>
                  <td className="px-5 py-4 text-muted">{lengthLabel[u.length]}</td>
                  <td className="px-5 py-4">{priceText(u.price)}</td>
                  <td className="px-5 py-4 text-right"><Link href={`/register?course=${u.courseSlug}&schedule=${encodeURIComponent(u.scheduleId)}`} className="rounded-lg bg-brand-600 px-3.5 py-2 text-xs font-semibold text-white hover:bg-brand-700">Register</Link></td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </section>

      {posts.length > 0 && (
        <section aria-labelledby="insights" className="mx-auto max-w-7xl px-4 pb-16 sm:px-6">
          <div className="flex items-end justify-between gap-4"><h2 id="insights" className="text-3xl font-bold tracking-tight">Latest insights</h2><Link href="/blog" className="text-sm font-semibold text-brand-700 hover:underline">All articles →</Link></div>
          <div className="mt-8 grid gap-6 sm:grid-cols-2 lg:grid-cols-3">{posts.map((p) => <PostCardView key={p.slug} post={p} />)}</div>
        </section>
      )}

      <section className="mx-auto max-w-7xl px-4 sm:px-6">
        <div className="rounded-3xl bg-gradient-to-r from-brand-700 to-brand-900 px-6 py-12 text-center text-white sm:px-12">
          <h2 className="text-3xl font-bold">Training a whole team?</h2>
          <p className="mx-auto mt-3 max-w-xl text-brand-100">We design and deliver tailor-made in-house programmes at your premises or online, with group rates available.</p>
          <Link href="/contact" className="mt-6 inline-block rounded-xl bg-accent-500 px-6 py-3 font-semibold text-brand-900 hover:bg-accent-400">Request a quote</Link>
        </div>
      </section>
    </>
  );
}
