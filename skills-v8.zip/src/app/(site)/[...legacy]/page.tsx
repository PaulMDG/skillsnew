import { notFound, permanentRedirect } from "next/navigation";
import { getRepo } from "@/lib/repo";

export const dynamic = "force-dynamic";

// Tiny cache so crawlers hammering random old URLs don't each cost a database query.
const cache = new Map<string, { to: string | null; at: number }>();
const TTL = 60_000;

/**
 * Catch-all for URLs no other page handles: if the old website had that address, send visitors and
 * search engines to the new page with a permanent redirect (keeps rankings); otherwise show the 404 page.
 */
export default async function Legacy({ params }: { params: Promise<{ legacy: string[] }> }) {
  const path = `/${(await params).legacy.map(decodeURIComponent).join("/")}`;
  const hit = cache.get(path);
  let to: string | null;
  if (hit && Date.now() - hit.at < TTL) to = hit.to;
  else {
    to = await (await getRepo()).findRedirect(path);
    if (cache.size > 2000) cache.clear();
    cache.set(path, { to, at: Date.now() });
  }
  if (to && to !== path && to.startsWith("/")) permanentRedirect(to);
  notFound();
}
