import type { Metadata } from "next";
import Link from "next/link";
import { notFound } from "next/navigation";
import { getRepo } from "@/lib/repo";
import { CourseCardView } from "@/components/course-card";
import { JsonLd } from "@/components/json-ld";
import { abs } from "@/lib/site";

export const revalidate = 3600;
type Props = { params: Promise<{ slug: string }> };

export async function generateStaticParams() {
  try {
    return (await (await getRepo()).listCategories()).map((x) => ({ slug: x.slug }));
  } catch {
    return []; // DB not reachable at build time: pages are generated on first request instead
  }
}

export async function generateMetadata({ params }: Props): Promise<Metadata> {
  const cat = await (await getRepo()).getCategory((await params).slug);
  if (!cat) return {};
  return {
    title: `${cat.name} training courses`,
    description: cat.description ?? `Professional ${cat.name} training courses with weekly start dates.`,
    alternates: { canonical: `/categories/${cat.slug}` },
  };
}

export default async function CategoryPage({ params }: Props) {
  const { slug } = await params;
  const repo = await getRepo();
  const cat = await repo.getCategory(slug);
  if (!cat) notFound();
  const courses = await repo.listCourses({ categorySlug: slug });

  return (
    <div className="mx-auto max-w-7xl px-4 py-10 sm:px-6">
      <JsonLd data={[
        { "@context": "https://schema.org", "@type": "BreadcrumbList", itemListElement: [
          { "@type": "ListItem", position: 1, name: "Home", item: abs("/") },
          { "@type": "ListItem", position: 2, name: "Courses", item: abs("/courses") },
          { "@type": "ListItem", position: 3, name: cat.name, item: abs(`/categories/${cat.slug}`) },
        ] },
        { "@context": "https://schema.org", "@type": "ItemList", itemListElement: courses.map((c, i) => ({ "@type": "ListItem", position: i + 1, url: abs(`/courses/${c.slug}`), name: c.name })) },
      ]} />
      <nav aria-label="Breadcrumb" className="text-sm text-muted"><Link href="/courses" className="hover:underline">Courses</Link> / <span className="text-ink">{cat.name}</span></nav>
      <h1 className="mt-3 text-4xl font-bold tracking-tight">{cat.name} training courses</h1>
      {cat.description && <p className="mt-3 max-w-2xl text-lg text-muted">{cat.description}</p>}
      <div className="mt-8 grid gap-6 sm:grid-cols-2 lg:grid-cols-3">{courses.map((c, i) => <CourseCardView key={c.id} course={c} priority={i < 3} />)}</div>
    </div>
  );
}
