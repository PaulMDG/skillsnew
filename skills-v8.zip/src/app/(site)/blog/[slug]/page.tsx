import type { Metadata } from "next";
import { notFound } from "next/navigation";
import { PostArticle } from "@/components/blog/post-article";
import { JsonLd } from "@/components/json-ld";
import { plainText } from "@/lib/blog/render";
import { getRepo } from "@/lib/repo";
import { abs, site } from "@/lib/site";

export const revalidate = 3600;
type Props = { params: Promise<{ slug: string }> };

export async function generateStaticParams() {
  try { return (await (await getRepo()).listPostSlugs()).map((p) => ({ slug: p.slug })); } catch { return []; }
}

export async function generateMetadata({ params }: Props): Promise<Metadata> {
  const post = await (await getRepo()).getPost((await params).slug);
  if (!post) return {};
  const title = post.metaTitle || post.title, description = post.metaDescription || post.excerpt;
  return {
    title, description, alternates: { canonical: `/blog/${post.slug}` },
    openGraph: { type: "article", title, description, url: abs(`/blog/${post.slug}`), publishedTime: post.publishedAt, modifiedTime: post.updatedAt, tags: post.tags, images: post.coverUrl ? [post.coverUrl] : undefined },
    twitter: { card: post.coverUrl ? "summary_large_image" : "summary", title, description },
  };
}

export default async function PostPage({ params }: Props) {
  const post = await (await getRepo()).getPost((await params).slug);
  if (!post) notFound();
  const url = abs(`/blog/${post.slug}`);
  return (
    <>
      <JsonLd data={[
        {
          "@context": "https://schema.org", "@type": "BlogPosting", headline: post.title, description: post.metaDescription || post.excerpt, url, mainEntityOfPage: url,
          datePublished: post.publishedAt, dateModified: post.updatedAt, image: post.coverUrl ? [post.coverUrl] : undefined, keywords: post.tags.join(", ") || undefined,
          wordCount: plainText(post.body, post.format).split(/\s+/).filter(Boolean).length, inLanguage: "en",
          author: post.author === site.name ? { "@type": "Organization", name: site.name, url: site.url } : { "@type": "Person", name: post.author },
          publisher: { "@type": "Organization", name: site.name, url: site.url },
        },
        { "@context": "https://schema.org", "@type": "BreadcrumbList", itemListElement: [
          { "@type": "ListItem", position: 1, name: "Home", item: abs("/") }, { "@type": "ListItem", position: 2, name: "Insights", item: abs("/blog") }, { "@type": "ListItem", position: 3, name: post.title, item: url } ] },
      ]} />
      <PostArticle post={post} />
    </>
  );
}
