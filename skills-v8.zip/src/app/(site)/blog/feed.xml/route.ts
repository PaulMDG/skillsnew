import { buildFeed } from "@/lib/blog/feed";
import { getRepo } from "@/lib/repo";

export const revalidate = 3600;

export async function GET() {
  const { posts } = await (await getRepo()).listPosts({ page: 1, pageSize: 20 });
  return new Response(buildFeed(posts), { headers: { "Content-Type": "application/rss+xml; charset=utf-8", "Cache-Control": "public, s-maxage=3600, stale-while-revalidate=86400" } });
}
