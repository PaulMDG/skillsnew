import type { Metadata } from "next";
import Link from "next/link";
import { notFound } from "next/navigation";
import { PostCardView } from "@/components/blog/post-card";
import { Pagination } from "@/components/pagination";
import { getRepo } from "@/lib/repo";

const PAGE_SIZE = 9;
type Props = { params: Promise<{ tag: string }>; searchParams: Promise<{ page?: string }> };
const label = (t: string) => t.replace(/-/g, " ");

export async function generateMetadata({ params }: Props): Promise<Metadata> {
  const tag = (await params).tag;
  return { title: `${label(tag)} articles`, description: `Articles and practical guides about ${label(tag)} from the Skills for Africa training team.`, alternates: { canonical: `/blog/tag/${tag}` } };
}

export default async function TagPage({ params, searchParams }: Props) {
  const tag = decodeURIComponent((await params).tag);
  const page = Math.max(1, Math.min(500, Number((await searchParams).page) || 1));
  const { posts, total } = await (await getRepo()).listPosts({ page, pageSize: PAGE_SIZE, tag });
  if (!total) notFound();
  return (
    <div className="mx-auto max-w-7xl px-4 py-10 sm:px-6">
      <nav aria-label="Breadcrumb" className="text-sm text-muted"><Link href="/blog" className="hover:underline">Insights</Link> / <span className="text-ink">{label(tag)}</span></nav>
      <h1 className="mt-3 text-4xl font-bold capitalize tracking-tight">{label(tag)}</h1>
      <p className="mt-2 text-muted">{total} article{total === 1 ? "" : "s"}</p>
      <div className="mt-8 grid gap-6 sm:grid-cols-2 lg:grid-cols-3">{posts.map((p) => <PostCardView key={p.slug} post={p} />)}</div>
      <Pagination basePath={`/blog/tag/${tag}`} page={page} totalPages={Math.ceil(total / PAGE_SIZE)} />
    </div>
  );
}
