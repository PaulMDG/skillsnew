import type { Metadata } from "next";
import Link from "next/link";
import { PostCardView } from "@/components/blog/post-card";
import { Pagination } from "@/components/pagination";
import { JsonLd } from "@/components/json-ld";
import { getRepo } from "@/lib/repo";
import { abs, site } from "@/lib/site";

const PAGE_SIZE = 9;

export async function generateMetadata({ searchParams }: { searchParams: Promise<{ page?: string }> }): Promise<Metadata> {
  const page = Math.max(1, Number((await searchParams).page) || 1);
  return {
    title: page > 1 ? `Insights: page ${page}` : "Insights: training articles and practical guides",
    description: "Practical articles on project management, monitoring and evaluation, finance, data, leadership and more from the Skills for Africa training team.",
    alternates: { canonical: page > 1 ? `/blog?page=${page}` : "/blog", types: { "application/rss+xml": "/blog/feed.xml" } },
  };
}

export default async function BlogIndex({ searchParams }: { searchParams: Promise<{ page?: string }> }) {
  const page = Math.max(1, Math.min(500, Number((await searchParams).page) || 1));
  const repo = await getRepo();
  const [{ posts, total }, tags] = await Promise.all([repo.listPosts({ page, pageSize: PAGE_SIZE }), repo.listPostTags()]);
  const pages = Math.max(1, Math.ceil(total / PAGE_SIZE));

  return (
    <div className="mx-auto max-w-7xl px-4 py-10 sm:px-6">
      <JsonLd data={[
        { "@context": "https://schema.org", "@type": "Blog", name: `${site.name} Insights`, url: abs("/blog"), publisher: { "@type": "Organization", name: site.name, url: site.url },
          blogPost: posts.map((p) => ({ "@type": "BlogPosting", headline: p.title, url: abs(`/blog/${p.slug}`), datePublished: p.publishedAt })) },
        { "@context": "https://schema.org", "@type": "BreadcrumbList", itemListElement: [{ "@type": "ListItem", position: 1, name: "Home", item: abs("/") }, { "@type": "ListItem", position: 2, name: "Insights", item: abs("/blog") }] },
      ]} />
      <h1 className="text-4xl font-bold tracking-tight">Insights</h1>
      <p className="mt-2 max-w-2xl text-lg text-muted">Practical guides from our trainers on the skills that move organisations forward. <Link href="/blog/feed.xml" className="font-semibold text-brand-700 hover:underline">RSS feed</Link></p>
      {tags.length > 0 && <div className="mt-6 flex flex-wrap gap-2" aria-label="Topics">{tags.slice(0, 14).map((t) => <Link key={t.tag} href={`/blog/tag/${t.tag}`} className="rounded-full border border-line px-3.5 py-1.5 text-sm font-medium text-muted transition hover:border-brand-500 hover:text-brand-700">{t.tag.replace(/-/g, " ")} <span className="text-xs">({t.count})</span></Link>)}</div>}
      {posts.length ? <div className="mt-8 grid gap-6 sm:grid-cols-2 lg:grid-cols-3">{posts.map((p) => <PostCardView key={p.slug} post={p} />)}</div>
        : <p className="mt-10 rounded-2xl border border-dashed border-line p-10 text-center text-muted">No articles yet. Please check back soon.</p>}
      <Pagination basePath="/blog" page={page} totalPages={pages} />
    </div>
  );
}
