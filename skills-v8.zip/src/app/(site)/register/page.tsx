import type { Metadata } from "next";
import Link from "next/link";
import { notFound } from "next/navigation";
import { getRepo } from "@/lib/repo";
import { RegisterForm } from "@/components/register-form";
import { formatRange, lengthLabel } from "@/lib/format";

export const metadata: Metadata = { title: "Register for a course", robots: { index: false, follow: false } };

export default async function RegisterPage({ searchParams }: { searchParams: Promise<{ course?: string; schedule?: string }> }) {
  const { course: slug, schedule } = await searchParams;
  if (!slug) notFound();
  const repo = await getRepo();
  const [course, centers] = await Promise.all([repo.getCourse(slug), repo.listCenters()]);
  if (!course) notFound();
  const selected = course.schedules.find((s) => s.id === schedule);
  const gone = !!schedule && !selected; // the link pointed at a date that has since been cancelled or removed

  return (
    <div className="mx-auto max-w-3xl px-4 py-12 sm:px-6">
      <Link href={`/courses/${course.slug}`} className="text-sm font-medium text-brand-700 hover:underline">← Back to course</Link>
      <h1 className="mt-3 text-3xl font-bold tracking-tight">Register for {course.name}</h1>
      {gone && <p role="alert" className="mt-2 rounded-lg bg-amber-50 px-4 py-3 text-sm font-medium text-amber-900">That start date is no longer available. Please choose another from the list below.</p>}
      {selected && <p className="mt-2 rounded-lg bg-brand-50 px-4 py-3 text-sm font-medium text-brand-800">{formatRange(selected.startDate, selected.endDate)} · {lengthLabel[selected.length]} · Monday to Friday</p>}
      <div className="mt-8 rounded-2xl border border-line bg-white p-6 shadow-sm sm:p-8">
        <RegisterForm courseSlug={course.slug} schedules={course.schedules} selectedId={selected?.id} centers={centers} />
      </div>
    </div>
  );
}
