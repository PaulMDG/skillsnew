import type { Metadata } from "next";
import Link from "next/link";
import { notFound } from "next/navigation";
import { ChevronDown, Clock, MapPin, Award } from "lucide-react";
import { getRepo } from "@/lib/repo";
import { ScheduleTable } from "@/components/schedule-table";
import { BrochureForm } from "@/components/brochure-form";
import { JsonLd } from "@/components/json-ld";
import { abs, site } from "@/lib/site";
import { lengthLabel, priceText } from "@/lib/format";

export const revalidate = 3600;
type Props = { params: Promise<{ slug: string }> };

export async function generateStaticParams() {
  try {
    return (await (await getRepo()).listCourses()).map((x) => ({ slug: x.slug }));
  } catch {
    return []; // DB not reachable at build time: pages are generated on first request instead
  }
}

export async function generateMetadata({ params }: Props): Promise<Metadata> {
  const c = await (await getRepo()).getCourse((await params).slug);
  if (!c) return {};
  const title = c.metaTitle || `${c.name} Training Course`;
  const description = c.metaDescription || c.summary;
  return {
    title, description,
    alternates: { canonical: `/courses/${c.slug}` },
    openGraph: { title, description, type: "website", url: abs(`/courses/${c.slug}`), images: c.imageUrl ? [c.imageUrl] : undefined },
  };
}

const lines = (t?: string | null) => (t ?? "").split(/\r?\n/).map((l) => l.trim()).filter(Boolean);

export default async function CoursePage({ params }: Props) {
  const { slug } = await params;
  const c = await (await getRepo()).getCourse(slug);
  if (!c) notFound();

  const url = abs(`/courses/${c.slug}`);
  const instances = c.schedules.slice(0, 10).map((s) => ({
    "@type": "CourseInstance", courseMode: "onsite", startDate: s.startDate, endDate: s.endDate,
    courseWorkload: s.length === "FIVE_DAY" ? "P5D" : "P10D",
    location: { "@type": "Place", name: "Skills for Africa training centre" },
    offers: c.prices[s.length]?.KES != null ? { "@type": "Offer", price: c.prices[s.length]!.KES, priceCurrency: "KES", availability: "https://schema.org/InStock", url } : undefined,
  }));
  const objectives = lines(c.objectives);

  return (
    <>
      <JsonLd data={[
        {
          "@context": "https://schema.org", "@type": "Course", name: c.name, description: c.summary, url,
          provider: { "@type": "EducationalOrganization", name: site.name, url: site.url },
          educationalCredentialAwarded: "Certificate of completion", hasCourseInstance: instances,
        },
        { "@context": "https://schema.org", "@type": "BreadcrumbList", itemListElement: [
          { "@type": "ListItem", position: 1, name: "Home", item: abs("/") },
          { "@type": "ListItem", position: 2, name: c.categoryName, item: abs(`/categories/${c.categorySlug}`) },
          { "@type": "ListItem", position: 3, name: c.name, item: url },
        ] },
        ...(c.faqs.length ? [{ "@context": "https://schema.org", "@type": "FAQPage", mainEntity: c.faqs.map((f) => ({ "@type": "Question", name: f.question, acceptedAnswer: { "@type": "Answer", text: f.answer } })) }] : []),
      ]} />

      <section className="bg-brand-900 text-white">
        <div className="mx-auto max-w-7xl px-4 py-12 sm:px-6">
          <nav aria-label="Breadcrumb" className="text-sm text-brand-200">
            <Link href="/courses" className="hover:underline">Courses</Link> / <Link href={`/categories/${c.categorySlug}`} className="hover:underline">{c.categoryName}</Link>
          </nav>
          <h1 className="mt-3 max-w-4xl text-3xl font-extrabold leading-tight tracking-tight sm:text-4xl md:text-5xl">{c.name}</h1>
          <p className="mt-4 max-w-3xl text-lg text-brand-100">{c.summary}</p>
          <div className="mt-6 flex flex-wrap gap-x-6 gap-y-2 text-sm font-medium text-brand-100">
            <span className="flex items-center gap-2"><Clock className="h-4 w-4" />{c.lengths.map((l) => lengthLabel[l]).join(" or ") || "Duration on request"}</span>
            <span className="flex items-center gap-2"><MapPin className="h-4 w-4" />Classroom &amp; live online</span>
            <span className="flex items-center gap-2"><Award className="h-4 w-4" />Certificate of completion</span>
          </div>
        </div>
      </section>

      <div className="mx-auto grid max-w-7xl gap-10 px-4 py-12 sm:px-6 lg:grid-cols-[1fr_360px]">
        <article className="min-w-0 space-y-12">
          <section aria-labelledby="overview">
            <h2 id="overview" className="mb-4 text-2xl font-bold">Course overview</h2>
            <div className="prose-sfa">{c.description.split(/\n\s*\n/).map((para, i) => <p key={i}>{para}</p>)}</div>
          </section>

          {objectives.length > 0 && (
            <section aria-labelledby="objectives">
              <h2 id="objectives" className="mb-4 text-2xl font-bold">What you will learn</h2>
              <ul className="grid gap-3 sm:grid-cols-2">
                {objectives.map((o) => <li key={o} className="flex gap-3 rounded-xl bg-surface p-4 text-sm leading-relaxed"><span className="mt-0.5 grid h-5 w-5 shrink-0 place-items-center rounded-full bg-brand-600 text-[11px] font-bold text-white">✓</span>{o}</li>)}
              </ul>
            </section>
          )}

          {(c.targetAudience || c.methodology) && (
            <section className="grid gap-8 sm:grid-cols-2">
              {c.targetAudience && <div><h2 className="mb-3 text-xl font-bold">Who should attend</h2><div className="prose-sfa"><p>{c.targetAudience}</p></div></div>}
              {c.methodology && <div><h2 className="mb-3 text-xl font-bold">How it is delivered</h2><div className="prose-sfa"><p>{c.methodology}</p></div></div>}
            </section>
          )}

          {c.outline.length > 0 && (
            <section aria-labelledby="outline">
              <h2 id="outline" className="mb-4 text-2xl font-bold">Course outline</h2>
              <div className="divide-y divide-line rounded-xl border border-line">
                {c.outline.map((o, i) => (
                  <details key={o.title} open={i === 0} className="group p-4">
                    <summary className="flex items-center justify-between gap-4 font-semibold">{o.title}<ChevronDown className="h-5 w-5 shrink-0 text-muted transition group-open:rotate-180" /></summary>
                    {o.body && <p className="mt-3 text-sm leading-relaxed text-muted">{o.body}</p>}
                  </details>
                ))}
              </div>
            </section>
          )}

          <section id="schedule" aria-labelledby="dates" className="scroll-mt-24">
            <h2 id="dates" className="mb-4 text-2xl font-bold">Upcoming dates &amp; fees</h2>
            <ScheduleTable slug={c.slug} lengths={c.lengths} schedules={c.schedules} prices={c.prices} />
          </section>

          {c.faqs.length > 0 && (
            <section aria-labelledby="faq">
              <h2 id="faq" className="mb-4 text-2xl font-bold">Frequently asked questions</h2>
              <div className="divide-y divide-line rounded-xl border border-line">
                {c.faqs.map((f) => (
                  <details key={f.question} className="group p-4">
                    <summary className="flex items-center justify-between gap-4 font-semibold">{f.question}<ChevronDown className="h-5 w-5 shrink-0 text-muted transition group-open:rotate-180" /></summary>
                    <p className="mt-3 text-sm leading-relaxed text-muted">{f.answer}</p>
                  </details>
                ))}
              </div>
            </section>
          )}
        </article>

        <aside className="lg:sticky lg:top-24 lg:self-start">
          <div className="rounded-2xl border border-line bg-white p-6 shadow-lg shadow-brand-900/5">
            <p className="text-xs font-semibold uppercase tracking-wide text-muted">Course fee</p>
            <p className="mt-1 text-2xl font-extrabold">{priceText(c.priceFrom)}</p>
            {c.lengths.length > 1 && <p className="text-xs text-muted">Lowest fee shown. Choose 5 or 10 days below.</p>}
            <Link href="#schedule" className="mt-5 block rounded-lg bg-brand-600 px-4 py-3 text-center text-sm font-semibold text-white shadow-sm transition hover:bg-brand-700">View dates &amp; register</Link>
            <div className="my-6 border-t border-line" />
            <h2 className="mb-3 text-sm font-bold">Download the course brochure</h2>
            <BrochureForm courseSlug={c.slug} />
          </div>
        </aside>
      </div>
    </>
  );
}
