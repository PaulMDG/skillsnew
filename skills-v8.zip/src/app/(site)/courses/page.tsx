import type { Metadata } from "next";
import Link from "next/link";
import { getRepo } from "@/lib/repo";
import { CourseCardView } from "@/components/course-card";

export const revalidate = 3600;

export const metadata: Metadata = {
  title: "All training courses",
  description: "Browse professional training courses with upcoming Monday start dates, in the classroom or online.",
  alternates: { canonical: "/courses" },
};

export default async function CoursesPage({ searchParams }: { searchParams: Promise<{ q?: string }> }) {
  const { q } = await searchParams;
  const query = q?.slice(0, 80);
  const repo = await getRepo();
  const [courses, categories] = await Promise.all([repo.listCourses({ q: query }), repo.listCategories()]);

  return (
    <div className="mx-auto max-w-7xl px-4 py-10 sm:px-6">
      <h1 className="text-4xl font-bold tracking-tight">{query ? `Results for “${query}”` : "All courses"}</h1>
      <p className="mt-2 text-muted">{courses.length} course{courses.length === 1 ? "" : "s"}</p>
      <div className="mt-6 flex flex-wrap gap-2" aria-label="Categories">
        <span className="rounded-full bg-brand-600 px-4 py-1.5 text-sm font-semibold text-white">All</span>
        {categories.map((c) => <Link key={c.id} href={`/categories/${c.slug}`} className="rounded-full border border-line px-4 py-1.5 text-sm font-medium text-muted transition hover:border-brand-500 hover:text-brand-700">{c.name}</Link>)}
      </div>
      {courses.length ? (
        <div className="mt-8 grid gap-6 sm:grid-cols-2 lg:grid-cols-3">{courses.map((c, i) => <CourseCardView key={c.id} course={c} priority={i < 3} />)}</div>
      ) : (
        <p className="mt-10 rounded-2xl border border-dashed border-line p-10 text-center text-muted">No courses matched. Try a different keyword or <Link className="font-semibold text-brand-700 underline" href="/contact">ask us</Link> — we may be able to run it.</p>
      )}
    </div>
  );
}
