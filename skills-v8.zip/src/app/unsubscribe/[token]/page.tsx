import type { Metadata } from "next";
import { revalidatePath } from "next/cache";
import { getEmailStore } from "@/lib/email/store";

export const metadata: Metadata = { title: "Unsubscribe", robots: { index: false, follow: false } };
export const dynamic = "force-dynamic";

/**
 * The link in the email only SHOWS this page. Unsubscribing needs a button press (POST), because mail
 * security scanners open every link in a message and must not silently unsubscribe people.
 */
export default async function UnsubscribePage({ params, searchParams }: { params: Promise<{ token: string }>; searchParams: Promise<{ done?: string }> }) {
  const { token } = await params;
  const { done } = await searchParams;

  async function confirm() {
    "use server";
    await (await getEmailStore()).unsubscribeByToken(token);
    revalidatePath(`/unsubscribe/${token}`);
    const { redirect } = await import("next/navigation");
    redirect(`/unsubscribe/${token}?done=1`);
  }

  return (
    <div className="mx-auto max-w-md px-4 py-20 text-center">
      {done ? (
        <>
          <h1 className="text-2xl font-bold">You&apos;ve been unsubscribed</h1>
          <p className="mt-3 text-muted">You won&apos;t receive any more reminders from us. You can still browse courses and register any time.</p>
        </>
      ) : (
        <>
          <h1 className="text-2xl font-bold">Unsubscribe from reminders?</h1>
          <p className="mt-3 text-muted">You will stop receiving course reminders and date updates by email.</p>
          <form action={confirm} className="mt-6"><button className="rounded-lg bg-brand-600 px-6 py-3 font-semibold text-white hover:bg-brand-700">Yes, unsubscribe me</button></form>
        </>
      )}
    </div>
  );
}
