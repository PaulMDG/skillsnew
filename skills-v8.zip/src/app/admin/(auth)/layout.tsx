import { Logo } from "@/components/site-header";

export default function AuthLayout({ children }: { children: React.ReactNode }) {
  return (
    <div className="grid min-h-screen place-items-center bg-surface px-4 py-10">
      <div className="w-full max-w-md">
        <div className="mb-6 flex justify-center"><Logo /></div>
        <div className="rounded-2xl border border-line bg-white p-8 shadow-xl shadow-brand-900/5">{children}</div>
        <p className="mt-6 text-center text-xs text-muted">Authorised staff only. Access is logged.</p>
      </div>
    </div>
  );
}
