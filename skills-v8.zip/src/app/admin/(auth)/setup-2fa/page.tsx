import type { Metadata } from "next";
import { cookies } from "next/headers";
import { redirect } from "next/navigation";
import QRCode from "qrcode";
import { CodeForm } from "@/components/admin/code-form";
import { COOKIE_PENDING } from "@/lib/auth/config";
import { decrypt } from "@/lib/auth/crypto";
import { getStaffStore } from "@/lib/auth/store";
import { verifyPending } from "@/lib/auth/tokens";
import { otpauthUri } from "@/lib/auth/totp";

export const metadata: Metadata = { title: "Set up two-factor authentication" };
export const dynamic = "force-dynamic";

export default async function Setup2faPage({ searchParams }: { searchParams: Promise<{ next?: string }> }) {
  const pending = await verifyPending((await cookies()).get(COOKIE_PENDING)?.value);
  if (!pending || pending.purpose !== "enroll" || !pending.enc) redirect("/admin/login");
  const user = await (await getStaffStore()).findById(pending.sub);
  if (!user || user.totpEnabled || user.sessionVersion !== pending.sv) redirect("/admin/login");

  const secret = decrypt(pending.enc);
  const qr = await QRCode.toDataURL(otpauthUri(secret, user.email), { margin: 1, width: 220 });
  const { next } = await searchParams;

  return (
    <>
      <h1 className="text-2xl font-bold">Secure your account</h1>
      <p className="mt-1 text-sm text-muted">Two-factor authentication is required for all staff. Scan this QR code with Google Authenticator, Microsoft Authenticator, Authy or 1Password.</p>
      <div className="my-5 flex justify-center">
        {/* eslint-disable-next-line @next/next/no-img-element */}
        <img src={qr} alt="QR code for your authenticator app" width={220} height={220} className="rounded-xl border border-line" />
      </div>
      <details className="mb-5 text-sm">
        <summary className="cursor-pointer font-medium text-brand-700">Can&apos;t scan? Enter the key manually</summary>
        <code className="mt-2 block break-all rounded-lg bg-surface p-3 font-mono text-xs tracking-wider">{secret}</code>
      </details>
      <CodeForm next={next} submitLabel="Confirm and sign in" />
    </>
  );
}
