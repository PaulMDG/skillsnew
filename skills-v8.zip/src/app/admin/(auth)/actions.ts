"use server";

import { cookies } from "next/headers";
import { redirect } from "next/navigation";
import { z } from "zod";
import { COOKIE_PENDING, LOCK_MS, MAX_FAILED } from "@/lib/auth/config";
import { decrypt, encrypt } from "@/lib/auth/crypto";
import { dummyHash, verifyPassword } from "@/lib/auth/password";
import { clearPendingCookie, createSession, destroySession, getStaff, safeNext, setPendingCookie } from "@/lib/auth/session";
import { getStaffStore } from "@/lib/auth/store";
import { generateSecret, verifyTotp } from "@/lib/auth/totp";
import { signPending, verifyPending } from "@/lib/auth/tokens";
import type { AuthFormState } from "@/lib/auth/types";
import { clientIp, hashIp } from "@/lib/ip";
import { rateLimit } from "@/lib/rate-limit";

const GENERIC = "Invalid email or password, or the account is temporarily locked.";
const loginSchema = z.object({ email: z.string().trim().toLowerCase().email().max(190), password: z.string().min(1).max(256) });

export async function loginAction(_: AuthFormState, fd: FormData): Promise<AuthFormState> {
  const ip = await clientIp();
  const ipHash = hashIp(ip);
  const parsed = loginSchema.safeParse({ email: fd.get("email"), password: fd.get("password") });
  if (!parsed.success) return { error: GENERIC };
  const { email, password } = parsed.data;

  if (!rateLimit(`login:ip:${ip}`, 15, 15 * 60_000) || !rateLimit(`login:email:${email}`, 8, 15 * 60_000)) {
    return { error: "Too many attempts. Please wait a few minutes and try again." };
  }

  const store = await getStaffStore();
  const user = await store.findByEmail(email);
  const locked = !!user?.lockedUntil && user.lockedUntil.getTime() > Date.now();
  // Always run one argon2 verification so unknown emails cost the same time as real ones
  const passwordOk = await verifyPassword(user && user.isActive ? user.passwordHash : await dummyHash(), password);

  if (!user || !user.isActive || locked || !passwordOk) {
    if (user && user.isActive && !locked) await store.recordFailedLogin(user.id, MAX_FAILED, LOCK_MS);
    await store.audit({ actorId: user?.id, action: locked ? "login.blocked_locked" : "login.failed", ipHash });
    return { error: GENERIC };
  }

  const next = encodeURIComponent(safeNext(fd.get("next")));
  if (user.totpEnabled) {
    await setPendingCookie(await signPending({ sub: user.id, sv: user.sessionVersion, purpose: "verify" }));
    redirect(`/admin/login/verify?next=${next}`);
  }
  // First login (or after a 2FA reset): enrolment is mandatory before any access is granted
  await setPendingCookie(await signPending({ sub: user.id, sv: user.sessionVersion, purpose: "enroll", enc: encrypt(generateSecret()) }));
  redirect(`/admin/setup-2fa?next=${next}`);
}

export async function verifyCodeAction(_: AuthFormState, fd: FormData): Promise<AuthFormState> {
  const ipHash = hashIp(await clientIp());
  const jar = await cookies();
  const pending = await verifyPending(jar.get(COOKIE_PENDING)?.value);
  if (!pending) redirect("/admin/login");

  const code = String(fd.get("code") ?? "").replace(/\s/g, "");
  if (!/^\d{6}$/.test(code)) return { error: "Enter the 6-digit code from your authenticator app." };
  if (!rateLimit(`totp:${pending.sub}`, 8, 10 * 60_000)) { await clearPendingCookie(); redirect("/admin/login"); }

  const store = await getStaffStore();
  const user = await store.findById(pending.sub);
  const locked = !!user?.lockedUntil && user.lockedUntil.getTime() > Date.now();
  if (!user || !user.isActive || locked || user.sessionVersion !== pending.sv) { await clearPendingCookie(); redirect("/admin/login"); }

  const enrolling = pending.purpose === "enroll";
  if (enrolling === user.totpEnabled) { await clearPendingCookie(); redirect("/admin/login"); } // stale/mismatched flow

  let secret: string;
  try { secret = decrypt(enrolling ? pending.enc! : user.totpSecretEnc!); }
  catch { await clearPendingCookie(); redirect("/admin/login"); }

  const step = verifyTotp(secret, code);
  if (step === null) {
    await store.recordFailedLogin(user.id, MAX_FAILED, LOCK_MS); // wrong codes count towards lockout too
    await store.audit({ actorId: user.id, action: "login.2fa_failed", ipHash });
    return { error: "That code isn't right. Check the time on your phone and try the newest code." };
  }
  if (!(await store.consumeTotpStep(user.id, step))) {
    return { error: "That code was already used. Wait for the next one to appear and try again." };
  }

  if (enrolling) {
    await store.enableTotp(user.id, encrypt(secret));
    await store.audit({ actorId: user.id, action: "2fa.enabled", ipHash });
  }
  await store.recordSuccessfulLogin(user.id);
  await store.audit({ actorId: user.id, action: "login.success", ipHash });
  await clearPendingCookie();
  await createSession(user);
  redirect(safeNext(fd.get("next")));
}

export async function logoutAction() {
  const staff = await getStaff();
  if (staff) await (await getStaffStore()).audit({ actorId: staff.id, action: "logout", ipHash: hashIp(await clientIp()) });
  await destroySession();
  redirect("/admin/login");
}
