import type { Metadata } from "next";
import { cookies } from "next/headers";
import { redirect } from "next/navigation";
import { CodeForm } from "@/components/admin/code-form";
import { COOKIE_PENDING } from "@/lib/auth/config";
import { verifyPending } from "@/lib/auth/tokens";

export const metadata: Metadata = { title: "Two-factor verification" };
export const dynamic = "force-dynamic";

export default async function VerifyPage({ searchParams }: { searchParams: Promise<{ next?: string }> }) {
  const pending = await verifyPending((await cookies()).get(COOKIE_PENDING)?.value);
  if (!pending || pending.purpose !== "verify") redirect("/admin/login");
  const { next } = await searchParams;
  return (
    <>
      <h1 className="text-2xl font-bold">Two-factor verification</h1>
      <p className="mt-1 text-sm text-muted">Open your authenticator app and enter the 6-digit code for Skills for Africa.</p>
      <CodeForm next={next} />
    </>
  );
}
