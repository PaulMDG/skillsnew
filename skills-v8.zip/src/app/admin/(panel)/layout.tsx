import Link from "next/link";
import { LayoutDashboard, BookOpen, Tags, CalendarDays, Banknote, CalendarX, Users, Newspaper, Mail, UserCircle, LogOut, Download, HelpCircle } from "lucide-react";
import { requireStaff } from "@/lib/auth/session";
import { logoutAction } from "../(auth)/actions";

const items = [
  { href: "/admin", label: "Dashboard", icon: LayoutDashboard, ready: true },
  { href: "/admin/courses", label: "Courses", icon: BookOpen, ready: true },
  { href: "/admin/categories", label: "Categories", icon: Tags, ready: true },
  { href: "/admin/schedules", label: "Schedules", icon: CalendarDays, ready: true },
  { href: "/admin/prices", label: "Manage prices", icon: Banknote, ready: true },
  { href: "/admin/faqs", label: "FAQs", icon: HelpCircle, ready: true },
  { href: "/admin/unscheduled", label: "Unscheduled", icon: CalendarX, ready: true },
  { href: "/admin/students", label: "Students", icon: Users, ready: true },
  { href: "/admin/leads", label: "Brochure leads", icon: Download, ready: true },
  { href: "/admin/blog", label: "Blog", icon: Newspaper, ready: true },
  { href: "/admin/emails", label: "Emails", icon: Mail, ready: true },
];

export default async function AdminLayout({ children }: { children: React.ReactNode }) {
  const staff = await requireStaff();
  return (
    <div className="min-h-screen bg-surface md:flex">
      <aside className="border-b border-line bg-brand-900 text-brand-100 md:min-h-screen md:w-64 md:border-b-0">
        <div className="px-5 py-5 text-lg font-bold text-white">Skills for Africa <span className="ml-1 rounded bg-accent-500 px-1.5 py-0.5 align-middle text-[10px] font-bold text-brand-900">ADMIN</span></div>
        <nav aria-label="Admin" className="flex gap-1 overflow-x-auto px-3 pb-3 md:flex-col md:pb-0">
          {items.map(({ href, label, icon: Icon, ready }) => ready ? (
            <Link key={href} href={href} className="flex shrink-0 items-center gap-3 rounded-lg px-3 py-2.5 text-sm font-medium hover:bg-white/10 hover:text-white"><Icon className="h-4 w-4" />{label}</Link>
          ) : (
            <span key={href} aria-disabled="true" className="flex shrink-0 cursor-not-allowed items-center gap-3 rounded-lg px-3 py-2.5 text-sm font-medium opacity-45"><Icon className="h-4 w-4" />{label}<span className="ml-auto rounded bg-white/10 px-1.5 text-[10px]">Soon</span></span>
          ))}
        </nav>
        <div className="mt-4 hidden border-t border-white/10 p-4 text-sm md:block">
          <Link href="/admin/account" className="flex items-center gap-2 font-medium text-white hover:underline"><UserCircle className="h-4 w-4" />{staff.name}</Link>
          <div className="mt-0.5 pl-6 text-xs text-brand-200">{staff.role.charAt(0) + staff.role.slice(1).toLowerCase()}</div>
          <form action={logoutAction} className="mt-3"><button className="flex items-center gap-2 rounded-lg px-2 py-1.5 text-xs font-semibold text-brand-100 hover:bg-white/10"><LogOut className="h-4 w-4" />Sign out</button></form>
        </div>
      </aside>
      <div className="min-w-0 flex-1 p-4 sm:p-8">{children}</div>
    </div>
  );
}
