"use server";

import { revalidatePath } from "next/cache";
import { requireStaff } from "@/lib/auth/session";
import { getStaffStore } from "@/lib/auth/store";
import { emailService } from "@/lib/email/service";

/** ADMIN-only: release due follow-ups and retry queued mail right now (same as the hourly job). */
export async function runEmailJobNowAction() {
  const staff = await requireStaff(["ADMIN"]);
  const svc = await emailService();
  const followUps = await svc.runFollowUps();
  const delivery = await svc.deliverQueued();
  await (await getStaffStore()).audit({ actorId: staff.id, action: "emails.run_now", meta: { followUps, delivery } });
  revalidatePath("/admin/emails");
}
