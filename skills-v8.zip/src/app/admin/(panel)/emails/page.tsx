import type { Metadata } from "next";
import Link from "next/link";
import type { EmailStatus } from "@prisma/client";
import { requireStaff } from "@/lib/auth/session";
import { getEmailStore } from "@/lib/email/store";
import { formatDate } from "@/lib/format";
import { runEmailJobNowAction } from "./actions";

export const metadata: Metadata = { title: "Emails" };
export const dynamic = "force-dynamic";

const STATUSES: EmailStatus[] = ["QUEUED", "SENT", "DELIVERED", "BOUNCED", "COMPLAINED", "FAILED", "SUPPRESSED"];
const badge: Record<EmailStatus, string> = {
  QUEUED: "bg-slate-100 text-slate-700", SENT: "bg-sky-50 text-sky-800", DELIVERED: "bg-brand-50 text-brand-800",
  BOUNCED: "bg-red-50 text-red-700", COMPLAINED: "bg-red-100 text-red-800", FAILED: "bg-amber-50 text-amber-800", SUPPRESSED: "bg-slate-100 text-slate-600",
};
const pct = (a: number, b: number) => (b ? `${((a / b) * 100).toFixed(1)}%` : "–");
const fmt = (n: number) => new Intl.NumberFormat("en-KE").format(n);
const when = (iso: string | null) => (iso ? `${formatDate(iso.slice(0, 10))} ${iso.slice(11, 16)}` : "—");
const stageLabel = (n: number) => (n === 0 ? "Awaiting stage 1" : `Stage ${n}`);

export default async function EmailsPage({ searchParams }: { searchParams: Promise<{ status?: string; q?: string }> }) {
  const staff = await requireStaff(["ADMIN", "MARKETING"]);
  const { status, q } = await searchParams;
  const filter = STATUSES.find((s) => s === status);
  const store = await getEmailStore();
  const [st, rows] = await Promise.all([store.stats(), store.listMessages({ status: filter, q: q?.slice(0, 80), limit: 100 })]);
  const sent = st.byStatus.SENT + st.byStatus.DELIVERED + st.byStatus.BOUNCED + st.byStatus.COMPLAINED;
  const reached = st.byStatus.DELIVERED;

  const cards: [string, string, string?][] = [
    ["Sent", fmt(sent), `${fmt(st.last30.sent)} in last 30 days`],
    ["Delivered", fmt(reached), `${pct(reached, sent)} of sent`],
    ["Opened", fmt(st.opened), `${pct(st.opened, reached)} of delivered`],
    ["Clicked", fmt(st.clicked), `${pct(st.clicked, reached)} of delivered`],
    ["Bounced", fmt(st.byStatus.BOUNCED), `${pct(st.byStatus.BOUNCED, sent)} of sent`],
    ["Complaints", fmt(st.byStatus.COMPLAINED), "spam reports"],
    ["Failed / queued", `${fmt(st.byStatus.FAILED)} / ${fmt(st.byStatus.QUEUED)}`, "will retry up to 3 times"],
    ["Suppressed addresses", fmt(st.suppressed), "never emailed again"],
  ];

  return (
    <div className="mx-auto max-w-6xl">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div><h1 className="text-2xl font-bold">Emails</h1><p className="text-sm text-muted">Brochure, registration and follow-up emails: sent, delivered, opened, bounced.</p></div>
        {staff.role === "ADMIN" && <form action={runEmailJobNowAction}><button className="rounded-lg border border-brand-600 px-4 py-2 text-sm font-semibold text-brand-700 hover:bg-brand-50">Run follow-up job now</button></form>}
      </div>

      <div className="mt-6 grid gap-4 sm:grid-cols-2 xl:grid-cols-4">
        {cards.map(([label, value, sub]) => (
          <div key={label} className="rounded-2xl border border-line bg-white p-5"><div className="text-sm font-medium text-muted">{label}</div><div className="mt-2 text-3xl font-extrabold tracking-tight">{value}</div>{sub && <div className="mt-1 text-xs text-muted">{sub}</div>}</div>
        ))}
      </div>

      <section className="mt-8 rounded-2xl border border-line bg-white p-5">
        <h2 className="font-bold">Follow-up sequences</h2>
        <p className="mt-1 text-sm text-muted">Stage 1 = day 3 · 2 = day 7 · 3 = day 14 · 4 = month 2 · 5 = month 3 · 6+ = monthly.</p>
        <div className="mt-4 flex flex-wrap gap-6 text-sm">
          <span><strong>{fmt(st.followUps.active)}</strong> active</span><span><strong>{fmt(st.followUps.converted)}</strong> converted</span>
          <span><strong>{fmt(st.followUps.unsubscribed)}</strong> unsubscribed</span><span><strong>{fmt(st.followUps.suppressed)}</strong> stopped (bounce/complaint)</span>
        </div>
        {st.followUps.byStage.length > 0 && (
          <ul className="mt-4 grid gap-2 sm:grid-cols-2 lg:grid-cols-4">
            {st.followUps.byStage.map((b) => <li key={b.stage} className="flex justify-between rounded-lg bg-surface px-3 py-2 text-sm"><span>{stageLabel(b.stage)}</span><strong>{fmt(b.count)}</strong></li>)}
          </ul>
        )}
      </section>

      <section className="mt-8">
        <div className="mb-3 flex flex-wrap items-center gap-2">
          <h2 className="mr-2 font-bold">Messages</h2>
          <Link href="/admin/emails" className={`rounded-full px-3 py-1 text-xs font-semibold ${!filter ? "bg-brand-600 text-white" : "border border-line text-muted"}`}>All</Link>
          {STATUSES.map((s) => <Link key={s} href={`/admin/emails?status=${s}`} className={`rounded-full px-3 py-1 text-xs font-semibold ${filter === s ? "bg-brand-600 text-white" : "border border-line text-muted hover:border-brand-500"}`}>{s.charAt(0) + s.slice(1).toLowerCase()} ({st.byStatus[s]})</Link>)}
          <form className="ml-auto" action="/admin/emails"><input name="q" defaultValue={q} placeholder="Search email address" className="rounded-lg border border-line px-3 py-1.5 text-sm" />{filter && <input type="hidden" name="status" value={filter} />}</form>
        </div>
        <div className="overflow-x-auto rounded-2xl border border-line bg-white">
          <table className="w-full min-w-[860px] text-left text-sm">
            <thead className="bg-surface text-xs uppercase tracking-wide text-muted"><tr><th className="px-4 py-3">Recipient</th><th className="px-4 py-3">Email</th><th className="px-4 py-3">Status</th><th className="px-4 py-3">Sent</th><th className="px-4 py-3">Opened</th><th className="px-4 py-3">Clicked</th></tr></thead>
            <tbody className="divide-y divide-line">
              {rows.length === 0 && <tr><td colSpan={6} className="px-4 py-10 text-center text-muted">No messages yet.</td></tr>}
              {rows.map((m) => (
                <tr key={m.id}>
                  <td className="px-4 py-3 font-medium">{m.toEmail}</td>
                  <td className="px-4 py-3 text-muted"><div className="max-w-xs truncate" title={m.subject}>{m.subject || "(not sent yet)"}</div><div className="text-xs">{m.template}{m.stage ? ` · stage ${m.stage}` : ""}</div></td>
                  <td className="px-4 py-3"><span className={`rounded-full px-2.5 py-1 text-xs font-semibold ${badge[m.status]}`}>{m.status}</span>{m.bounceType && <div className="mt-1 text-xs text-muted">{m.bounceType}</div>}{m.error && <div className="mt-1 max-w-[220px] truncate text-xs text-amber-700" title={m.error}>{m.error} (attempt {m.attempts})</div>}</td>
                  <td className="px-4 py-3 text-muted">{when(m.sentAt)}</td><td className="px-4 py-3 text-muted">{when(m.openedAt)}</td><td className="px-4 py-3 text-muted">{when(m.clickedAt)}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </section>
    </div>
  );
}
