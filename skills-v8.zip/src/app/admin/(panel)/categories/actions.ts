"use server";

import { revalidatePath } from "next/cache";
import { revalidatePublicSite } from "@/lib/revalidate";
import { redirect } from "next/navigation";
import { requireStaff } from "@/lib/auth/session";
import { getStaffStore } from "@/lib/auth/store";
import { getRepo } from "@/lib/repo";
import { categoryFormSchema, toCategoryInput } from "@/lib/admin-schemas";
import type { FormState } from "@/lib/validation";

export async function saveCategoryAction(_: FormState, fd: FormData): Promise<FormState> {
  const staff = await requireStaff(["ADMIN", "EDITOR"]);
  const parsed = categoryFormSchema.safeParse(Object.fromEntries(fd));
  if (!parsed.success) return { status: "error", message: "Please fix the highlighted fields.", fieldErrors: parsed.error.flatten().fieldErrors };
  const conv = toCategoryInput(parsed.data);
  if (!conv.ok) return { status: "error", message: "Please fix the highlighted fields.", fieldErrors: conv.fieldErrors };

  const res = await (await getRepo()).saveCategory(conv.value);
  if (!res.ok) return { status: "error", message: res.error, fieldErrors: res.fieldErrors };

  await (await getStaffStore()).audit({ actorId: staff.id, action: conv.value.id ? "category.update" : "category.create", entity: "category", entityId: res.id, meta: { name: conv.value.name, status: conv.value.status } });
  await revalidatePublicSite();
  revalidatePath("/admin/categories");
  redirect(`/admin/categories/${res.id}?saved=1`);
}
