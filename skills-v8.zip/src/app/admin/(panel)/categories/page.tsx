import type { Metadata } from "next";
import Link from "next/link";
import { CategoryIcon } from "@/components/category-icon";
import { requireStaff } from "@/lib/auth/session";
import { getRepo } from "@/lib/repo";

export const metadata: Metadata = { title: "Categories" };
export const dynamic = "force-dynamic";

export default async function AdminCategories() {
  const staff = await requireStaff(["ADMIN", "EDITOR", "MARKETING"]);
  const canEdit = staff.role !== "MARKETING";
  const cats = await (await getRepo()).adminListCategories();
  return (
    <div className="mx-auto max-w-4xl">
      <div className="flex items-center justify-between">
        <div><h1 className="text-2xl font-bold">Categories</h1><p className="text-sm text-muted">{cats.length} categories</p></div>
        {canEdit && <Link href="/admin/categories/new" className="rounded-lg bg-brand-600 px-4 py-2 text-sm font-semibold text-white hover:bg-brand-700">Add category</Link>}
      </div>
      <div className="mt-6 overflow-x-auto rounded-2xl border border-line bg-white">
        <table className="w-full min-w-[560px] text-left text-sm">
          <thead className="bg-surface text-xs uppercase tracking-wide text-muted"><tr><th className="px-5 py-3">Category</th><th className="px-5 py-3">Courses</th><th className="px-5 py-3">Order</th><th className="px-5 py-3">Status</th><th className="px-5 py-3"><span className="sr-only">Actions</span></th></tr></thead>
          <tbody className="divide-y divide-line">
            {cats.map((c) => (
              <tr key={c.id}>
                <td className="px-5 py-3.5"><span className="flex items-center gap-3 font-semibold"><span className="grid h-9 w-9 place-items-center rounded-lg bg-brand-50 text-brand-700"><CategoryIcon name={c.iconKey} className="h-4 w-4" /></span>{c.name}</span></td>
                <td className="px-5 py-3.5">{c.courses}</td><td className="px-5 py-3.5 text-muted">{c.sortOrder}</td>
                <td className="px-5 py-3.5"><span className={`rounded-full px-2.5 py-1 text-xs font-semibold ${c.status === "PUBLISHED" ? "bg-brand-50 text-brand-800" : "bg-amber-50 text-amber-800"}`}>{c.status}</span></td>
                <td className="px-5 py-3.5 text-right">{canEdit && <Link href={`/admin/categories/${c.id}`} className="font-semibold text-brand-700 hover:underline">Edit</Link>}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}
