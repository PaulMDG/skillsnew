import type { Metadata } from "next";
import Link from "next/link";
import { notFound } from "next/navigation";
import { CategoryForm } from "@/components/admin/category-form";
import { requireStaff } from "@/lib/auth/session";
import { getRepo } from "@/lib/repo";

export const metadata: Metadata = { title: "Edit category" };
export const dynamic = "force-dynamic";

export default async function EditCategory({ params, searchParams }: { params: Promise<{ id: string }>; searchParams: Promise<{ saved?: string }> }) {
  await requireStaff(["ADMIN", "EDITOR"]);
  const { id } = await params;
  const { saved } = await searchParams;
  const category = await (await getRepo()).getCategoryForEdit(id);
  if (!category) notFound();
  return (
    <div className="mx-auto max-w-3xl">
      <Link href="/admin/categories" className="text-sm font-medium text-brand-700 hover:underline">← All categories</Link>
      <h1 className="mb-6 mt-2 text-2xl font-bold">{category.name}</h1>
      <CategoryForm key={saved ? "saved" : "edit"} category={category} saved={!!saved} />
    </div>
  );
}
