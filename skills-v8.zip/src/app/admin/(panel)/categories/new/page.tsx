import type { Metadata } from "next";
import Link from "next/link";
import { CategoryForm } from "@/components/admin/category-form";
import { requireStaff } from "@/lib/auth/session";

export const metadata: Metadata = { title: "Add category" };
export const dynamic = "force-dynamic";

export default async function NewCategory() {
  await requireStaff(["ADMIN", "EDITOR"]);
  return (
    <div className="mx-auto max-w-3xl">
      <Link href="/admin/categories" className="text-sm font-medium text-brand-700 hover:underline">← All categories</Link>
      <h1 className="mb-6 mt-2 text-2xl font-bold">Add category</h1>
      <CategoryForm />
    </div>
  );
}
