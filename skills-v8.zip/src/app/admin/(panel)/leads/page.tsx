import type { Metadata } from "next";
import { requireStaff } from "@/lib/auth/session";
import { getRepo } from "@/lib/repo";
import { formatDate } from "@/lib/format";

export const metadata: Metadata = { title: "Brochure leads" };
export const dynamic = "force-dynamic";

export default async function LeadsPage({ searchParams }: { searchParams: Promise<{ q?: string }> }) {
  await requireStaff(["ADMIN", "MARKETING"]);
  const { q } = await searchParams;
  const leads = await (await getRepo()).listLeads({ q: q?.slice(0, 80), limit: 200 });
  return (
    <div className="mx-auto max-w-6xl">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div><h1 className="text-2xl font-bold">Brochure leads</h1><p className="text-sm text-muted">Everyone who requested a course brochure, with their contact details.</p></div>
        <form action="/admin/leads"><input name="q" defaultValue={q} placeholder="Search name or email" className="rounded-lg border border-line px-3 py-2 text-sm" /></form>
      </div>
      <div className="mt-6 overflow-x-auto rounded-2xl border border-line bg-white">
        <table className="w-full min-w-[900px] text-left text-sm">
          <thead className="bg-surface text-xs uppercase tracking-wide text-muted"><tr><th className="px-4 py-3">Contact</th><th className="px-4 py-3">Phone</th><th className="px-4 py-3">Organisation</th><th className="px-4 py-3">Course</th><th className="px-4 py-3">Requested</th><th className="px-4 py-3">Downloads</th></tr></thead>
          <tbody className="divide-y divide-line">
            {leads.length === 0 && <tr><td colSpan={6} className="px-4 py-10 text-center text-muted">No brochure requests yet.</td></tr>}
            {leads.map((l) => (
              <tr key={l.id}>
                <td className="px-4 py-3"><div className="font-semibold">{l.name}</div><a href={`mailto:${l.email}`} className="text-muted hover:underline">{l.email}</a></td>
                <td className="px-4 py-3 text-muted">{l.phone || "—"}</td>
                <td className="px-4 py-3 text-muted">{[l.company, l.country].filter(Boolean).join(", ") || "—"}</td>
                <td className="px-4 py-3">{l.course}</td>
                <td className="px-4 py-3 text-muted">{formatDate(l.createdAt.slice(0, 10))}</td>
                <td className="px-4 py-3">{l.downloadCount}{l.lastDownloadedAt && <span className="block text-xs text-muted">last {formatDate(l.lastDownloadedAt.slice(0, 10))}</span>}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}
