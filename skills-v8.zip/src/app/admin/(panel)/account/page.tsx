import type { Metadata } from "next";
import { ShieldCheck } from "lucide-react";
import { ChangePasswordForm } from "@/components/admin/change-password-form";
import { requireStaff } from "@/lib/auth/session";

export const metadata: Metadata = { title: "My account" };
export const dynamic = "force-dynamic";

export default async function AccountPage() {
  const staff = await requireStaff();
  return (
    <div className="mx-auto max-w-xl">
      <h1 className="text-2xl font-bold">My account</h1>
      <div className="mt-6 rounded-2xl border border-line bg-white p-6">
        <dl className="grid grid-cols-[100px_1fr] gap-y-2 text-sm">
          <dt className="text-muted">Name</dt><dd className="font-medium">{staff.name}</dd>
          <dt className="text-muted">Email</dt><dd className="font-medium">{staff.email}</dd>
          <dt className="text-muted">Role</dt><dd className="font-medium">{staff.role}</dd>
          <dt className="text-muted">2FA</dt><dd className="flex items-center gap-1.5 font-medium text-brand-700"><ShieldCheck className="h-4 w-4" />Enabled</dd>
        </dl>
      </div>
      <div className="mt-6 rounded-2xl border border-line bg-white p-6">
        <h2 className="font-bold">Change password</h2>
        <ChangePasswordForm />
      </div>
    </div>
  );
}
