"use server";

import { z } from "zod";
import { hashPassword, validateNewPassword, verifyPassword } from "@/lib/auth/password";
import { createSession, requireStaff } from "@/lib/auth/session";
import { getStaffStore } from "@/lib/auth/store";
import type { AuthFormState } from "@/lib/auth/types";
import { clientIp, hashIp } from "@/lib/ip";
import { rateLimit } from "@/lib/rate-limit";

const schema = z.object({ current: z.string().min(1).max(256), next: z.string().max(256), confirm: z.string().max(256) });

export async function changePasswordAction(_: AuthFormState, fd: FormData): Promise<AuthFormState> {
  const staff = await requireStaff();
  if (!rateLimit(`pw:${staff.id}`, 5, 15 * 60_000)) return { error: "Too many attempts. Try again later." };
  const parsed = schema.safeParse({ current: fd.get("current"), next: fd.get("next"), confirm: fd.get("confirm") });
  if (!parsed.success) return { error: "Please fill in all fields." };
  const { current, next, confirm } = parsed.data;
  if (next !== confirm) return { error: "The new passwords don't match." };
  const policy = validateNewPassword(next, staff.email);
  if (policy) return { error: policy };

  const store = await getStaffStore();
  const user = await store.findById(staff.id);
  if (!user || !(await verifyPassword(user.passwordHash, current))) return { error: "Your current password is incorrect." };
  if (await verifyPassword(user.passwordHash, next)) return { error: "Choose a password you haven't used before." };

  const sv = await store.setPassword(user.id, await hashPassword(next)); // invalidates every other session
  await createSession({ id: user.id, role: user.role, sessionVersion: sv }); // keep THIS browser signed in
  await store.audit({ actorId: user.id, action: "password.changed", ipHash: hashIp(await clientIp()) });
  return { success: "Password updated. All other devices have been signed out." };
}
