"use server";

import { revalidatePath } from "next/cache";
import { requireStaff } from "@/lib/auth/session";
import { getStaffStore } from "@/lib/auth/store";
import { getRepo } from "@/lib/repo";

export async function generateSchedulesAction(formData: FormData) {
  const staff = await requireStaff(["ADMIN", "EDITOR"]);
  const courseId = String(formData.get("courseId") ?? "");
  if (!courseId) return;
  const created = await (await getRepo()).generateSchedules(courseId);
  await (await getStaffStore()).audit({ actorId: staff.id, action: "schedules.generate", entity: "course", entityId: courseId, meta: { created } });
  revalidatePath("/admin/unscheduled");
  revalidatePath("/admin/courses");
}
