import type { Metadata } from "next";
import { requireStaff } from "@/lib/auth/session";
import { getRepo } from "@/lib/repo";
import { formatDate, formatRange, lengthLabel } from "@/lib/format";

export const metadata: Metadata = { title: "Students" };
export const dynamic = "force-dynamic";

export default async function StudentsPage({ searchParams }: { searchParams: Promise<{ q?: string }> }) {
  await requireStaff(["ADMIN", "MARKETING"]);
  const { q } = await searchParams;
  const students = await (await getRepo()).listStudents({ q: q?.slice(0, 80), limit: 200 });
  return (
    <div className="mx-auto max-w-6xl">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div><h1 className="text-2xl font-bold">Students</h1><p className="text-sm text-muted">Registered students, the courses they booked and their dates.</p></div>
        <form action="/admin/students"><input name="q" defaultValue={q} placeholder="Search name or email" className="rounded-lg border border-line px-3 py-2 text-sm" /></form>
      </div>
      <div className="mt-6 space-y-3">
        {students.length === 0 && <p className="rounded-2xl border border-dashed border-line p-10 text-center text-sm text-muted">No registrations yet.</p>}
        {students.map((s) => (
          <details key={s.id} className="group rounded-2xl border border-line bg-white" open={students.length <= 5}>
            <summary className="flex flex-wrap items-center justify-between gap-3 p-4">
              <div><div className="font-semibold">{s.name}</div><div className="text-sm text-muted">{s.email}{s.phone ? ` · ${s.phone}` : ""}{s.organisation ? ` · ${s.organisation}` : ""}</div></div>
              <span className="rounded-full bg-brand-50 px-3 py-1 text-xs font-semibold text-brand-800">{s.registrations.length} registration{s.registrations.length === 1 ? "" : "s"}</span>
            </summary>
            <ul className="divide-y divide-line border-t border-line">
              {s.registrations.map((r) => (
                <li key={r.id} className="flex flex-wrap items-center justify-between gap-2 px-4 py-3 text-sm">
                  <div><div className="font-medium">{r.course}</div><div className="text-muted">{formatRange(r.startDate, r.endDate)} · {lengthLabel[r.length]} · {r.mode === "ONLINE" ? "Online" : `Classroom${r.center ? `, ${r.center}` : ""}`}</div></div>
                  <div className="text-right text-xs text-muted"><span className="rounded-full bg-surface px-2.5 py-1 font-semibold text-ink">{r.status}</span><div className="mt-1">registered {formatDate(r.registeredAt.slice(0, 10))}</div></div>
                </li>
              ))}
            </ul>
          </details>
        ))}
      </div>
    </div>
  );
}
