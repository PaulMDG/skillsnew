import { Users, BookOpen, Download, ClipboardCheck, MailCheck, MailX, Repeat } from "lucide-react";
import { getRepo } from "@/lib/repo";
import { requireStaff } from "@/lib/auth/session";
import { getEmailStore } from "@/lib/email/store";
import { formatDate } from "@/lib/format";

export const dynamic = "force-dynamic";
const fmt = (n: number) => new Intl.NumberFormat("en-KE").format(n);

function Stat({ icon: Icon, label, value, sub }: { icon: typeof Users; label: string; value: string; sub?: string }) {
  return (
    <div className="rounded-2xl border border-line bg-white p-5">
      <div className="flex items-center justify-between"><span className="text-sm font-medium text-muted">{label}</span><span className="grid h-9 w-9 place-items-center rounded-lg bg-brand-50 text-brand-700"><Icon className="h-4 w-4" /></span></div>
      <div className="mt-3 text-3xl font-extrabold tracking-tight">{value}</div>
      {sub && <div className="mt-1 text-xs text-muted">{sub}</div>}
    </div>
  );
}

export default async function AdminDashboard() {
  await requireStaff();
  const [s, em] = await Promise.all([(await getRepo()).getDashboardStats(), getEmailStore().then((x) => x.stats())]);
  const pct = (a: number, b: number) => (b ? `${((a / b) * 100).toFixed(1)}%` : "–");
  const sent = em.byStatus.SENT + em.byStatus.DELIVERED + em.byStatus.BOUNCED + em.byStatus.COMPLAINED;

  return (
    <div className="mx-auto max-w-6xl">
      <h1 className="text-2xl font-bold">Dashboard</h1>
      <p className="text-sm text-muted">System overview</p>

      <div className="mt-6 grid gap-4 sm:grid-cols-2 xl:grid-cols-4">
        <Stat icon={Users} label="Registered students" value={fmt(s.students)} />
        <Stat icon={ClipboardCheck} label="Registrations" value={fmt(s.registrations)} sub={`${fmt(s.registrationsLast30)} in the last 30 days`} />
        <Stat icon={BookOpen} label="Published courses" value={fmt(s.publishedCourses)} sub={`${s.categories} categories`} />
        <Stat icon={Download} label="Brochure downloads" value={fmt(s.brochureDownloads)} sub={`${fmt(s.brochureDownloadsLast30)} in the last 30 days`} />
      </div>

      <h2 className="mb-3 mt-10 text-lg font-bold">Email follow-ups</h2>
      <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-4">
        <Stat icon={MailCheck} label="Delivered" value={fmt(em.byStatus.DELIVERED)} sub={`${pct(em.byStatus.DELIVERED, sent)} of ${fmt(sent)} sent`} />
        <Stat icon={MailX} label="Bounced" value={fmt(em.byStatus.BOUNCED)} sub={`${pct(em.byStatus.BOUNCED, sent)} bounce rate`} />
        <Stat icon={MailX} label="Complaints / failed" value={`${fmt(em.byStatus.COMPLAINED)} / ${fmt(em.byStatus.FAILED)}`} />
        <Stat icon={Repeat} label="Active follow-up sequences" value={fmt(em.followUps.active)} sub={`${fmt(em.followUps.converted)} converted · ${fmt(em.followUps.unsubscribed)} unsubscribed`} />
      </div>

      <div className="mt-10 grid gap-6 lg:grid-cols-2">
        <section className="rounded-2xl border border-line bg-white">
          <h2 className="border-b border-line px-5 py-4 font-bold">Recent registrations</h2>
          <ul className="divide-y divide-line">
            {s.recentRegistrations.map((r) => (
              <li key={r.id} className="px-5 py-3.5 text-sm"><div className="font-semibold">{r.student}</div><div className="text-muted">{r.course} · starts {formatDate(r.startDate)}</div></li>
            ))}
          </ul>
        </section>
        <section className="rounded-2xl border border-line bg-white">
          <h2 className="border-b border-line px-5 py-4 font-bold">Recent brochure downloads</h2>
          <ul className="divide-y divide-line">
            {s.recentLeads.map((l) => (
              <li key={l.id} className="px-5 py-3.5 text-sm"><div className="font-semibold">{l.name} <span className="font-normal text-muted">· {l.email}</span></div><div className="text-muted">{l.course}</div></li>
            ))}
          </ul>
        </section>
      </div>
    </div>
  );
}
