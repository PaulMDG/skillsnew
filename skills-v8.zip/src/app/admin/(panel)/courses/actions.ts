"use server";

import { revalidatePath } from "next/cache";
import { after } from "next/server";
import { openAiConfigured } from "@/lib/faq/openai";
import { faqService } from "@/lib/faq/service";
import { revalidatePublicSite } from "@/lib/revalidate";
import { redirect } from "next/navigation";
import { requireStaff } from "@/lib/auth/session";
import { getStaffStore } from "@/lib/auth/store";
import { getRepo } from "@/lib/repo";
import { courseFormSchema, toCourseInput } from "@/lib/admin-schemas";
import type { FormState } from "@/lib/validation";

export async function saveCourseAction(_: FormState, fd: FormData): Promise<FormState> {
  const staff = await requireStaff(["ADMIN", "EDITOR"]);
  const parsed = courseFormSchema.safeParse({ ...Object.fromEntries(fd), lengths: fd.getAll("lengths"), deliveryModes: fd.getAll("deliveryModes") });
  if (!parsed.success) return { status: "error", message: "Please fix the highlighted fields.", fieldErrors: parsed.error.flatten().fieldErrors };
  const conv = toCourseInput(parsed.data);
  if (!conv.ok) return { status: "error", message: "Please fix the highlighted fields.", fieldErrors: conv.fieldErrors };

  const res = await (await getRepo()).saveCourse(conv.value);
  if (!res.ok) return { status: "error", message: res.error, fieldErrors: res.fieldErrors };

  await (await getStaffStore()).audit({ actorId: staff.id, action: conv.value.id ? "course.update" : "course.create", entity: "course", entityId: res.id, meta: { name: conv.value.name, status: conv.value.status, lengths: conv.value.lengths } });
  await revalidatePublicSite({ courseSlug: res.slug });
  // New or reworded course → write FAQ drafts in the background (skipped automatically when its text did not change)
  if (conv.value.status === "PUBLISHED" && openAiConfigured()) {
    after(async () => { try { await (await faqService()).generateForCourse(res.id); } catch (e) { console.error("FAQ generation failed", e); } });
  }
  revalidatePath("/admin/courses"); revalidatePath("/admin/unscheduled"); revalidatePath("/admin/prices");
  redirect(`/admin/courses/${res.id}?saved=1`);
}
