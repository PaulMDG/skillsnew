import type { Metadata } from "next";
import Link from "next/link";
import { CourseForm } from "@/components/admin/course-form";
import { requireStaff } from "@/lib/auth/session";
import { getRepo } from "@/lib/repo";

export const metadata: Metadata = { title: "Add course" };
export const dynamic = "force-dynamic";

export default async function NewCourse() {
  await requireStaff(["ADMIN", "EDITOR"]);
  const categories = await (await getRepo()).listCategoryOptions();
  return (
    <div className="mx-auto max-w-3xl">
      <Link href="/admin/courses" className="text-sm font-medium text-brand-700 hover:underline">← All courses</Link>
      <h1 className="mb-6 mt-2 text-2xl font-bold">Add course</h1>
      <CourseForm categories={categories} />
    </div>
  );
}
