import type { Metadata } from "next";
import Link from "next/link";
import { getRepo } from "@/lib/repo";
import { requireStaff } from "@/lib/auth/session";
import { lengthLabel } from "@/lib/format";

export const metadata: Metadata = { title: "Courses" };
export const dynamic = "force-dynamic";

const tone: Record<string, string> = { PUBLISHED: "bg-brand-50 text-brand-800", DRAFT: "bg-amber-50 text-amber-800", ARCHIVED: "bg-slate-100 text-slate-600" };

export default async function AdminCourses({ searchParams }: { searchParams: Promise<{ q?: string }> }) {
  const staff = await requireStaff(["ADMIN", "EDITOR", "MARKETING"]);
  const canEdit = staff.role !== "MARKETING";
  const { q } = await searchParams;
  const all = await (await getRepo()).adminListCourses();
  const n = q?.trim().toLowerCase();
  const courses = n ? all.filter((c) => c.name.toLowerCase().includes(n) || c.category.toLowerCase().includes(n)) : all;
  return (
    <div className="mx-auto max-w-6xl">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div><h1 className="text-2xl font-bold">Courses</h1><p className="text-sm text-muted">{courses.length} of {all.length} courses</p></div>
        <div className="flex gap-3">
          <form action="/admin/courses"><input name="q" defaultValue={q} placeholder="Search courses" className="rounded-lg border border-line px-3 py-2 text-sm" /></form>
          {canEdit && <Link href="/admin/courses/new" className="rounded-lg bg-brand-600 px-4 py-2 text-sm font-semibold text-white hover:bg-brand-700">Add course</Link>}
        </div>
      </div>
      <div className="mt-6 overflow-x-auto rounded-2xl border border-line bg-white">
        <table className="w-full min-w-[760px] text-left text-sm">
          <thead className="bg-surface text-xs uppercase tracking-wide text-muted"><tr><th className="px-5 py-3">Course</th><th className="px-5 py-3">Category</th><th className="px-5 py-3">Lengths</th><th className="px-5 py-3">Upcoming</th><th className="px-5 py-3">Status</th><th className="px-5 py-3"><span className="sr-only">Actions</span></th></tr></thead>
          <tbody className="divide-y divide-line">
            {courses.map((c) => (
              <tr key={c.id}>
                <td className="px-5 py-3.5 font-semibold">{c.name}</td>
                <td className="px-5 py-3.5 text-muted">{c.category}</td>
                <td className="px-5 py-3.5">{c.lengths.length ? c.lengths.map((l) => lengthLabel[l]).join(", ") : <span className="text-muted">—</span>}</td>
                <td className="px-5 py-3.5">{c.upcoming}</td>
                <td className="px-5 py-3.5"><span className={`rounded-full px-2.5 py-1 text-xs font-semibold ${tone[c.status] ?? ""}`}>{c.status}</span></td>
                <td className="px-5 py-3.5 text-right">{canEdit && <Link href={`/admin/courses/${c.id}`} className="font-semibold text-brand-700 hover:underline">Edit</Link>}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}
