import type { Metadata } from "next";
import Link from "next/link";
import { notFound } from "next/navigation";
import { CourseForm } from "@/components/admin/course-form";
import { requireStaff } from "@/lib/auth/session";
import { getRepo } from "@/lib/repo";

export const metadata: Metadata = { title: "Edit course" };
export const dynamic = "force-dynamic";
export const maxDuration = 60; // background FAQ generation after saving

export default async function EditCourse({ params, searchParams }: { params: Promise<{ id: string }>; searchParams: Promise<{ saved?: string }> }) {
  await requireStaff(["ADMIN", "EDITOR"]);
  const { id } = await params;
  const { saved } = await searchParams;
  const repo = await getRepo();
  const [course, categories] = await Promise.all([repo.getCourseForEdit(id), repo.listCategoryOptions()]);
  if (!course) notFound();
  return (
    <div className="mx-auto max-w-3xl">
      <Link href="/admin/courses" className="text-sm font-medium text-brand-700 hover:underline">← All courses</Link>
      <div className="mb-6 mt-2 flex flex-wrap items-center justify-between gap-3">
        <h1 className="text-2xl font-bold">{course.name}</h1>
        <div className="flex gap-4 text-sm font-semibold text-brand-700"><Link href={`/admin/faqs?course=${course.id}`} className="hover:underline">Manage FAQs</Link>{course.status === "PUBLISHED" && <Link href={`/courses/${course.slug}`} target="_blank" className="hover:underline">View on website ↗</Link>}</div>
      </div>
      <CourseForm key={saved ? "saved" : "edit"} course={course} categories={categories} saved={!!saved} />
    </div>
  );
}
