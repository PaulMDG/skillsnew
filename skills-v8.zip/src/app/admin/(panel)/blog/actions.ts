"use server";

import { revalidatePath } from "next/cache";
import { redirect } from "next/navigation";
import { requireStaff } from "@/lib/auth/session";
import { getStaffStore } from "@/lib/auth/store";
import { postFormSchema, toPostInput } from "@/lib/blog/schema";
import { getRepo } from "@/lib/repo";
import { revalidateBlog } from "@/lib/revalidate";
import type { FormState } from "@/lib/validation";

export async function savePostAction(_: FormState, fd: FormData): Promise<FormState> {
  const staff = await requireStaff(["ADMIN", "EDITOR", "MARKETING"]); // content marketing: all three roles may write
  const parsed = postFormSchema.safeParse(Object.fromEntries(fd));
  if (!parsed.success) return { status: "error", message: "Please fix the highlighted fields.", fieldErrors: parsed.error.flatten().fieldErrors };
  const conv = toPostInput(parsed.data);
  if (!conv.ok) return { status: "error", message: "Please fix the highlighted fields.", fieldErrors: conv.fieldErrors };

  const repo = await getRepo();
  const before = conv.value.id ? await repo.getPostForEdit(conv.value.id) : null;
  const res = await repo.savePost(conv.value, { id: staff.id, name: staff.name });
  if (!res.ok) return { status: "error", message: res.error, fieldErrors: res.fieldErrors };

  await (await getStaffStore()).audit({ actorId: staff.id, action: conv.value.id ? "post.update" : "post.create", entity: "post", entityId: res.id, meta: { title: conv.value.title, status: conv.value.status } });
  revalidateBlog(res.slug, [...conv.value.tags, ...(before?.tags ?? [])]);
  revalidatePath("/admin/blog");
  redirect(`/admin/blog/${res.id}?saved=1`);
}
