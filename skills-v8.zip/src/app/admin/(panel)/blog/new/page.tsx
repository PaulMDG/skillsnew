import type { Metadata } from "next";
import Link from "next/link";
import { PostForm } from "@/components/admin/post-form";
import { requireStaff } from "@/lib/auth/session";

export const metadata: Metadata = { title: "New post" };
export const dynamic = "force-dynamic";

export default async function NewPost() {
  await requireStaff(["ADMIN", "EDITOR", "MARKETING"]);
  return (
    <div className="mx-auto max-w-3xl">
      <Link href="/admin/blog" className="text-sm font-medium text-brand-700 hover:underline">← All posts</Link>
      <h1 className="mb-6 mt-2 text-2xl font-bold">New post</h1>
      <PostForm />
    </div>
  );
}
