import type { Metadata } from "next";
import Link from "next/link";
import { requireStaff } from "@/lib/auth/session";
import { formatPostDate } from "@/lib/format";
import { getRepo } from "@/lib/repo";
import type { PublishStatusT } from "@/lib/types";

export const metadata: Metadata = { title: "Blog" };
export const dynamic = "force-dynamic";

const TABS: { key?: PublishStatusT; label: string }[] = [{ label: "All" }, { key: "DRAFT", label: "Drafts" }, { key: "PUBLISHED", label: "Published" }, { key: "ARCHIVED", label: "Archived" }];
const tone: Record<string, string> = { PUBLISHED: "bg-brand-50 text-brand-800", DRAFT: "bg-amber-50 text-amber-800", ARCHIVED: "bg-slate-100 text-slate-600" };

export default async function AdminBlog({ searchParams }: { searchParams: Promise<{ status?: string; q?: string }> }) {
  await requireStaff(["ADMIN", "EDITOR", "MARKETING"]);
  const { status, q } = await searchParams;
  const st = TABS.find((t) => t.key === status)?.key;
  const posts = await (await getRepo()).adminListPosts({ status: st, q: q?.slice(0, 80), limit: 200 });
  return (
    <div className="mx-auto max-w-6xl">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div><h1 className="text-2xl font-bold">Blog</h1><p className="text-sm text-muted">Write articles that bring people to your courses. Published posts appear on the website, in the RSS feed and sitemap.</p></div>
        <Link href="/admin/blog/new" className="rounded-lg bg-brand-600 px-4 py-2 text-sm font-semibold text-white hover:bg-brand-700">New post</Link>
      </div>
      <div className="mt-6 flex flex-wrap items-center gap-2">
        {TABS.map((t) => <Link key={t.label} href={t.key ? `/admin/blog?status=${t.key}` : "/admin/blog"} className={`rounded-full px-4 py-1.5 text-sm font-semibold ${st === t.key ? "bg-brand-600 text-white" : "border border-line text-muted hover:border-brand-500"}`}>{t.label}</Link>)}
        <form action="/admin/blog" className="ml-auto">{st && <input type="hidden" name="status" value={st} />}<input name="q" defaultValue={q} placeholder="Search titles" className="rounded-lg border border-line px-3 py-1.5 text-sm" /></form>
      </div>
      <div className="mt-4 overflow-x-auto rounded-2xl border border-line bg-white">
        <table className="w-full min-w-[820px] text-left text-sm">
          <thead className="bg-surface text-xs uppercase tracking-wide text-muted"><tr><th className="px-5 py-3">Title</th><th className="px-5 py-3">Status</th><th className="px-5 py-3">Publish date</th><th className="px-5 py-3">Topics</th><th className="px-5 py-3">Author</th><th className="px-5 py-3"><span className="sr-only">Actions</span></th></tr></thead>
          <tbody className="divide-y divide-line">
            {posts.length === 0 && <tr><td colSpan={6} className="px-5 py-10 text-center text-muted">No posts yet.</td></tr>}
            {posts.map((p) => (
              <tr key={p.id}>
                <td className="px-5 py-3.5"><Link href={`/admin/blog/${p.id}`} className="font-semibold hover:text-brand-700 hover:underline">{p.title}</Link></td>
                <td className="px-5 py-3.5"><span className={`rounded-full px-2.5 py-1 text-xs font-semibold ${tone[p.status]}`}>{p.status}</span>{p.scheduled && <span className="ml-1.5 rounded-full bg-sky-50 px-2.5 py-1 text-xs font-semibold text-sky-800">SCHEDULED</span>}</td>
                <td className="px-5 py-3.5 text-muted">{p.publishedAt ? formatPostDate(p.publishedAt) : "—"}</td>
                <td className="px-5 py-3.5 text-muted">{p.tags.join(", ") || "—"}</td>
                <td className="px-5 py-3.5 text-muted">{p.author || "—"}</td>
                <td className="whitespace-nowrap px-5 py-3.5 text-right text-xs font-semibold"><Link href={`/admin/blog/${p.id}/preview`} className="mr-3 text-brand-700 hover:underline">Preview</Link><Link href={`/admin/blog/${p.id}`} className="text-brand-700 hover:underline">Edit</Link></td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}
