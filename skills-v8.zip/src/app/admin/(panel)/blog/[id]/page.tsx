import type { Metadata } from "next";
import Link from "next/link";
import { notFound } from "next/navigation";
import { PostForm } from "@/components/admin/post-form";
import { requireStaff } from "@/lib/auth/session";
import { getRepo } from "@/lib/repo";

export const metadata: Metadata = { title: "Edit post" };
export const dynamic = "force-dynamic";

export default async function EditPost({ params, searchParams }: { params: Promise<{ id: string }>; searchParams: Promise<{ saved?: string }> }) {
  await requireStaff(["ADMIN", "EDITOR", "MARKETING"]);
  const { id } = await params;
  const { saved } = await searchParams;
  const post = await (await getRepo()).getPostForEdit(id);
  if (!post) notFound();
  const live = post.status === "PUBLISHED" && (!post.publishedAt || new Date(post.publishedAt) <= new Date());
  return (
    <div className="mx-auto max-w-3xl">
      <Link href="/admin/blog" className="text-sm font-medium text-brand-700 hover:underline">← All posts</Link>
      <div className="mb-6 mt-2 flex flex-wrap items-center justify-between gap-3">
        <h1 className="text-2xl font-bold">{post.title}</h1>
        {live && <Link href={`/blog/${post.slug}`} target="_blank" className="text-sm font-semibold text-brand-700 hover:underline">View on website ↗</Link>}
      </div>
      {post.status === "PUBLISHED" && !live && <p className="mb-4 rounded-lg bg-sky-50 px-4 py-3 text-sm font-medium text-sky-900">Scheduled: this post goes live automatically at its publish time.</p>}
      <PostForm key={saved ? "saved" : "edit"} post={post} saved={!!saved} />
    </div>
  );
}
