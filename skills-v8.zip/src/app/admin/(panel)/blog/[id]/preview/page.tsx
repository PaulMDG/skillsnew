import type { Metadata } from "next";
import { notFound } from "next/navigation";
import { PostArticle } from "@/components/blog/post-article";
import { requireStaff } from "@/lib/auth/session";
import { getRepo } from "@/lib/repo";

export const metadata: Metadata = { title: "Preview post" };
export const dynamic = "force-dynamic";

export default async function PreviewPost({ params }: { params: Promise<{ id: string }> }) {
  await requireStaff(["ADMIN", "EDITOR", "MARKETING"]);
  const post = await (await getRepo()).getPostPreview((await params).id);
  if (!post) notFound();
  return <PostArticle post={post} preview />;
}
