"use server";

import { revalidatePath } from "next/cache";
import { revalidatePublicSite } from "@/lib/revalidate";
import { z } from "zod";
import { requireStaff } from "@/lib/auth/session";
import { getStaffStore } from "@/lib/auth/store";
import { getRepo } from "@/lib/repo";
import type { Length, PriceMap } from "@/lib/types";

const money = z.preprocess((v) => (v === "" || v == null ? undefined : Number(String(v).replace(/,/g, ""))), z.number().min(0).max(100_000_000).optional());
const schema = z.object({ courseId: z.string().min(1), p5Kes: money, p5Usd: money, p10Kes: money, p10Usd: money });

export type PriceState = { courseId?: string; ok?: boolean; error?: string };

export async function savePricesAction(_: PriceState, fd: FormData): Promise<PriceState> {
  const staff = await requireStaff(["ADMIN", "EDITOR"]);
  const p = schema.safeParse(Object.fromEntries(fd));
  if (!p.success) return { courseId: String(fd.get("courseId") ?? ""), error: "Enter valid, non-negative amounts" };
  const d = p.data;
  const pm = (kes?: number, usd?: number): PriceMap | undefined => (kes == null && usd == null ? undefined : { ...(kes != null ? { KES: kes } : {}), ...(usd != null ? { USD: usd } : {}) });
  const prices: Partial<Record<Length, PriceMap>> = {};
  const a = pm(d.p5Kes, d.p5Usd), b = pm(d.p10Kes, d.p10Usd);
  if (a) prices.FIVE_DAY = a;
  if (b) prices.TEN_DAY = b;
  await (await getRepo()).setCoursePrices(d.courseId, prices);
  await (await getStaffStore()).audit({ actorId: staff.id, action: "price.update", entity: "course", entityId: d.courseId, meta: prices });
  const course = await (await getRepo()).getCourseForEdit(d.courseId);
  await revalidatePublicSite({ courseSlug: course?.slug });
  revalidatePath("/admin/prices");
  return { courseId: d.courseId, ok: true };
}
