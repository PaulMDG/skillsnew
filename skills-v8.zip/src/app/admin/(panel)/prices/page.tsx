import type { Metadata } from "next";
import { PriceRow } from "@/components/admin/price-row";
import { requireStaff } from "@/lib/auth/session";
import { getRepo } from "@/lib/repo";

export const metadata: Metadata = { title: "Manage prices" };
export const dynamic = "force-dynamic";

export default async function PricesPage() {
  await requireStaff(["ADMIN", "EDITOR"]);
  const rows = await (await getRepo()).listPriceRows();
  return (
    <div className="mx-auto max-w-6xl">
      <h1 className="text-2xl font-bold">Manage prices</h1>
      <p className="text-sm text-muted">Update fees per course. Changes appear on the website, brochures and emails straight away. Empty = “On request”.</p>
      <div className="mt-6 overflow-x-auto rounded-2xl border border-line bg-white">
        <table className="w-full min-w-[900px] text-left text-sm">
          <thead className="bg-surface text-xs uppercase tracking-wide text-muted">
            <tr><th className="px-5 py-3">Course</th><th className="px-3 py-3">5-day KES</th><th className="px-3 py-3">5-day USD</th><th className="px-3 py-3">10-day KES</th><th className="px-3 py-3">10-day USD</th><th className="px-3 py-3"><span className="sr-only">Save</span></th></tr>
          </thead>
          <tbody className="divide-y divide-line">{rows.map((r) => <PriceRow key={r.courseId} {...r} />)}</tbody>
        </table>
      </div>
    </div>
  );
}
