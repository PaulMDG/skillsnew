"use server";

import { revalidatePath } from "next/cache";
import { redirect } from "next/navigation";
import { z } from "zod";
import { requireStaff } from "@/lib/auth/session";
import { getStaffStore } from "@/lib/auth/store";
import { openAiConfigured } from "@/lib/faq/openai";
import { faqService } from "@/lib/faq/service";
import { getRepo } from "@/lib/repo";
import { revalidatePublicSite } from "@/lib/revalidate";

const ROLES = ["ADMIN", "EDITOR"] as const;
const back = (v: FormDataEntryValue | null) => (typeof v === "string" && v.startsWith("/admin/faqs") ? v : "/admin/faqs");
const withParams = (path: string, p: Record<string, string | number>) => `${path}${path.includes("?") ? "&" : "?"}${new URLSearchParams(Object.entries(p).map(([k, v]) => [k, String(v)]))}`;
const audit = async (actorId: string, action: string, entityId?: string, meta?: Record<string, unknown>) =>
  (await getStaffStore()).audit({ actorId, action, entity: "faq", entityId, meta });

/** Generates FAQs for the next courses that need them (new courses, or ones whose text changed). */
export async function generateMissingAction() {
  const staff = await requireStaff([...ROLES]);
  if (!openAiConfigured()) redirect(withParams("/admin/faqs", { error: "no-key" }));
  const r = await (await faqService()).runBatch({ limit: Number(process.env.FAQ_MAX_PER_RUN ?? 5), budgetMs: 45_000 });
  await audit(staff.id, "faq.generate_batch", undefined, r);
  revalidatePath("/admin/faqs");
  redirect(withParams("/admin/faqs", { generated: r.generated, failed: r.failed, left: Math.max(0, r.needing - r.attempted) }));
}

export async function regenerateCourseAction(fd: FormData) {
  const staff = await requireStaff([...ROLES]);
  const courseId = String(fd.get("courseId") ?? "");
  const to = back(fd.get("back"));
  if (!openAiConfigured()) redirect(withParams(to, { error: "no-key" }));
  const r = await (await faqService()).generateForCourse(courseId, { force: true });
  await audit(staff.id, "faq.regenerate", courseId, r);
  revalidatePath("/admin/faqs");
  redirect(withParams("/admin/faqs", r.status === "generated" ? { status: "DRAFT", course: courseId, made: r.count } : { course: courseId, failed_reason: ("reason" in r ? r.reason : "").slice(0, 240) }));
}

const review = z.object({
  id: z.string().min(1),
  question: z.string().trim().min(10, "The question is too short").max(200, "The question is too long"),
  answer: z.string().trim().min(20, "The answer is too short").max(1500, "The answer is too long"),
});

type Intent = "save" | "approve" | "reject" | "draft";

async function applyReview(fd: FormData, intent: Intent) {
  const staff = await requireStaff([...ROLES]);
  const to = back(fd.get("back"));
  const p = review.safeParse(Object.fromEntries(fd));
  if (!p.success) redirect(withParams(to, { error: p.error.issues[0].message }));
  const { id, question, answer } = p.data;
  const status = intent === "approve" ? "PUBLISHED" : intent === "reject" ? "REJECTED" : intent === "draft" ? "DRAFT" : undefined;
  const res = await (await getRepo()).updateFaq(id, { question: question.endsWith("?") ? question : `${question}?`, answer, ...(status ? { status } : {}) });
  if (res.ok) { await audit(staff.id, `faq.${intent}`, id); await revalidatePublicSite({ courseSlug: res.courseSlug }); }
  revalidatePath("/admin/faqs");
  redirect(res.ok ? to : withParams(to, { error: res.error }));
}

// One action per button: React does not send the clicked button's name/value, so the intent cannot ride in the form data.
export async function saveFaqAction(fd: FormData) { await applyReview(fd, "save"); }
export async function approveFaqAction(fd: FormData) { await applyReview(fd, "approve"); }
export async function rejectFaqAction(fd: FormData) { await applyReview(fd, "reject"); }
export async function draftFaqAction(fd: FormData) { await applyReview(fd, "draft"); }

export async function approveAllAction(fd: FormData) {
  const staff = await requireStaff([...ROLES]);
  const courseId = String(fd.get("courseId") ?? "");
  const res = await (await getRepo()).setCourseFaqsStatus(courseId, "DRAFT", "PUBLISHED");
  if (res.ok) { await audit(staff.id, "faq.approve_all", courseId, { count: res.count }); await revalidatePublicSite({ courseSlug: res.courseSlug }); }
  revalidatePath("/admin/faqs");
  redirect(back(fd.get("back")));
}

const add = z.object({ courseId: z.string().min(1, "Choose a course"), question: review.shape.question, answer: review.shape.answer });
export async function addFaqAction(fd: FormData) {
  const staff = await requireStaff([...ROLES]);
  const p = add.safeParse(Object.fromEntries(fd));
  if (!p.success) redirect(withParams("/admin/faqs", { error: p.error.issues[0].message }));
  const q = p.data.question.endsWith("?") ? p.data.question : `${p.data.question}?`;
  const res = await (await getRepo()).addFaq(p.data.courseId, q, p.data.answer);
  if (res.ok) { await audit(staff.id, "faq.add", p.data.courseId); await revalidatePublicSite({ courseSlug: res.courseSlug }); }
  revalidatePath("/admin/faqs");
  redirect(withParams("/admin/faqs", res.ok ? { status: "PUBLISHED", course: p.data.courseId, added: 1 } : { error: res.error }));
}
