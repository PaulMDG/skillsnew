import type { Metadata } from "next";
import Link from "next/link";
import { requireStaff } from "@/lib/auth/session";
import { openAiConfigured } from "@/lib/faq/openai";
import { faqService } from "@/lib/faq/service";
import { getRepo } from "@/lib/repo";
import type { AdminFaqRow, FaqStatusT } from "@/lib/types";
import { addFaqAction, approveAllAction, approveFaqAction, draftFaqAction, generateMissingAction, regenerateCourseAction, rejectFaqAction, saveFaqAction } from "./actions";

export const metadata: Metadata = { title: "FAQs" };
export const dynamic = "force-dynamic";
export const maxDuration = 60; // generating calls OpenAI (a few seconds per course)

const TABS: { key: FaqStatusT; label: string }[] = [{ key: "DRAFT", label: "Awaiting review" }, { key: "PUBLISHED", label: "Published" }, { key: "REJECTED", label: "Rejected" }];
const field = "w-full rounded-lg border border-line px-3 py-2 text-sm";
type SP = { status?: string; course?: string; generated?: string; failed?: string; left?: string; made?: string; added?: string; error?: string; failed_reason?: string };

export default async function FaqsPage({ searchParams }: { searchParams: Promise<SP> }) {
  const staff = await requireStaff(["ADMIN", "EDITOR", "MARKETING"]);
  const canEdit = staff.role !== "MARKETING";
  const sp = await searchParams;
  const status = TABS.find((t) => t.key === sp.status)?.key ?? "DRAFT";
  const repo = await getRepo();
  const svc = await faqService();
  const [counts, courses, rows, needing] = await Promise.all([
    repo.faqCounts(), repo.adminListCourses(), repo.listFaqsAdmin({ status, courseId: sp.course || undefined, limit: 300 }), svc.needing(),
  ]);
  const configured = openAiConfigured();
  const here = `/admin/faqs?status=${status}${sp.course ? `&course=${encodeURIComponent(sp.course)}` : ""}`;
  const groups = Object.values(rows.reduce<Record<string, AdminFaqRow[]>>((m, r) => ((m[r.courseId] ??= []).push(r), m), {}));
  const count = (s: FaqStatusT) => (s === "DRAFT" ? counts.draft : s === "PUBLISHED" ? counts.published : counts.rejected);

  return (
    <div className="mx-auto max-w-5xl">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div><h1 className="text-2xl font-bold">Course FAQs</h1><p className="text-sm text-muted">AI drafts the questions people ask; you approve what goes live. Approved FAQs also feed Google and AI search answers.</p></div>
        {canEdit && <form action={generateMissingAction}><button disabled={!configured || needing.length === 0} className="rounded-lg bg-brand-600 px-4 py-2 text-sm font-semibold text-white hover:bg-brand-700 disabled:cursor-not-allowed disabled:opacity-50">{needing.length ? `Generate for ${Math.min(needing.length, Number(process.env.FAQ_MAX_PER_RUN ?? 5))} of ${needing.length} courses` : "All courses have FAQs"}</button></form>}
      </div>

      {!configured && <p role="alert" className="mt-4 rounded-lg bg-amber-50 px-4 py-3 text-sm font-medium text-amber-900">OpenAI is not connected. Set <code>OPENAI_API_KEY</code> to enable generation. You can still write and edit FAQs by hand.</p>}
      {sp.generated && <p role="status" className="mt-4 rounded-lg bg-brand-50 px-4 py-3 text-sm font-medium text-brand-800">Generated for {sp.generated} course(s){Number(sp.failed) ? `, ${sp.failed} failed (see the run log)` : ""}{Number(sp.left) ? `. ${sp.left} more waiting: run it again.` : "."} Review them below.</p>}
      {sp.made && <p role="status" className="mt-4 rounded-lg bg-brand-50 px-4 py-3 text-sm font-medium text-brand-800">{sp.made} new FAQs are ready for review.</p>}
      {sp.added && <p role="status" className="mt-4 rounded-lg bg-brand-50 px-4 py-3 text-sm font-medium text-brand-800">FAQ added and published.</p>}
      {sp.failed_reason && <p role="alert" className="mt-4 rounded-lg bg-red-50 px-4 py-3 text-sm font-medium text-red-700">Could not generate: {sp.failed_reason}</p>}
      {sp.error && <p role="alert" className="mt-4 rounded-lg bg-red-50 px-4 py-3 text-sm font-medium text-red-700">{sp.error === "no-key" ? "OpenAI is not connected (OPENAI_API_KEY)." : sp.error}</p>}

      <div className="mt-6 flex flex-wrap items-center gap-2">
        {TABS.map((t) => <Link key={t.key} href={`/admin/faqs?status=${t.key}${sp.course ? `&course=${encodeURIComponent(sp.course)}` : ""}`} className={`rounded-full px-4 py-1.5 text-sm font-semibold ${status === t.key ? "bg-brand-600 text-white" : "border border-line text-muted hover:border-brand-500"}`}>{t.label} ({count(t.key)})</Link>)}
        <form action="/admin/faqs" className="ml-auto flex gap-2"><input type="hidden" name="status" value={status} />
          <select name="course" defaultValue={sp.course ?? ""} aria-label="Filter by course" className="rounded-lg border border-line px-3 py-2 text-sm"><option value="">All courses</option>{courses.map((c) => <option key={c.id} value={c.id}>{c.name}</option>)}</select>
          <button className="rounded-lg border border-line px-3 py-2 text-sm font-semibold hover:border-brand-500">Filter</button></form>
      </div>
      <p className="mt-2 text-xs text-muted">{counts.coursesWithPublished} courses have published FAQs · {needing.length} need generating (new, or their text changed).</p>

      <div className="mt-4 space-y-6">
        {groups.length === 0 && <p className="rounded-2xl border border-dashed border-line p-10 text-center text-sm text-muted">Nothing here.{status === "DRAFT" && " Generated FAQs will wait here for your review."}</p>}
        {groups.map((g) => (
          <section key={g[0].courseId} className="rounded-2xl border border-line bg-white">
            <div className="flex flex-wrap items-center justify-between gap-3 border-b border-line px-5 py-4">
              <div><Link href={`/admin/courses/${g[0].courseId}`} className="font-bold hover:underline">{g[0].course}</Link><span className="ml-2 text-sm text-muted">{g.length} FAQ{g.length === 1 ? "" : "s"}</span></div>
              {canEdit && <div className="flex gap-2">
                {status === "DRAFT" && <form action={approveAllAction}><input type="hidden" name="courseId" value={g[0].courseId} /><input type="hidden" name="back" value={here} /><button className="rounded-lg bg-brand-600 px-3 py-1.5 text-xs font-semibold text-white hover:bg-brand-700">Approve all {g.length}</button></form>}
                <form action={regenerateCourseAction}><input type="hidden" name="courseId" value={g[0].courseId} /><input type="hidden" name="back" value={here} /><button disabled={!configured} className="rounded-lg border border-line px-3 py-1.5 text-xs font-semibold hover:border-brand-500 disabled:opacity-50">Regenerate</button></form>
              </div>}
            </div>
            <ul className="divide-y divide-line">
              {g.map((f) => (
                <li key={f.id} className="p-5">
                  <form className="space-y-3">
                    <input type="hidden" name="id" value={f.id} /><input type="hidden" name="back" value={here} />
                    <input name="question" defaultValue={f.question} readOnly={!canEdit} aria-label="Question" className={`${field} font-semibold`} />
                    <textarea name="answer" defaultValue={f.answer} readOnly={!canEdit} rows={3} aria-label="Answer" className={field} />
                    <div className="flex flex-wrap items-center gap-2">
                      {canEdit && <>
                        {f.status !== "PUBLISHED" && <button formAction={approveFaqAction} className="rounded-lg bg-brand-600 px-3 py-1.5 text-xs font-semibold text-white hover:bg-brand-700">Approve &amp; publish</button>}
                        <button formAction={saveFaqAction} className="rounded-lg border border-line px-3 py-1.5 text-xs font-semibold hover:border-brand-500">{f.status === "PUBLISHED" ? "Save changes" : "Save edits"}</button>
                        {f.status !== "REJECTED" && <button formAction={rejectFaqAction} className="rounded-lg border border-red-200 px-3 py-1.5 text-xs font-semibold text-red-700 hover:bg-red-50">{f.status === "PUBLISHED" ? "Unpublish & reject" : "Reject"}</button>}
                        {f.status !== "DRAFT" && <button formAction={draftFaqAction} className="rounded-lg border border-line px-3 py-1.5 text-xs font-semibold hover:border-brand-500">Back to review</button>}
                      </>}
                      <span className="ml-auto text-xs text-muted">{f.aiGenerated ? `AI-written${f.model ? ` (${f.model})` : ""}` : "Written by staff"}</span>
                    </div>
                  </form>
                </li>
              ))}
            </ul>
          </section>
        ))}
      </div>

      {canEdit && (
        <details className="mt-8 rounded-2xl border border-line bg-white p-5">
          <summary className="cursor-pointer font-bold">Add an FAQ by hand</summary>
          <form action={addFaqAction} className="mt-4 space-y-3">
            <select name="courseId" required defaultValue={sp.course ?? ""} aria-label="Course" className={field}><option value="" disabled>Choose a course…</option>{courses.map((c) => <option key={c.id} value={c.id}>{c.name}</option>)}</select>
            <input name="question" required placeholder="Question" className={field} /><textarea name="answer" required rows={3} placeholder="Answer" className={field} />
            <button className="rounded-lg bg-brand-600 px-4 py-2 text-sm font-semibold text-white hover:bg-brand-700">Add &amp; publish</button>
          </form>
        </details>
      )}
    </div>
  );
}
