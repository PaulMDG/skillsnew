import type { Metadata } from "next";
import { getRepo } from "@/lib/repo";
import { requireStaff } from "@/lib/auth/session";
import Link from "next/link";
import { generateSchedulesAction } from "../actions";

export const metadata: Metadata = { title: "Unscheduled courses" };
export const dynamic = "force-dynamic";

export default async function Unscheduled() {
  await requireStaff(["ADMIN", "EDITOR"]);
  const rows = await (await getRepo()).listUnscheduled();
  return (
    <div className="mx-auto max-w-5xl">
      <h1 className="text-2xl font-bold">Unscheduled courses</h1>
      <p className="text-sm text-muted">Courses with no upcoming schedules. Generating creates 52 weekly (5-day) or 26 fortnightly (10-day) Monday–Friday schedules.</p>
      <div className="mt-6 overflow-x-auto rounded-2xl border border-line bg-white">
        {rows.length === 0 ? <p className="p-8 text-center text-sm text-muted">Every course is scheduled 🎉</p> : (
          <table className="w-full min-w-[640px] text-left text-sm">
            <thead className="bg-surface text-xs uppercase tracking-wide text-muted"><tr><th className="px-5 py-3">Course</th><th className="px-5 py-3">Category</th><th className="px-5 py-3">Reason</th><th className="px-5 py-3"><span className="sr-only">Action</span></th></tr></thead>
            <tbody className="divide-y divide-line">
              {rows.map((r) => (
                <tr key={r.id}>
                  <td className="px-5 py-3.5 font-semibold">{r.name}</td>
                  <td className="px-5 py-3.5 text-muted">{r.category}</td>
                  <td className="px-5 py-3.5"><span className="rounded-full bg-amber-50 px-2.5 py-1 text-xs font-semibold text-amber-800">{r.reason}</span></td>
                  <td className="px-5 py-3.5 text-right">
                    {r.reason === "No course length selected"
                      ? <Link href={`/admin/courses/${r.id}`} className="rounded-lg border border-brand-600 px-3.5 py-1.5 text-xs font-semibold text-brand-700 hover:bg-brand-50">Choose length</Link>
                      : <form action={generateSchedulesAction}><input type="hidden" name="courseId" value={r.id} />
                          <button className="rounded-lg border border-brand-600 px-3.5 py-1.5 text-xs font-semibold text-brand-700 hover:bg-brand-50">Generate schedules</button>
                        </form>}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </div>
    </div>
  );
}
