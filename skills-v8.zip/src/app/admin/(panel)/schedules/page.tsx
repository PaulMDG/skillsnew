import type { Metadata } from "next";
import Link from "next/link";
import { ScheduleForm } from "@/components/admin/schedule-form";
import { requireStaff } from "@/lib/auth/session";
import { getRepo } from "@/lib/repo";
import { formatRange, lengthLabel } from "@/lib/format";
import { nairobiToday, toISODate } from "@/lib/schedules/dates";
import { setScheduleStatusAction } from "./actions";

export const metadata: Metadata = { title: "Schedules" };
export const dynamic = "force-dynamic";

export default async function SchedulesPage({ searchParams }: { searchParams: Promise<{ course?: string; past?: string }> }) {
  const staff = await requireStaff(["ADMIN", "EDITOR", "MARKETING"]);
  const canEdit = staff.role !== "MARKETING";
  const { course, past } = await searchParams;
  const repo = await getRepo();
  const [courses, rows] = await Promise.all([
    repo.adminListCourses(),
    repo.listSchedulesAdmin({ courseId: course || undefined, from: past ? undefined : toISODate(nairobiToday()), limit: 150 }),
  ]);
  const schedulable = courses.filter((c) => c.lengths.length);

  return (
    <div className="mx-auto max-w-6xl">
      <h1 className="text-2xl font-bold">Training schedule</h1>
      <p className="text-sm text-muted">52 weekly (5-day) and 26 fortnightly (10-day) Monday–Friday schedules are kept ahead for every course automatically.</p>
      {canEdit && <div className="mt-6"><ScheduleForm courses={schedulable.map((c) => ({ id: c.id, name: c.name }))} /></div>}

      <form action="/admin/schedules" className="mt-6 flex flex-wrap items-center gap-3">
        <select name="course" defaultValue={course ?? ""} aria-label="Filter by course" className="rounded-lg border border-line px-3 py-2 text-sm"><option value="">All courses</option>{courses.map((c) => <option key={c.id} value={c.id}>{c.name}</option>)}</select>
        <label className="flex items-center gap-2 text-sm"><input type="checkbox" name="past" value="1" defaultChecked={!!past} className="accent-brand-600" />Include past</label>
        <button className="rounded-lg border border-line px-4 py-2 text-sm font-semibold hover:border-brand-500">Filter</button>
        <span className="text-sm text-muted">{rows.length}{rows.length === 150 ? "+" : ""} schedules shown</span>
      </form>

      <div className="mt-4 overflow-x-auto rounded-2xl border border-line bg-white">
        <table className="w-full min-w-[820px] text-left text-sm">
          <thead className="bg-surface text-xs uppercase tracking-wide text-muted"><tr><th className="px-5 py-3">Dates</th><th className="px-5 py-3">Course</th><th className="px-5 py-3">Length</th><th className="px-5 py-3">Registered</th><th className="px-5 py-3">Status</th><th className="px-5 py-3"><span className="sr-only">Actions</span></th></tr></thead>
          <tbody className="divide-y divide-line">
            {rows.length === 0 && <tr><td colSpan={6} className="px-5 py-10 text-center text-muted">No schedules match.</td></tr>}
            {rows.map((r) => (
              <tr key={r.id} className={r.status === "CANCELLED" ? "bg-slate-50 text-muted" : ""}>
                <td className="px-5 py-3 font-semibold">{formatRange(r.startDate, r.endDate)}{r.legacy && <span className="ml-2 rounded bg-slate-100 px-1.5 py-0.5 text-[10px] font-bold text-slate-600">OLD SYSTEM</span>}{!r.generated && !r.legacy && <span className="ml-2 rounded bg-amber-50 px-1.5 py-0.5 text-[10px] font-bold text-amber-800">MANUAL</span>}</td>
                <td className="px-5 py-3"><Link href={`/admin/courses/${r.courseId}`} className="hover:underline">{r.course}</Link></td>
                <td className="px-5 py-3">{lengthLabel[r.length]}</td>
                <td className="px-5 py-3">{r.registrations}</td>
                <td className="px-5 py-3"><span className={`rounded-full px-2.5 py-1 text-xs font-semibold ${r.status === "OPEN" ? "bg-brand-50 text-brand-800" : "bg-slate-200 text-slate-700"}`}>{r.status}</span></td>
                <td className="px-5 py-3 text-right">
                  {canEdit && !r.legacy && (
                    <form action={setScheduleStatusAction}><input type="hidden" name="id" value={r.id} /><input type="hidden" name="status" value={r.status === "OPEN" ? "CANCELLED" : "OPEN"} />
                      <button className="text-xs font-semibold text-brand-700 hover:underline" title={r.status === "OPEN" && r.registrations ? `${r.registrations} people are registered – contact them` : undefined}>{r.status === "OPEN" ? "Cancel" : "Reopen"}</button>
                    </form>
                  )}
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
      <p className="mt-3 text-xs text-muted">Cancelling hides a date from the website and brochures and a replacement is added at the end of the list. People already registered are not notified automatically.</p>
    </div>
  );
}
