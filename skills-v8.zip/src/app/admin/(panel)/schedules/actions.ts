"use server";

import { revalidatePath } from "next/cache";
import { z } from "zod";
import { requireStaff } from "@/lib/auth/session";
import { getStaffStore } from "@/lib/auth/store";
import { getRepo } from "@/lib/repo";
import { revalidatePublicSite } from "@/lib/revalidate";

export type ScheduleFormState = { ok?: boolean; error?: string };

const addSchema = z.object({
  courseId: z.string().min(1, "Choose a course"),
  length: z.enum(["FIVE_DAY", "TEN_DAY"]),
  startDate: z.string().regex(/^\d{4}-\d{2}-\d{2}$/, "Choose a start date"),
});

export async function addScheduleAction(_: ScheduleFormState, fd: FormData): Promise<ScheduleFormState> {
  const staff = await requireStaff(["ADMIN", "EDITOR"]);
  const p = addSchema.safeParse(Object.fromEntries(fd));
  if (!p.success) return { error: p.error.issues[0].message };
  const res = await (await getRepo()).addSchedule(p.data);
  if (!res.ok) return { error: res.error };
  await (await getStaffStore()).audit({ actorId: staff.id, action: "schedule.add", entity: "course", entityId: p.data.courseId, meta: p.data });
  await revalidatePublicSite({ courseSlug: res.courseSlug });
  revalidatePath("/admin/schedules");
  return { ok: true };
}

export async function setScheduleStatusAction(fd: FormData) {
  const staff = await requireStaff(["ADMIN", "EDITOR"]);
  const id = String(fd.get("id") ?? ""), status = fd.get("status") === "CANCELLED" ? "CANCELLED" : "OPEN";
  if (!id) return;
  const res = await (await getRepo()).setScheduleStatus(id, status);
  if (!res.ok) return;
  await (await getStaffStore()).audit({ actorId: staff.id, action: status === "CANCELLED" ? "schedule.cancel" : "schedule.reopen", entity: "schedule", entityId: id });
  await revalidatePublicSite({ courseSlug: res.courseSlug });
  revalidatePath("/admin/schedules");
}
