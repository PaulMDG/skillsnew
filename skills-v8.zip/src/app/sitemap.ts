import type { MetadataRoute } from "next";
import { getRepo } from "@/lib/repo";
import { abs } from "@/lib/site";

export const revalidate = 3600;

export default async function sitemap(): Promise<MetadataRoute.Sitemap> {
  const repo = await getRepo();
  const [courses, categories, posts, tags] = await Promise.all([repo.listCourses(), repo.listCategories(), repo.listPostSlugs(), repo.listPostTags()]);
  return [
    { url: abs("/"), changeFrequency: "weekly", priority: 1 },
    { url: abs("/courses"), changeFrequency: "daily", priority: 0.9 },
    { url: abs("/blog"), changeFrequency: "daily", priority: 0.7 },
    ...posts.map((p) => ({ url: abs(`/blog/${p.slug}`), lastModified: new Date(p.updatedAt), changeFrequency: "monthly" as const, priority: 0.6 })),
    ...tags.map((t) => ({ url: abs(`/blog/tag/${t.tag}`), changeFrequency: "weekly" as const, priority: 0.4 })),
    ...categories.map((c) => ({ url: abs(`/categories/${c.slug}`), changeFrequency: "weekly" as const, priority: 0.8 })),
    ...courses.map((c) => ({ url: abs(`/courses/${c.slug}`), changeFrequency: "weekly" as const, priority: 0.7 })),
  ];
}
