import { NextResponse } from "next/server";
import { getRepo } from "@/lib/repo";
import { buildBrochure } from "@/lib/brochure/pdf";
import { verifyBrochureLink } from "@/lib/brochure/links";
import { clientIp } from "@/lib/ip";
import { rateLimit } from "@/lib/rate-limit";

export const dynamic = "force-dynamic";

/** Signed, expiring link: only people who requested the brochure (form or email) can fetch it. */
export async function GET(req: Request, { params }: { params: Promise<{ slug: string }> }) {
  const { slug } = await params;
  const q = new URL(req.url).searchParams;
  const leadId = verifyBrochureLink(slug, { lead: q.get("lead"), exp: q.get("exp"), sig: q.get("sig") });
  if (!leadId) return new NextResponse("This brochure link is invalid or has expired. Please request the brochure again from the course page.", { status: 403 });
  if (!rateLimit(`brochure-dl:${await clientIp()}`, 30, 10 * 60_000)) return new NextResponse("Too many downloads. Try again shortly.", { status: 429 });

  const repo = await getRepo();
  const course = await repo.getCourse(slug);
  if (!course) return new NextResponse("Course not found", { status: 404 });

  const pdf = await buildBrochure(course); // built fresh: always the current description, dates and fees
  await repo.recordBrochureDownload(leadId);
  return new NextResponse(Buffer.from(pdf), {
    headers: {
      "Content-Type": "application/pdf",
      "Content-Disposition": `attachment; filename="${slug}-brochure.pdf"`,
      "Cache-Control": "private, no-store",
      "X-Robots-Tag": "noindex",
    },
  });
}
