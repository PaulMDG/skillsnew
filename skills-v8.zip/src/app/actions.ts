"use server";

import { after } from "next/server";
import { getRepo } from "@/lib/repo";
import { emailService } from "@/lib/email/service";
import { brochurePath } from "@/lib/brochure/links";
import { brochureSchema, registrationSchema, type FormState } from "@/lib/validation";
import { rateLimit } from "@/lib/rate-limit";
import { clientIp, hashIp } from "@/lib/ip";

const GENERIC_ERROR = "Something went wrong on our side. Please try again in a moment.";

export async function requestBrochure(_: FormState, fd: FormData): Promise<FormState> {
  const ip = await clientIp();
  if (!rateLimit(`brochure:${ip}`, 5)) return { status: "error", message: "Too many requests. Please try again in a few minutes." };

  const parsed = brochureSchema.safeParse(Object.fromEntries(fd));
  if (!parsed.success) {
    // A filled honeypot gets a fake success so bots learn nothing
    if (parsed.error.issues.some((i) => i.path[0] === "website")) return { status: "success", message: "Thank you!" };
    return { status: "error", message: "Please check the highlighted fields.", fieldErrors: parsed.error.flatten().fieldErrors };
  }
  try {
    const { website: _w, ...data } = parsed.data;
    const repo = await getRepo();
    const res = await repo.createLead({ ...data, ipHash: hashIp(ip) });
    if (!res.ok) return { status: "error", message: res.error };
    const downloadUrl = brochurePath(data.courseSlug, res.leadId);

    // The lead is saved and the download link works even if the email system is down.
    try {
      const mail = await emailService();
      const ids = await mail.captureLead({ leadId: res.leadId, email: data.email, name: data.fullName, phone: data.phone, courseSlug: data.courseSlug, courseName: res.courseName });
      after(async () => { for (const id of ids) await mail.deliverMessage(id); }); // send after the response is returned
    } catch (e) { console.error("brochure email queue failed", e); }
    return { status: "success", message: "Your brochure is downloading. A copy is also on its way to your inbox.", downloadUrl };
  } catch (e) {
    console.error("requestBrochure failed", e);
    return { status: "error", message: GENERIC_ERROR };
  }
}

export async function registerForCourse(_: FormState, fd: FormData): Promise<FormState> {
  const ip = await clientIp();
  if (!rateLimit(`register:${ip}`, 5)) return { status: "error", message: "Too many attempts. Please try again in a few minutes." };

  const parsed = registrationSchema.safeParse(Object.fromEntries(fd));
  if (!parsed.success) {
    if (parsed.error.issues.some((i) => i.path[0] === "website")) return { status: "success", message: "Registration received." };
    return { status: "error", message: "Please check the highlighted fields.", fieldErrors: parsed.error.flatten().fieldErrors };
  }
  try {
    const { website: _w, ...data } = parsed.data;
    const repo = await getRepo();
    const res = await repo.createRegistration(data);
    if (!res.ok) return { status: "error", message: res.error };
    try {
      const mail = await emailService();
      const { summary: r } = res;
      const ids = await mail.captureRegistration({ email: r.email, name: r.name, phone: r.phone, courseSlug: r.courseSlug, courseName: r.courseName, startDate: r.startDate, endDate: r.endDate, length: r.length, deliveryMode: r.deliveryMode, centerName: r.centerName, participants: r.participants });
      after(async () => { for (const id of ids) await mail.deliverMessage(id); });
    } catch (e) { console.error("registration email queue failed", e); }
    return { status: "success", message: "Registration received! We have emailed you a confirmation with the next steps." };
  } catch (e) {
    console.error("registerForCourse failed", e);
    return { status: "error", message: GENERIC_ERROR };
  }
}
