import { getRepo } from "@/lib/repo";
import { abs, site } from "@/lib/site";

export const revalidate = 3600;

/** Plain-text map of the site for AI assistants (llmstxt.org convention). */
export async function GET() {
  const repo = await getRepo();
  const [categories, courses, { posts }] = await Promise.all([repo.listCategories(), repo.listCourses(), repo.listPosts({ page: 1, pageSize: 30 })]);
  const body = [
    `# ${site.name}`,
    `> ${site.tagline}. Instructor-led 5-day and 10-day professional courses, classroom and online, with a new Monday start date every week (Monday–Friday only).`,
    "",
    "## Categories",
    ...categories.map((c) => `- [${c.name}](${abs(`/categories/${c.slug}`)}): ${c.description ?? ""}`.trim()),
    "",
    "## Courses",
    ...courses.map((c) => `- [${c.name}](${abs(`/courses/${c.slug}`)}): ${c.summary}`),
    "",
    ...(posts.length ? ["## Articles", ...posts.map((p) => `- [${p.title}](${abs(`/blog/${p.slug}`)}): ${p.excerpt}`), ""] : []),
    "## Contact",
    `- Email: ${site.email}`,
    `- Phone: ${site.phone}`,
  ].join("\n");
  return new Response(body, { headers: { "Content-Type": "text/plain; charset=utf-8" } });
}
