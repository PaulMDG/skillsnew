import Link from "next/link";
export default function NotFound() {
  return (
    <div className="mx-auto max-w-xl px-4 py-24 text-center">
      <p className="text-sm font-semibold text-brand-700">404</p>
      <h1 className="mt-2 text-3xl font-bold">We couldn&apos;t find that page</h1>
      <p className="mt-3 text-muted">It may have moved. Try searching our courses.</p>
      <Link href="/courses" className="mt-6 inline-block rounded-lg bg-brand-600 px-5 py-2.5 font-semibold text-white">Browse courses</Link>
    </div>
  );
}
