import { NextResponse, type NextRequest } from "next/server";
import { COOKIE_SESSION } from "@/lib/auth/config";
import { verifySession } from "@/lib/auth/tokens";

/**
 * First gate for /admin/*: requests without a validly signed, unexpired session are redirected to login.
 * (Whether the account is still active and the role allowed is re-checked against the database
 * in requireStaff(), which every page and server action calls.)
 */
const PUBLIC = ["/admin/login", "/admin/setup-2fa"];

export async function middleware(req: NextRequest) {
  const { pathname, search } = req.nextUrl;
  const isPublic = PUBLIC.some((p) => pathname === p || pathname.startsWith(`${p}/`));

  if (!isPublic) {
    const claims = await verifySession(req.cookies.get(COOKIE_SESSION)?.value);
    if (!claims) {
      const url = req.nextUrl.clone();
      url.pathname = "/admin/login";
      url.search = pathname === "/admin" ? "" : `?next=${encodeURIComponent(pathname + search)}`;
      return NextResponse.redirect(url);
    }
  }

  const res = NextResponse.next();
  res.headers.set("X-Robots-Tag", "noindex, nofollow");
  res.headers.set("Cache-Control", "no-store");
  res.headers.set("Content-Security-Policy", "frame-ancestors 'none'");
  return res;
}

export const config = { matcher: ["/admin/:path*"] };
