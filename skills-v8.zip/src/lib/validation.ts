import { z } from "zod";

const text = (max: number) => z.string().trim().max(max);
const optional = (max: number) => text(max).optional().transform((v) => (v ? v : undefined));

export const brochureSchema = z.object({
  courseSlug: text(250).min(1),
  fullName: text(100).min(2, "Please enter your full name"),
  email: z.string().trim().toLowerCase().email("Enter a valid email address").max(190),
  phone: optional(30),
  company: optional(150),
  country: optional(80),
  website: z.string().max(0).optional(), // honeypot – must stay empty
});

export const registrationSchema = z.object({
  courseSlug: text(250).min(1),
  scheduleId: text(60).min(1, "Please choose a start date"),
  firstName: text(80).min(1, "Required"),
  lastName: text(80).min(1, "Required"),
  email: z.string().trim().toLowerCase().email("Enter a valid email address").max(190),
  phone: text(30).min(7, "Enter a phone number we can reach you on"),
  organisation: optional(150),
  deliveryMode: z.enum(["CLASSROOM", "ONLINE"]),
  centerId: optional(60),
  participants: z.coerce.number().int().min(1).max(200).default(1),
  needsAccommodation: z.preprocess((v) => v === "on", z.boolean()),
  needsAirportPickup: z.preprocess((v) => v === "on", z.boolean()),
  notes: optional(1000),
  website: z.string().max(0).optional(),
});

export type FormState = {
  status: "idle" | "success" | "error";
  message?: string;
  fieldErrors?: Record<string, string[] | undefined>;
  /** signed link to the brochure PDF, returned after a successful request */
  downloadUrl?: string;
};
