/**
 * Pure date logic for the rolling schedule engine. No database, no side effects.
 *
 * All dates are "calendar dates" represented as UTC-midnight `Date`s, which is how Prisma
 * returns/accepts `@db.Date` columns. Using UTC arithmetic means there is no DST or
 * server-timezone drift. "Today" is always the calendar date in Africa/Nairobi (UTC+3, no DST).
 */

export type Length = "FIVE_DAY" | "TEN_DAY";

/** How many upcoming schedules we always keep per course and length. */
export const TARGET_COUNT: Record<Length, number> = { FIVE_DAY: 52, TEN_DAY: 26 };

/** Days between consecutive start Mondays. 10-day courses start every second Monday. */
export const STEP_DAYS: Record<Length, number> = { FIVE_DAY: 7, TEN_DAY: 14 };

/** Days from the start Monday to the final Friday. 5-day: Mon→Fri (+4). 10-day: Mon→Fri of next week (+11). */
export const END_OFFSET_DAYS: Record<Length, number> = { FIVE_DAY: 4, TEN_DAY: 11 };

/**
 * Fixed Monday that anchors the 10-day fortnight grid, so every course's 10-day runs
 * begin on the same Mondays (cleaner brochures and calendars).
 */
export const TEN_DAY_ANCHOR = utc(2026, 1, 5); // Monday 5 Jan 2026

const DAY_MS = 86_400_000;
const NAIROBI_OFFSET_MS = 3 * 3_600_000;

export function utc(y: number, m: number, d: number): Date {
  return new Date(Date.UTC(y, m - 1, d));
}

export function addDays(d: Date, n: number): Date {
  return new Date(d.getTime() + n * DAY_MS);
}

export function toISODate(d: Date): string {
  return d.toISOString().slice(0, 10);
}

/** Today's calendar date in Nairobi, as a UTC-midnight Date. */
export function nairobiToday(now: Date = new Date()): Date {
  const t = new Date(now.getTime() + NAIROBI_OFFSET_MS);
  return utc(t.getUTCFullYear(), t.getUTCMonth() + 1, t.getUTCDate());
}

/** 1 = Monday … 7 = Sunday */
export function isoWeekday(d: Date): number {
  return d.getUTCDay() === 0 ? 7 : d.getUTCDay();
}

/** First Monday on or after `d`. */
export function mondayOnOrAfter(d: Date): Date {
  const dow = d.getUTCDay(); // 0 = Sun … 6 = Sat
  return addDays(d, (8 - dow) % 7);
}

/** Whole weeks between the anchor and `monday` (can be negative). */
function weeksFromAnchor(monday: Date): number {
  return Math.round((monday.getTime() - TEN_DAY_ANCHOR.getTime()) / (7 * DAY_MS));
}

/** First valid start date on or after `from` for the given length. */
export function firstStartOnOrAfter(from: Date, length: Length): Date {
  const monday = mondayOnOrAfter(from);
  if (length === "FIVE_DAY") return monday;
  // 10-day: stay on the fortnight grid (even number of weeks from the anchor)
  return weeksFromAnchor(monday) % 2 === 0 ? monday : addDays(monday, 7);
}

export interface PlannedSchedule {
  length: Length;
  startDate: Date;
  endDate: Date;
}

export function buildSchedule(length: Length, startDate: Date): PlannedSchedule {
  return { length, startDate, endDate: addDays(startDate, END_OFFSET_DAYS[length]) };
}

/** Throws if a schedule would break the weekday-only rule. Used by admin "Add schedule" too. */
export function assertWeekdayOnly(s: { length: Length; startDate: Date; endDate: Date }): void {
  if (isoWeekday(s.startDate) !== 1) throw new Error(`Start ${toISODate(s.startDate)} is not a Monday`);
  if (isoWeekday(s.endDate) !== 5) throw new Error(`End ${toISODate(s.endDate)} is not a Friday`);
  const span = Math.round((s.endDate.getTime() - s.startDate.getTime()) / DAY_MS);
  if (span !== END_OFFSET_DAYS[s.length]) throw new Error(`Span of ${span} days does not match ${s.length}`);
}

export interface PlanOptions {
  /**
   * A schedule counts as "upcoming" only if it starts at least this many days from today.
   * Default 1 → anything starting today or earlier has lapsed. Raise it to enforce registration lead time.
   */
  leadDays?: number;
  targetOverride?: Partial<Record<Length, number>>;
  /**
   * Start dates that already exist in ANY status (open, cancelled) from the cutoff on. A cancelled date is never
   * re-created; it is simply replaced by one more date at the end. Defaults to the open starts.
   */
  takenStarts?: Date[];
}

/**
 * Decide which new schedules must be created so exactly `target` OPEN upcoming schedules exist.
 *
 * Walks the Monday grid forward from the first valid start and creates every date that is missing until the target
 * is reached. So it fills gaps (for example after importing one far-future registration from the old system), replaces a
 * cancelled date by extending the end, tops up lapsed weeks at the end, and never recreates a date that exists.
 *
 * @param openStarts start dates of OPEN schedules that have not lapsed
 */
export function planTopUp(
  length: Length,
  openStarts: Date[],
  today: Date,
  opts: PlanOptions = {},
): PlannedSchedule[] {
  const lead = opts.leadDays ?? 1;
  const target = opts.targetOverride?.[length] ?? TARGET_COUNT[length];
  const cutoff = addDays(today, lead);
  const ge = (d: Date) => d.getTime() >= cutoff.getTime();

  const open = openStarts.filter(ge);
  const missing = target - open.length;
  if (missing <= 0) return [];

  const taken = new Set((opts.takenStarts ?? openStarts).filter(ge).concat(open).map((d) => d.getTime()));
  const step = STEP_DAYS[length];
  const out: PlannedSchedule[] = [];
  for (let d = firstStartOnOrAfter(cutoff, length); out.length < missing; d = addDays(d, step)) {
    if (!taken.has(d.getTime())) out.push(buildSchedule(length, d));
  }
  return out;
}
