import { test } from "node:test";
import assert from "node:assert/strict";
import { utc, isoWeekday, planTopUp, nairobiToday, toISODate, addDays, assertWeekdayOnly, firstStartOnOrAfter } from "./dates";

const iso = (d: Date) => toISODate(d);

test("Nairobi 'today' rolls over at 21:00 UTC", () => {
  assert.equal(iso(nairobiToday(new Date("2026-10-09T20:59:00Z"))), "2026-10-09");
  assert.equal(iso(nairobiToday(new Date("2026-10-09T21:00:00Z"))), "2026-10-10");
});

test("empty course gets 52 five-day schedules, all Mon→Fri, none lapsed", () => {
  const today = utc(2026, 10, 9); // Friday
  const plan = planTopUp("FIVE_DAY", [], today);
  assert.equal(plan.length, 52);
  assert.equal(iso(plan[0].startDate), "2026-10-12"); // next Monday
  for (const p of plan) {
    assert.equal(isoWeekday(p.startDate), 1);
    assert.equal(isoWeekday(p.endDate), 5);
    assert.doesNotThrow(() => assertWeekdayOnly(p));
  }
  assert.equal(iso(plan[51].startDate), iso(addDays(utc(2026, 10, 12), 51 * 7)));
});

test("empty course gets 26 ten-day schedules on the fortnight grid, spanning two weeks", () => {
  const plan = planTopUp("TEN_DAY", [], utc(2026, 10, 9));
  assert.equal(plan.length, 26);
  assert.equal(iso(plan[0].startDate), "2026-10-12"); // 40 weeks after the 5 Jan anchor → even
  assert.equal(iso(plan[0].endDate), "2026-10-23");
  assert.equal(isoWeekday(plan[0].endDate), 5);
  for (let i = 1; i < plan.length; i++) {
    assert.equal((plan[i].startDate.getTime() - plan[i - 1].startDate.getTime()) / 86_400_000, 14);
  }
});

test("10-day skips an off-grid Monday", () => {
  assert.equal(iso(firstStartOnOrAfter(utc(2026, 10, 13), "TEN_DAY")), "2026-10-26");
});

test("when one week lapses, exactly one is appended after the last", () => {
  const today = utc(2026, 10, 9);
  const full = planTopUp("FIVE_DAY", [], today).map((p) => p.startDate);
  // a week later the first Monday (12 Oct) has started and lapsed
  const nextWeek = utc(2026, 10, 16);
  const add = planTopUp("FIVE_DAY", full, nextWeek);
  assert.equal(add.length, 1);
  assert.equal(iso(add[0].startDate), iso(addDays(full[51], 7)));
});

test("a long outage catches up in one run and stays idempotent", () => {
  const today = utc(2026, 10, 9);
  const full = planTopUp("FIVE_DAY", [], today).map((p) => p.startDate);
  const later = utc(2026, 12, 21); // a Monday, 10 weeks on: 11 sessions (12 Oct … 21 Dec) have started
  const add = planTopUp("FIVE_DAY", full, later);
  assert.equal(add.length, 11);
  const all = [...full, ...add.map((a) => a.startDate)];
  assert.equal(planTopUp("FIVE_DAY", all, later).length, 0);
});

test("a Monday start is not 'upcoming' once it is today", () => {
  const monday = utc(2026, 10, 12);
  const add = planTopUp("FIVE_DAY", [monday], monday);
  assert.equal(add.length, 52); // the one starting today has lapsed
  assert.equal(iso(add[0].startDate), "2026-10-19");
});

test("weekend or mismatched dates are rejected", () => {
  assert.throws(() => assertWeekdayOnly({ length: "FIVE_DAY", startDate: utc(2026, 10, 10), endDate: utc(2026, 10, 14) }));
  assert.throws(() => assertWeekdayOnly({ length: "FIVE_DAY", startDate: utc(2026, 10, 12), endDate: utc(2026, 10, 23) }));
});

test("a far-future imported schedule does not leave a gap before it: the grid is filled from the first valid Monday", () => {
  const today = utc(2026, 10, 9);
  const imported = utc(2026, 12, 7); // e.g. one real registration brought across from the old system
  const plan = planTopUp("FIVE_DAY", [imported], today);
  assert.equal(plan.length, 51);                                         // 52 open in total, counting the imported one
  assert.equal(iso(plan[0].startDate), "2026-10-12");                    // starts at the first Monday, not after December
  assert.ok(!plan.some((p) => iso(p.startDate) === "2026-12-07"), "never re-creates the date that exists");
  assert.equal(iso(plan[plan.length - 1].startDate), iso(addDays(utc(2026, 10, 12), 51 * 7)));
});

test("a cancelled date is not re-created; a replacement is added at the end instead", () => {
  const today = utc(2026, 10, 9);
  const all = planTopUp("FIVE_DAY", [], today).map((p) => p.startDate);
  const cancelled = all[3];
  const open = all.filter((d) => d !== cancelled);
  const add = planTopUp("FIVE_DAY", open, today, { takenStarts: all });  // all dates exist; one of them is cancelled
  assert.equal(add.length, 1);
  assert.equal(iso(add[0].startDate), iso(addDays(all[51], 7)));
  assert.ok(!add.some((p) => p.startDate.getTime() === cancelled.getTime()));
});

test("a manual off-grid schedule counts towards the target", () => {
  const today = utc(2026, 10, 9);
  const manual = utc(2027, 3, 3); // a Wednesday: not on the Monday grid
  const plan = planTopUp("FIVE_DAY", [manual], today);
  assert.equal(plan.length, 51);
  assert.equal(planTopUp("TEN_DAY", [], today).length, 26);
});
