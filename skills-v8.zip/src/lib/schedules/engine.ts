import type { PrismaClient, CourseLength } from "@prisma/client";
import { assertWeekdayOnly, nairobiToday, planTopUp, addDays, type PlanOptions } from "./dates";

export interface EnsureResult {
  courseId: string;
  created: Record<CourseLength, number>;
}

const LEAD_DAYS = Number(process.env.SCHEDULE_LEAD_DAYS ?? 1);

/**
 * Tops a single course up to 52 upcoming 5-day and/or 26 upcoming 10-day schedules.
 *
 * Safe to call any time and any number of times:
 *  - past schedules are never deleted (students' records still point at them);
 *  - the (courseId, length, startDate) unique key + skipDuplicates makes concurrent runs harmless;
 *  - a cancelled schedule does not count towards the target, so a replacement is appended.
 */
export async function ensureCourseSchedules(
  db: PrismaClient,
  courseId: string,
  opts: PlanOptions = {},
  now: Date = new Date(),
): Promise<EnsureResult> {
  const course = await db.course.findUnique({
    where: { id: courseId },
    select: { id: true, lengths: true, autoSchedule: true, status: true },
  });
  const created: Record<CourseLength, number> = { FIVE_DAY: 0, TEN_DAY: 0 };
  if (!course || !course.autoSchedule || course.status === "ARCHIVED") return { courseId, created };

  const today = nairobiToday(now);
  const cutoff = addDays(today, opts.leadDays ?? LEAD_DAYS);

  for (const length of course.lengths) {
    const existing = await db.schedule.findMany({
      where: { courseId, length, startDate: { gte: cutoff } }, // every status: cancelled dates must not be re-created
      select: { startDate: true, status: true },
    });
    const open = existing.filter((s) => s.status === "OPEN").map((s) => s.startDate);
    const plan = planTopUp(length, open, today, { leadDays: LEAD_DAYS, ...opts, takenStarts: existing.map((s) => s.startDate) });
    if (plan.length === 0) continue;

    plan.forEach(assertWeekdayOnly); // belt and braces; the DB CHECK constraint is the final guard

    const res = await db.schedule.createMany({
      data: plan.map((p) => ({ courseId, length, startDate: p.startDate, endDate: p.endDate, generated: true })),
      skipDuplicates: true,
    });
    created[length] = res.count;
  }
  return { courseId, created };
}

/** The daily job: keeps every auto-scheduled, non-archived course topped up. */
export async function rollAllSchedules(db: PrismaClient, now: Date = new Date()) {
  const courses = await db.course.findMany({
    where: { autoSchedule: true, status: { not: "ARCHIVED" }, lengths: { isEmpty: false } },
    select: { id: true },
  });

  const results: EnsureResult[] = [];
  const failures: { courseId: string; error: string }[] = [];
  for (const { id } of courses) {
    try {
      results.push(await ensureCourseSchedules(db, id, {}, now));
    } catch (e) {
      failures.push({ courseId: id, error: e instanceof Error ? e.message : String(e) });
    }
  }
  const added = results.reduce((n, r) => n + r.created.FIVE_DAY + r.created.TEN_DAY, 0);
  return { courses: courses.length, added, failures };
}

/**
 * Admin → Schedule → "Unscheduled Courses".
 * A course is unscheduled if it has no lengths chosen, auto-scheduling switched off,
 * or fewer upcoming schedules than its target (e.g. the job has not run yet).
 */
export async function listUnscheduledCourses(db: PrismaClient, now: Date = new Date()) {
  const cutoff = addDays(nairobiToday(now), LEAD_DAYS);
  const courses = await db.course.findMany({
    where: { status: { not: "ARCHIVED" } },
    select: {
      id: true, name: true, slug: true, lengths: true, autoSchedule: true,
      category: { select: { name: true } },
      schedules: { where: { status: "OPEN", startDate: { gte: cutoff } }, select: { length: true } },
    },
    orderBy: { name: "asc" },
  });

  return courses.flatMap((c) => {
    const counts = { FIVE_DAY: 0, TEN_DAY: 0 };
    c.schedules.forEach((s) => counts[s.length]++);
    const reason =
      c.lengths.length === 0 ? "No course length selected"
      : !c.autoSchedule ? "Auto-scheduling is off"
      : c.schedules.length === 0 ? "No upcoming schedules"
      : null;
    return reason ? [{ id: c.id, name: c.name, slug: c.slug, category: c.category.name, counts, reason }] : [];
  });
}
