import type { Repo } from "../repo";
import type { CourseDetail, Length } from "../types";
import type { Mailer } from "./mailer";
import type { EmailStore, QueuedMessage } from "./types";
import { isSendWindow, nextDueAt, stageDueAt } from "./cadence";
import { renderBrochure, renderFollowUp, renderRegistration, renderStaffNotification, type Rendered } from "./templates";
import { buildBrochure } from "../brochure/pdf";
import { brochurePath } from "../brochure/links";
import { abs } from "../site";

export const MAX_ATTEMPTS = 3;
const MIN_GAP_MS = 3 * 86_400_000; // never two follow-ups closer than 3 days, even after an outage

export interface Deps {
  store: EmailStore;
  repo: Pick<Repo, "getCourse">;
  mailer: Mailer;
  /** Staff inbox that gets a heads-up for every registration / brochure download. */
  notifyTo?: string;
  /** Pause between sends – Resend allows 2 requests/second by default. */
  sendDelayMs?: number;
}

export interface RegistrationInfo {
  email: string; name: string; courseSlug: string; courseName: string; phone?: string;
  startDate: string; endDate: string; length: Length; deliveryMode: "CLASSROOM" | "ONLINE"; centerName?: string; participants: number;
}

const sleep = (ms: number) => new Promise((r) => setTimeout(r, ms));
const str = (v: unknown) => (typeof v === "string" ? v : "");

export function createEmailService(d: Deps) {
  const { store, repo, mailer } = d;

  async function course(slug: string): Promise<CourseDetail> {
    const c = await repo.getCourse(slug);
    if (!c) throw new Error(`Course "${slug}" is no longer available`);
    return c;
  }

  async function render(m: QueuedMessage): Promise<{ rendered: Rendered; attachments?: { filename: string; content: Buffer; contentType: string }[] }> {
    const x = m.context;
    const unsubscribeUrl = m.unsubscribeToken ? abs(`/unsubscribe/${m.unsubscribeToken}`) : undefined;

    if (m.template === "staff-notification") {
      return { rendered: renderStaffNotification({ kind: x.kind === "registration" ? "registration" : "brochure", name: str(x.name), email: str(x.email), phone: str(x.phone) || undefined, courseName: str(x.courseName), detail: str(x.detail) || undefined }) };
    }
    const c = await course(str(x.courseSlug));
    const name = str(x.name);

    if (m.template === "brochure") {
      const downloadUrl = abs(brochurePath(c.slug, str(x.leadId)));
      const pdf = Buffer.from(await buildBrochure(c));
      return { rendered: renderBrochure({ name, course: c, unsubscribeUrl, downloadUrl }), attachments: [{ filename: `${c.slug}-brochure.pdf`, content: pdf, contentType: "application/pdf" }] };
    }
    if (m.template === "registration") {
      return { rendered: renderRegistration({ name, course: c, unsubscribeUrl, startDate: str(x.startDate), endDate: str(x.endDate), length: x.length as Length, deliveryMode: x.deliveryMode === "ONLINE" ? "ONLINE" : "CLASSROOM", centerName: str(x.centerName) || undefined, participants: Number(x.participants) || 1 }) };
    }
    if (m.template === "followup") {
      return { rendered: renderFollowUp({ name, course: c, unsubscribeUrl, stage: m.stage ?? 1, source: x.source === "REGISTRATION" ? "REGISTRATION" : "BROCHURE" }) };
    }
    throw new Error(`Unknown template ${m.template}`);
  }

  /** Sends a message this worker has already leased. Never throws: failures are recorded and retried. */
  async function sendClaimed(m: QueuedMessage, now: Date): Promise<"sent" | "suppressed" | "failed"> {
    try {
      if (m.template !== "staff-notification") {
        // marketing mail honours unsubscribes; requested/transactional mail only stops for bounces & complaints
        const scope = m.template === "followup" ? "marketing" : "transactional";
        if (await store.isSuppressed(m.toEmail, scope)) { await store.markSuppressed(m.id); return "suppressed"; }
      }
      const { rendered, attachments } = await render(m);
      const headers: Record<string, string> = {};
      if (m.unsubscribeToken && m.template === "followup") {
        headers["List-Unsubscribe"] = `<${abs(`/api/unsubscribe/${m.unsubscribeToken}`)}>`;
        headers["List-Unsubscribe-Post"] = "List-Unsubscribe=One-Click"; // RFC 8058: Gmail/Yahoo one-click requirement
      }
      try {
        const { providerId } = await mailer.send({
          to: m.toEmail, subject: rendered.subject, html: rendered.html, text: rendered.text, headers, attachments,
          tags: [{ name: "template", value: m.template }, ...(m.stage ? [{ name: "stage", value: String(m.stage) }] : [])],
          idempotencyKey: m.id,
        });
        await store.markSent(m.id, rendered.subject, providerId, now);
        return "sent";
      } catch (e) {
        await store.markFailed(m.id, rendered.subject, e instanceof Error ? e.message : String(e), now);
        return "failed";
      }
    } catch (e) {
      await store.markFailed(m.id, null, e instanceof Error ? e.message : String(e), now);
      return "failed";
    }
  }

  return {
    /** Brochure requested: queue the brochure email, start the follow-up sequence, ping staff. */
    async captureLead(i: { leadId: string; email: string; name: string; phone?: string; courseSlug: string; courseName: string }, now = new Date()): Promise<string[]> {
      const fu = await store.startFollowUp({ source: "BROCHURE", email: i.email, name: i.name, courseSlug: i.courseSlug, startedAt: now, firstDueAt: stageDueAt(now, 1) });
      const ids = [await store.enqueueMessage({ toEmail: i.email, template: "brochure", followUpId: fu?.id, context: { name: i.name, courseSlug: i.courseSlug, leadId: i.leadId } })];
      if (d.notifyTo) ids.push(await store.enqueueMessage({ toEmail: d.notifyTo, template: "staff-notification", context: { kind: "brochure", name: i.name, email: i.email, phone: i.phone, courseName: i.courseName } }));
      return ids;
    },

    /** Registration: confirmation email, follow-up sequence, end any brochure sequence for the same course. */
    async captureRegistration(i: RegistrationInfo, now = new Date()): Promise<string[]> {
      await store.convertBrochureFollowUps(i.email, i.courseSlug);
      const fu = await store.startFollowUp({ source: "REGISTRATION", email: i.email, name: i.name, courseSlug: i.courseSlug, startedAt: now, firstDueAt: stageDueAt(now, 1) });
      const ids = [await store.enqueueMessage({ toEmail: i.email, template: "registration", followUpId: fu?.id, context: { name: i.name, courseSlug: i.courseSlug, startDate: i.startDate, endDate: i.endDate, length: i.length, deliveryMode: i.deliveryMode, centerName: i.centerName, participants: i.participants } })];
      if (d.notifyTo) ids.push(await store.enqueueMessage({ toEmail: d.notifyTo, template: "staff-notification", context: { kind: "registration", name: i.name, email: i.email, phone: i.phone, courseName: i.courseName, detail: `${i.startDate} → ${i.endDate}, ${i.deliveryMode === "ONLINE" ? "online" : `classroom${i.centerName ? ` (${i.centerName})` : ""}`}, ${i.participants} participant(s)` } }));
      return ids;
    },

    /** Send one message now (used right after the request, via after()). */
    async deliverMessage(id: string, now = new Date()) {
      const m = await store.claimMessage(id, now, MAX_ATTEMPTS);
      return m ? sendClaimed(m, now) : "skipped";
    },

    /** Outbox sweeper: retries anything queued/failed that is not already being sent. */
    async deliverQueued(now = new Date(), limit = 50) {
      const batch = await store.claimQueued(now, limit, MAX_ATTEMPTS, 30_000);
      const tally = { sent: 0, suppressed: 0, failed: 0 };
      for (const m of batch) {
        tally[await sendClaimed(m, now)]++;
        if (d.sendDelayMs) await sleep(d.sendDelayMs);
      }
      return { claimed: batch.length, ...tally };
    },

    /** Hourly: release follow-ups that are due (business hours only), one stage each. */
    async runFollowUps(now = new Date(), limit = 200) {
      const res = { due: 0, enqueued: 0, stopped: 0, waitingForDates: 0, skippedWindow: false };
      if (!isSendWindow(now)) return { ...res, skippedWindow: true };
      const due = await store.dueFollowUps(now, limit);
      res.due = due.length;

      for (const f of due) {
        if (await store.isSuppressed(f.email, "marketing")) { await store.stopFollowUp(f.id, "SUPPRESSED", "address suppressed"); res.stopped++; continue; }
        const c = await repo.getCourse(f.courseSlug);
        if (!c) { await store.stopFollowUp(f.id, "COMPLETED", "course unavailable"); res.stopped++; continue; }
        if (!c.schedules.length) { res.waitingForDates++; continue; } // an email with no dates is pointless; retry next run

        const stage = f.lastSentStage + 1;
        const computed = nextDueAt(f.startedAt, stage); // when the stage AFTER this one is due (null = last stage)
        const floor = new Date(now.getTime() + MIN_GAP_MS);
        const next = computed && computed < floor ? floor : computed;
        const ok = await store.enqueueFollowUpStage({
          followUpId: f.id, expectedStage: f.lastSentStage, nextStage: stage, nextDueAt: next, sentAt: now,
          message: { toEmail: f.email, template: "followup", context: { name: f.name, courseSlug: f.courseSlug, source: f.source } },
        });
        if (ok) res.enqueued++;
      }
      return res;
    },
  };
}

export type EmailService = ReturnType<typeof createEmailService>;

let cached: EmailService | undefined;
/** Production wiring. */
export async function emailService(): Promise<EmailService> {
  if (cached) return cached;
  const [{ getEmailStore }, { getRepo }, { getMailer }] = await Promise.all([import("./store"), import("../repo"), import("./mailer")]);
  const mailer = getMailer();
  cached = createEmailService({
    store: await getEmailStore(), repo: await getRepo(), mailer, notifyTo: process.env.EMAIL_NOTIFY_TO || undefined,
    sendDelayMs: Number(process.env.EMAIL_SEND_DELAY_MS ?? (process.env.RESEND_API_KEY ? 550 : 0)),
  });
  return cached;
}
