import { mkdir, writeFile } from "node:fs/promises";
import path from "node:path";

export interface OutgoingEmail {
  to: string; subject: string; html: string; text: string;
  headers?: Record<string, string>;
  attachments?: { filename: string; content: Buffer; contentType: string }[];
  tags?: { name: string; value: string }[];
  /** Stable per message: if we retry after a timeout the provider will not send twice. */
  idempotencyKey: string;
}
export interface Mailer { send(m: OutgoingEmail): Promise<{ providerId: string }> }

export const FROM = () => process.env.EMAIL_FROM ?? "Skills for Africa <training@example.org>";

/** Resend REST API (https://resend.com/docs/api-reference/emails/send-email). No SDK needed. */
export const resendMailer: Mailer = {
  async send(m) {
    const res = await fetch("https://api.resend.com/emails", {
      method: "POST",
      headers: { Authorization: `Bearer ${process.env.RESEND_API_KEY}`, "Content-Type": "application/json", "Idempotency-Key": m.idempotencyKey },
      body: JSON.stringify({
        from: FROM(), to: [m.to], subject: m.subject, html: m.html, text: m.text,
        reply_to: process.env.EMAIL_REPLY_TO || undefined, headers: m.headers, tags: m.tags,
        attachments: m.attachments?.map((a) => ({ filename: a.filename, content: a.content.toString("base64") })),
      }),
      signal: AbortSignal.timeout(15_000),
    });
    const body = (await res.json().catch(() => ({}))) as { id?: string; message?: string };
    if (!res.ok || !body.id) throw new Error(`Resend ${res.status}: ${body.message ?? "no id returned"}`);
    return { providerId: body.id };
  },
};

/** Local preview: nothing is sent; HTML is written to .email-previews/ so you can open it in a browser. */
export const devMailer: Mailer = {
  async send(m) {
    const id = `dev_${Date.now().toString(36)}_${Math.random().toString(36).slice(2, 8)}`;
    const dir = path.join(process.cwd(), ".email-previews");
    await mkdir(dir, { recursive: true });
    await writeFile(path.join(dir, `${id}.html`), `<!-- To: ${m.to} | Subject: ${m.subject} | Attachments: ${m.attachments?.map((a) => a.filename).join(", ") || "none"} -->\n${m.html}`);
    console.log(`[mail:dev] to=${m.to} subject="${m.subject}" → .email-previews/${id}.html`);
    return { providerId: id };
  },
};

export function getMailer(): Mailer {
  if (process.env.RESEND_API_KEY) return resendMailer;
  // Dry run writes previews instead of sending. Outside development it must be switched on explicitly.
  if (process.env.NODE_ENV !== "production" || process.env.EMAIL_DRY_RUN === "1") return devMailer;
  throw new Error("RESEND_API_KEY is required in production (or set EMAIL_DRY_RUN=1 to disable sending)");
}
