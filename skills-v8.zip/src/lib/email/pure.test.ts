import { test } from "node:test";
import assert from "node:assert/strict";
import { createHmac } from "node:crypto";
import { addMonths, stageDueAt, nextDueAt, isSendWindow } from "./cadence";
import { nextStatus, shouldSuppress } from "./status";
import { verifySvix } from "./svix";
import { brochurePath, verifyBrochureLink } from "../brochure/links";

const T0 = new Date("2026-01-31T10:00:00Z");
const iso = (d: Date | null) => d?.toISOString().slice(0, 10);

test("stage timings: d3, d7, d14, +2m, +3m, then monthly", () => {
  assert.deepEqual([1, 2, 3, 4, 5, 6, 7].map((s) => iso(stageDueAt(T0, s))),
    ["2026-02-03", "2026-02-07", "2026-02-14", "2026-03-31", "2026-04-30", "2026-05-31", "2026-06-30"]);
});

test("month arithmetic clamps to month end", () => {
  assert.equal(iso(addMonths(new Date("2026-01-31T00:00:00Z"), 1)), "2026-02-28");
  assert.equal(iso(addMonths(new Date("2028-01-31T00:00:00Z"), 1)), "2028-02-29");
  assert.equal(iso(addMonths(new Date("2026-11-30T00:00:00Z"), 3)), "2027-02-28");
});

test("sequence ends after the cap", () => {
  assert.ok(nextDueAt(T0, 11, 12));
  assert.equal(nextDueAt(T0, 12, 12), null);
});

test("send window: Nairobi weekdays 08:00–17:59 only", () => {
  assert.equal(isSendWindow(new Date("2026-10-12T05:00:00Z")), true);  // Mon 08:00 EAT
  assert.equal(isSendWindow(new Date("2026-10-12T04:59:00Z")), false); // Mon 07:59 EAT
  assert.equal(isSendWindow(new Date("2026-10-12T14:59:00Z")), true);  // Mon 17:59 EAT
  assert.equal(isSendWindow(new Date("2026-10-12T15:00:00Z")), false); // Mon 18:00 EAT
  assert.equal(isSendWindow(new Date("2026-10-17T08:00:00Z")), false); // Saturday
  assert.equal(isSendWindow(new Date("2026-10-18T08:00:00Z")), false); // Sunday
});

test("status only moves forward, opens/clicks never change it", () => {
  assert.equal(nextStatus("SENT", "DELIVERED"), "DELIVERED");
  assert.equal(nextStatus("BOUNCED", "DELIVERED"), "BOUNCED");   // late delivered event can't undo a bounce
  assert.equal(nextStatus("DELIVERED", "BOUNCED"), "BOUNCED");
  assert.equal(nextStatus("COMPLAINED", "BOUNCED"), "COMPLAINED");
  assert.equal(nextStatus("DELIVERED", "OPENED"), "DELIVERED");
  assert.equal(nextStatus("QUEUED", "SENT"), "SENT");
});

test("only permanent bounces and complaints suppress", () => {
  assert.equal(shouldSuppress("BOUNCED", "Permanent"), "HARD_BOUNCE");
  assert.equal(shouldSuppress("BOUNCED", "Transient"), null);
  assert.equal(shouldSuppress("BOUNCED", undefined), null);
  assert.equal(shouldSuppress("COMPLAINED"), "COMPLAINT");
  assert.equal(shouldSuppress("DELIVERED"), null);
});

const key = Buffer.from("super-secret-key-for-tests-1234567890");
const secret = "whsec_" + key.toString("base64");
const sign = (id: string, ts: string, body: string) => "v1," + createHmac("sha256", key).update(`${id}.${ts}.${body}`).digest("base64");

test("svix signature: valid, wrong body, stale, rotation", () => {
  const now = 1_800_000_000_000, ts = String(now / 1000), body = '{"type":"email.delivered"}';
  const base = { secret, id: "msg_1", timestamp: ts, body, now };
  assert.equal(verifySvix({ ...base, signature: sign("msg_1", ts, body) }), true);
  assert.equal(verifySvix({ ...base, signature: sign("msg_1", ts, body + " ") }), false);
  assert.equal(verifySvix({ ...base, signature: "v1,AAAA " + sign("msg_1", ts, body) }), true); // rotation: any match
  assert.equal(verifySvix({ ...base, signature: sign("msg_1", ts, body), now: now + 10 * 60_000 }), false); // 10 min old
  assert.equal(verifySvix({ ...base, signature: null }), false);
  assert.equal(verifySvix({ ...base, secret: "", signature: sign("msg_1", ts, body) }), false);
});

test("brochure links: valid, tampered, wrong course, expired", () => {
  const now = Date.now();
  const url = new URL("http://x" + brochurePath("pmp-prep", "lead_1", 30, now));
  const q = (k: string) => url.searchParams.get(k);
  assert.equal(verifyBrochureLink("pmp-prep", { lead: q("lead"), exp: q("exp"), sig: q("sig") }, now), "lead_1");
  assert.equal(verifyBrochureLink("other-course", { lead: q("lead"), exp: q("exp"), sig: q("sig") }, now), null);
  assert.equal(verifyBrochureLink("pmp-prep", { lead: "lead_2", exp: q("exp"), sig: q("sig") }, now), null);
  assert.equal(verifyBrochureLink("pmp-prep", { lead: q("lead"), exp: q("exp"), sig: q("sig") }, now + 31 * 86_400_000), null);
  assert.equal(verifyBrochureLink("pmp-prep", {}, now), null);
});
