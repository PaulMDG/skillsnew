import { createHmac, timingSafeEqual } from "node:crypto";

/**
 * Verifies Svix-style webhook signatures (used by Resend).
 * signed content = `${svix-id}.${svix-timestamp}.${rawBody}`, HMAC-SHA256 with the base64 part of `whsec_…`.
 * Header `svix-signature` = space separated `v1,<base64>` entries (several during secret rotation).
 */
export function verifySvix(opts: { secret: string; id: string | null; timestamp: string | null; signature: string | null; body: string; now?: number; toleranceS?: number }): boolean {
  const { secret, id, timestamp, signature, body } = opts;
  if (!secret || !id || !timestamp || !signature) return false;
  const ts = Number(timestamp);
  if (!Number.isFinite(ts)) return false;
  const now = Math.floor((opts.now ?? Date.now()) / 1000);
  if (Math.abs(now - ts) > (opts.toleranceS ?? 300)) return false; // stale or replayed

  const key = Buffer.from(secret.startsWith("whsec_") ? secret.slice(6) : secret, "base64");
  const expected = createHmac("sha256", key).update(`${id}.${timestamp}.${body}`).digest();

  return signature.split(" ").some((part) => {
    const [version, sig] = part.split(",");
    if (version !== "v1" || !sig) return false;
    const given = Buffer.from(sig, "base64");
    return given.length === expected.length && timingSafeEqual(given, expected);
  });
}
