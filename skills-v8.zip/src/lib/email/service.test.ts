import { test, beforeEach } from "node:test";
import assert from "node:assert/strict";
import { createEmailService } from "./service";
import { memoryEmailStore, __memoryEmailState as S } from "./store.memory";
import { mockRepo } from "../repo.mock";
import type { Mailer, OutgoingEmail } from "./mailer";

process.env.AUTH_SECRET = "x".repeat(40);

let sent: OutgoingEmail[] = [];
let failNext = 0;
const mailer: Mailer = {
  async send(m) {
    if (failNext > 0) { failNext--; throw new Error("provider down"); }
    sent.push(m);
    return { providerId: `prov_${sent.length}` };
  },
};
const svc = () => createEmailService({ store: memoryEmailStore, repo: mockRepo, mailer, notifyTo: "staff@org.test" });

beforeEach(() => { S.followUps.clear(); S.messages.clear(); S.events.clear(); S.suppressed.clear(); sent = []; failNext = 0; });

// Monday 12 Oct 2026, 10:00 Nairobi (07:00Z) – inside the send window
const T0 = new Date("2026-10-12T07:00:00Z");
const day = (n: number, from = T0) => new Date(from.getTime() + n * 86_400_000);

test("brochure request: sends brochure with PDF attached, tracks it, notifies staff", async () => {
  const s = svc();
  const ids = await s.captureLead({ leadId: "L1", email: "Amina@Example.com", name: "Amina Wanjiru", courseSlug: "pmp-prep", courseName: "PMP" }, T0);
  assert.equal(ids.length, 2);
  for (const id of ids) assert.equal(await s.deliverMessage(id, T0), "sent");
  const brochure = sent.find((m) => m.to === "amina@example.com")!;
  assert.match(brochure.subject, /Your brochure/);
  assert.equal(brochure.attachments?.[0].contentType, "application/pdf");
  assert.equal(brochure.attachments![0].content.subarray(0, 4).toString(), "%PDF");
  assert.match(brochure.html, /\/brochure\/pmp-prep\?lead=L1&amp;exp=\d+&amp;sig=/);
  assert.ok(sent.find((m) => m.to === "staff@org.test"));
  assert.equal(S.followUps.size, 1);
});

test("a message is never sent twice, even if two workers race", async () => {
  const s = svc();
  const [id] = await s.captureLead({ leadId: "L1", email: "a@b.co", name: "A", courseSlug: "pmp-prep", courseName: "PMP" }, T0);
  const results = await Promise.all([s.deliverMessage(id, T0), s.deliverMessage(id, T0), s.deliverQueued(T0, 10)]);
  assert.equal(sent.filter((m) => m.to === "a@b.co").length, 1);
  assert.ok(results.some((r) => r === "sent"));
});

test("full cadence: d3, d7, d14, +2m, +3m, then monthly – with correct unsubscribe headers", async () => {
  const s = svc();
  await s.captureLead({ leadId: "L1", email: "a@b.co", name: "A B", courseSlug: "pmp-prep", courseName: "PMP" }, T0);
  sent = []; S.messages.clear(); // ignore the brochure itself

  const fire = async (when: Date) => { const r = await s.runFollowUps(when); await s.deliverQueued(new Date(when.getTime() + 60_000), 50); return r; };

  assert.equal((await fire(day(2))).enqueued, 0);                  // day 2: nothing yet
  assert.equal((await fire(day(3))).enqueued, 1);                  // stage 1
  assert.equal((await fire(day(3, new Date(T0.getTime() + 3600_000)))).enqueued, 0); // same day again: no duplicate
  assert.equal((await fire(day(7))).enqueued, 1);                  // stage 2
  assert.equal((await fire(day(14))).enqueued, 1);                 // stage 3
  const stageTimes = [[1, "2026-11-12"], [2, "2026-12-12"]];       // 4th = +2 months = Dec 12; walk to it
  assert.equal((await fire(new Date("2026-12-14T07:00:00Z"))).enqueued, 1);   // stage 4 (+2 months → Mon 14 Dec is first working slot after Sat 12 Dec)
  assert.equal((await fire(new Date("2027-01-12T07:00:00Z"))).enqueued, 1);   // stage 5 (+3 months)
  assert.equal((await fire(new Date("2027-02-12T07:00:00Z"))).enqueued, 1);   // stage 6 (monthly)
  void stageTimes;

  assert.deepEqual(sent.map((m) => m.subject.length > 0), [true, true, true, true, true, true]);
  assert.match(sent[0].subject, /Still thinking about/);
  const h = sent[0].headers!;
  assert.match(h["List-Unsubscribe"], /\/api\/unsubscribe\/[a-f0-9]+>$/);
  assert.equal(h["List-Unsubscribe-Post"], "List-Unsubscribe=One-Click");
  assert.match(sent[0].html, /\/unsubscribe\/[a-f0-9]+/);
  assert.match(sent[0].html, /Register/);
  assert.deepEqual([...S.messages.values()].map((m) => m.stage).sort(), [1, 2, 3, 4, 5, 6]);
});

test("outside business hours nothing is released; it goes out at the next window", async () => {
  const s = svc();
  await s.captureLead({ leadId: "L1", email: "a@b.co", name: "A", courseSlug: "pmp-prep", courseName: "PMP" }, T0);
  const sat = new Date("2026-10-17T08:00:00Z"); // day 5.. due stage 1 (Oct 15) already passed; Saturday → blocked
  const r = await s.runFollowUps(sat);
  assert.equal(r.skippedWindow, true);
  assert.equal((await s.runFollowUps(new Date("2026-10-19T07:00:00Z"))).enqueued, 1); // Monday morning
});

test("after an outage the sequence does not burst: at least 3 days between follow-ups", async () => {
  const s = svc();
  await s.captureLead({ leadId: "L1", email: "a@b.co", name: "A", courseSlug: "pmp-prep", courseName: "PMP" }, T0);
  const late = new Date("2027-03-01T07:00:00Z"); // months late: stages 1-6 all overdue
  assert.equal((await s.runFollowUps(late)).enqueued, 1);
  assert.equal((await s.runFollowUps(new Date(late.getTime() + 3_600_000))).enqueued, 0);
  assert.equal((await s.runFollowUps(new Date(late.getTime() + 2 * 86_400_000))).enqueued, 0);
  assert.equal((await s.runFollowUps(new Date(late.getTime() + 3 * 86_400_000))).enqueued, 1);
});

test("registering ends the brochure sequence for that course; registration sequence starts", async () => {
  const s = svc();
  await s.captureLead({ leadId: "L1", email: "a@b.co", name: "A", courseSlug: "pmp-prep", courseName: "PMP" }, T0);
  await s.captureRegistration({ email: "a@b.co", name: "A B", courseSlug: "pmp-prep", courseName: "PMP", startDate: "2026-10-19", endDate: "2026-10-23", length: "FIVE_DAY", deliveryMode: "CLASSROOM", centerName: "Nairobi, Kenya", participants: 2 }, T0);
  const fus = [...S.followUps.values()];
  assert.equal(fus.find((f) => f.source === "BROCHURE")!.status, "CONVERTED");
  assert.equal(fus.find((f) => f.source === "REGISTRATION")!.status, "ACTIVE");
  const conf = [...S.messages.values()].find((m) => m.template === "registration")!;
  await s.deliverMessage(conf.id, T0);
  const mail = sent.find((m) => m.subject.startsWith("Registration received"))!;
  assert.match(mail.html, /19 Oct – 23 Oct 2026|19 Oct – 23 Oct/);
  assert.match(mail.html, /Nairobi, Kenya/);
});

test("unsubscribe stops everything for that address; transactional still allowed", async () => {
  const s = svc();
  await s.captureLead({ leadId: "L1", email: "a@b.co", name: "A", courseSlug: "pmp-prep", courseName: "PMP" }, T0);
  await s.captureLead({ leadId: "L2", email: "a@b.co", name: "A", courseSlug: "data-analysis-excel-power-bi", courseName: "Data" }, T0);
  const token = [...S.followUps.values()][0].token;
  assert.deepEqual(await memoryEmailStore.unsubscribeByToken(token), { email: "a@b.co" });
  assert.equal([...S.followUps.values()].every((f) => f.status === "UNSUBSCRIBED"), true);
  assert.equal((await s.runFollowUps(day(4))).enqueued, 0);
  assert.equal(await memoryEmailStore.unsubscribeByToken("nope"), null);
  // a fresh brochure request after unsubscribing still delivers the brochure but starts no new sequence
  const ids = await s.captureLead({ leadId: "L3", email: "a@b.co", name: "A", courseSlug: "ifrs-financial-reporting", courseName: "IFRS" }, T0);
  assert.equal(await s.deliverMessage(ids[0], T0), "sent");
  assert.equal([...S.followUps.values()].filter((f) => f.status === "ACTIVE").length, 0);
});

test("provider failure is retried, then given up after 3 attempts", async () => {
  const s = svc();
  const [id] = await s.captureLead({ leadId: "L1", email: "a@b.co", name: "A", courseSlug: "pmp-prep", courseName: "PMP" }, T0);
  failNext = 2;
  assert.equal(await s.deliverMessage(id, T0), "failed");
  const t1 = new Date(T0.getTime() + 6 * 60_000);
  assert.equal(await s.deliverMessage(id, new Date(T0.getTime() + 60_000)), "skipped"); // lease not expired yet
  assert.equal(await s.deliverMessage(id, t1), "failed");
  const t2 = new Date(t1.getTime() + 6 * 60_000);
  assert.equal(await s.deliverMessage(id, t2), "sent");                                  // 3rd attempt succeeds
  assert.equal(S.messages.get(id)!.status, "SENT");
  // exhausted attempts are never retried
  const [id2] = await s.captureLead({ leadId: "L9", email: "z@b.co", name: "Z", courseSlug: "pmp-prep", courseName: "PMP" }, t2);
  failNext = 9; let t = t2;
  for (let i = 0; i < 4; i++) { t = new Date(t.getTime() + 6 * 60_000); await s.deliverMessage(id2, t); }
  assert.equal(S.messages.get(id2)!.attempts, 3);
  assert.equal(S.messages.get(id2)!.status, "FAILED");
});

test("webhooks: delivered → opened → clicked; bounce suppresses; duplicates and out-of-order are safe", async () => {
  const s = svc();
  const [id] = await s.captureLead({ leadId: "L1", email: "a@b.co", name: "A", courseSlug: "pmp-prep", courseName: "PMP" }, T0);
  await s.deliverMessage(id, T0);
  const pid = S.messages.get(id)!.providerId!;
  const ev = (n: string, type: "DELIVERED" | "OPENED" | "CLICKED" | "BOUNCED" | "COMPLAINED", extra = {}) => ({ providerEventId: n, providerMessageId: pid, type, occurredAt: new Date(), ...extra });
  assert.equal(await memoryEmailStore.applyEvent(ev("e1", "DELIVERED")), "applied");
  assert.equal(await memoryEmailStore.applyEvent(ev("e1", "DELIVERED")), "duplicate");
  await memoryEmailStore.applyEvent(ev("e2", "OPENED")); await memoryEmailStore.applyEvent(ev("e3", "CLICKED"));
  let m = S.messages.get(id)!;
  assert.equal(m.status, "DELIVERED"); assert.ok(m.openedAt && m.clickedAt && m.deliveredAt);
  assert.equal(await memoryEmailStore.applyEvent({ ...ev("x", "OPENED"), providerMessageId: "unknown" }), "unmatched");
  // transient bounce: status changes but address stays mailable
  await memoryEmailStore.applyEvent(ev("e4", "BOUNCED", { bounceType: "Transient" }));
  assert.equal(S.suppressed.size, 0);
  // permanent bounce suppresses & stops sequences; a late 'delivered' cannot undo it
  await memoryEmailStore.applyEvent(ev("e5", "BOUNCED", { bounceType: "Permanent" }));
  await memoryEmailStore.applyEvent(ev("e6", "DELIVERED"));
  m = S.messages.get(id)!;
  assert.equal(m.status, "BOUNCED");
  assert.equal(S.suppressed.get("a@b.co"), "HARD_BOUNCE");
  assert.equal([...S.followUps.values()].every((f) => f.status === "SUPPRESSED"), true);
  assert.equal((await s.runFollowUps(day(4))).enqueued, 0);
  const [id2] = await s.captureLead({ leadId: "L2", email: "a@b.co", name: "A", courseSlug: "pmp-prep", courseName: "PMP" }, T0);
  assert.equal(await s.deliverMessage(id2, T0), "suppressed");           // even the brochure is withheld from a dead address
  assert.equal(S.messages.get(id2)!.status, "SUPPRESSED");
});

test("stats summarise statuses, opens and sequences", async () => {
  const s = svc();
  const [id] = await s.captureLead({ leadId: "L1", email: "a@b.co", name: "A", courseSlug: "pmp-prep", courseName: "PMP" }, T0);
  await s.deliverMessage(id, T0);
  await memoryEmailStore.applyEvent({ providerEventId: "e1", providerMessageId: S.messages.get(id)!.providerId!, type: "DELIVERED", occurredAt: new Date() });
  const st = await memoryEmailStore.stats();
  assert.equal(st.byStatus.DELIVERED, 1); assert.equal(st.followUps.active, 1); assert.equal(st.followUps.byStage[0].stage, 0);
});

test("a course that disappears ends its sequences quietly; one with no dates waits", async () => {
  const s = createEmailService({ store: memoryEmailStore, repo: { getCourse: async (slug) => (slug === "gone" ? null : slug === "nodates" ? { ...(await mockRepo.getCourse("pmp-prep"))!, schedules: [] } : mockRepo.getCourse(slug)) }, mailer });
  await memoryEmailStore.startFollowUp({ source: "BROCHURE", email: "g@b.co", name: "G", courseSlug: "gone", startedAt: T0, firstDueAt: day(3) });
  await memoryEmailStore.startFollowUp({ source: "BROCHURE", email: "n@b.co", name: "N", courseSlug: "nodates", startedAt: T0, firstDueAt: day(3) });
  const r = await s.runFollowUps(day(3));
  assert.deepEqual([r.stopped, r.waitingForDates, r.enqueued], [1, 1, 0]);
});
