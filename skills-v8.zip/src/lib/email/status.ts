import type { EmailStatus, EmailEventType } from "@prisma/client";

/** Providers deliver webhooks out of order and retry them. A message's status may only move FORWARD. */
const RANK: Record<EmailStatus, number> = {
  QUEUED: 0, SUPPRESSED: 0, FAILED: 1, SENT: 2, DELIVERED: 3, BOUNCED: 4, COMPLAINED: 5,
};

const TARGET: Partial<Record<EmailEventType, EmailStatus>> = {
  SENT: "SENT", DELIVERED: "DELIVERED", BOUNCED: "BOUNCED", COMPLAINED: "COMPLAINED",
};

export function nextStatus(current: EmailStatus, event: EmailEventType): EmailStatus {
  const target = TARGET[event];
  if (!target) return current; // opened / clicked / delayed never change delivery status
  return RANK[target] > RANK[current] ? target : current;
}

/** Permanent bounces and spam complaints must stop all future mail to that address. */
export function shouldSuppress(event: EmailEventType, bounceType?: string | null): "HARD_BOUNCE" | "COMPLAINT" | null {
  if (event === "COMPLAINED") return "COMPLAINT";
  if (event === "BOUNCED" && (bounceType ?? "").toLowerCase().startsWith("perm")) return "HARD_BOUNCE";
  return null;
}
