import type { EmailEventType, EmailStatus, FollowUpStatus } from "@prisma/client";

export type FollowUpSourceT = "BROCHURE" | "REGISTRATION";
export type Template = "brochure" | "registration" | "followup" | "staff-notification";

export interface NewMessage {
  toEmail: string;
  template: Template;
  stage?: number;
  followUpId?: string | null;
  context: Record<string, unknown>;
}

export interface QueuedMessage {
  id: string;
  toEmail: string;
  template: Template;
  stage: number | null;
  followUpId: string | null;
  context: Record<string, unknown>;
  attempts: number;
  unsubscribeToken: string | null;
}

export interface DueFollowUp {
  id: string;
  source: FollowUpSourceT;
  email: string;
  name: string;
  courseSlug: string;
  lastSentStage: number;
  startedAt: Date;
}

export interface ProviderEvent {
  providerEventId: string;
  providerMessageId: string;
  type: EmailEventType;
  occurredAt: Date;
  bounceType?: string | null;
  payload?: unknown;
}

export interface EmailStats {
  total: number;
  byStatus: Record<EmailStatus, number>;
  opened: number;
  clicked: number;
  last30: { sent: number; delivered: number; bounced: number };
  followUps: { active: number; converted: number; unsubscribed: number; suppressed: number; byStage: { stage: number; count: number }[] };
  suppressed: number;
}

export interface MessageRow {
  id: string;
  toEmail: string;
  subject: string;
  template: string;
  stage: number | null;
  status: EmailStatus;
  attempts: number;
  error: string | null;
  createdAt: string;
  sentAt: string | null;
  deliveredAt: string | null;
  openedAt: string | null;
  clickedAt: string | null;
  bounceType: string | null;
}

export interface EmailStore {
  /** Creates (or returns the existing) follow-up sequence. Null when the address is suppressed. */
  startFollowUp(i: { source: FollowUpSourceT; email: string; name: string; courseSlug: string; startedAt: Date; firstDueAt: Date }): Promise<{ id: string; unsubscribeToken: string } | null>;
  /** A registration ends the "still thinking about it" brochure sequence for that course. */
  convertBrochureFollowUps(email: string, courseSlug: string): Promise<void>;

  enqueueMessage(m: NewMessage): Promise<string>;
  dueFollowUps(now: Date, limit: number): Promise<DueFollowUp[]>;
  /**
   * Atomic: advances the sequence AND queues the message together, only if the follow-up is still at
   * `expectedStage`. Returns false if another worker got there first – so no one is ever emailed twice.
   */
  enqueueFollowUpStage(i: { followUpId: string; expectedStage: number; nextStage: number; nextDueAt: Date | null; message: NewMessage; sentAt: Date }): Promise<boolean>;
  stopFollowUp(id: string, status: FollowUpStatus, reason: string): Promise<void>;

  /** Leases one queued/failed message for sending (null if already taken or out of attempts). */
  claimMessage(id: string, now: Date, maxAttempts: number): Promise<QueuedMessage | null>;
  claimQueued(now: Date, limit: number, maxAttempts: number, olderThanMs: number): Promise<QueuedMessage[]>;
  markSent(id: string, subject: string, providerId: string, at: Date): Promise<void>;
  markFailed(id: string, subject: string | null, error: string, now: Date): Promise<void>;
  markSuppressed(id: string): Promise<void>;
  isSuppressed(email: string, scope: "marketing" | "transactional"): Promise<boolean>;

  applyEvent(e: ProviderEvent): Promise<"applied" | "duplicate" | "unmatched">;
  unsubscribeByToken(token: string): Promise<{ email: string } | null>;

  stats(): Promise<EmailStats>;
  listMessages(f: { status?: EmailStatus; q?: string; limit: number }): Promise<MessageRow[]>;
}
