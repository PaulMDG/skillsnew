import type { CourseDetail, Length } from "../types";
import { formatRange, lengthLabel, priceText } from "../format";
import { abs, site } from "../site";

export const esc = (s: string) => s.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;");

export interface Rendered { subject: string; html: string; text: string }

export interface BaseCtx { name: string; course: CourseDetail; unsubscribeUrl?: string }
const first = (name: string) => name.trim().split(/\s+/)[0] || "there";

const BRAND = "#0b835c", DARK = "#08382a", ACCENT = "#ee9f0a", MUTED = "#55665f", LINE = "#e2eae6";

function nextDates(course: CourseDetail, n = 3): { length: Length; start: string; end: string; id: string }[] {
  // soonest first; prefer showing both lengths if offered
  const out: { length: Length; start: string; end: string; id: string }[] = [];
  for (const l of course.lengths) {
    course.schedules.filter((s) => s.length === l).slice(0, l === course.lengths[0] ? n : 1)
      .forEach((s) => out.push({ length: l, start: s.startDate, end: s.endDate, id: s.id }));
  }
  return out.sort((a, b) => a.start.localeCompare(b.start)).slice(0, n + 1);
}

const button = (href: string, label: string) =>
  `<a href="${esc(href)}" style="display:inline-block;background:${BRAND};color:#ffffff;font-weight:600;font-size:15px;text-decoration:none;padding:13px 26px;border-radius:8px">${esc(label)}</a>`;

function layout(o: { preheader: string; heading: string; body: string; unsubscribeUrl?: string }): string {
  return `<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>${esc(o.heading)}</title></head>
<body style="margin:0;background:#f5f8f6;font-family:Arial,Helvetica,sans-serif;color:#11241d">
<span style="display:none;max-height:0;overflow:hidden;opacity:0">${esc(o.preheader)}</span>
<table role="presentation" width="100%" cellpadding="0" cellspacing="0" style="background:#f5f8f6"><tr><td align="center" style="padding:24px 12px">
<table role="presentation" width="600" cellpadding="0" cellspacing="0" style="max-width:600px;width:100%;background:#ffffff;border-radius:14px;overflow:hidden;border:1px solid ${LINE}">
<tr><td style="background:${DARK};padding:22px 32px"><span style="color:#ffffff;font-size:20px;font-weight:700">${esc(site.name)}</span></td></tr>
<tr><td style="padding:32px"><h1 style="margin:0 0 16px;font-size:22px;line-height:1.3;color:${DARK}">${esc(o.heading)}</h1>${o.body}</td></tr>
<tr><td style="padding:20px 32px;background:#f5f8f6;border-top:1px solid ${LINE};font-size:12px;line-height:1.6;color:${MUTED}">
${esc(site.name)} · ${esc(site.email)} · ${esc(site.phone)}<br>${o.unsubscribeUrl ? `Don't want these reminders? <a href="${esc(o.unsubscribeUrl)}" style="color:${MUTED}">Unsubscribe</a>.` : "You are receiving this because you made a request on our website."}
</td></tr></table></td></tr></table></body></html>`;
}

function datesBlock(course: CourseDetail): { html: string; text: string } {
  const rows = nextDates(course);
  if (!rows.length) return { html: `<p style="color:${MUTED}">New dates are being confirmed. Reply to this email and we will tell you the next available start.</p>`, text: "New dates are being confirmed. Reply to this email and we will tell you the next start.\n" };
  const html = `<table role="presentation" width="100%" cellpadding="0" cellspacing="0" style="margin:8px 0 20px;border:1px solid ${LINE};border-radius:10px">${rows.map((r, i) =>
    `<tr><td style="padding:12px 16px;${i ? `border-top:1px solid ${LINE};` : ""}font-size:14px"><strong>${esc(formatRange(r.start, r.end))}</strong><br><span style="color:${MUTED};font-size:13px">Mon–Fri · ${lengthLabel[r.length]} · ${esc(priceText(course.prices[r.length]))}</span></td>
<td align="right" style="padding:12px 16px;${i ? `border-top:1px solid ${LINE};` : ""}"><a href="${esc(abs(`/register?course=${course.slug}&schedule=${encodeURIComponent(r.id)}`))}" style="color:${BRAND};font-weight:600;font-size:14px;text-decoration:none">Register →</a></td></tr>`).join("")}</table>`;
  const text = rows.map((r) => `• ${formatRange(r.start, r.end)} (${lengthLabel[r.length]}, ${priceText(course.prices[r.length])})\n  Register: ${abs(`/register?course=${course.slug}&schedule=${r.id}`)}`).join("\n") + "\n";
  return { html, text };
}

const p = (t: string) => `<p style="margin:0 0 16px;font-size:15px;line-height:1.65;color:#2b3d36">${t}</p>`;

// ───────────── Brochure (requested by the visitor; attachment added by the sender) ─────────────
export function renderBrochure(c: BaseCtx & { downloadUrl: string }): Rendered {
  const d = datesBlock(c.course);
  const subject = `Your brochure: ${c.course.name}`;
  const body = p(`Hi ${esc(first(c.name))},`) + p(`Thank you for your interest in <strong>${esc(c.course.name)}</strong>. Your brochure is attached, and you can also <a href="${esc(c.downloadUrl)}" style="color:${BRAND}">download it here</a>. It includes the full outline and the latest dates.`) +
    `<p style="margin:0 0 8px;font-size:15px;font-weight:600">Upcoming dates</p>` + d.html + `<p style="margin:0 0 24px">${button(abs(`/courses/${c.course.slug}`), "View the course")}</p>` +
    p("Questions about fees, group discounts or in-house training? Just reply to this email.");
  return { subject, html: layout({ preheader: `Brochure and upcoming dates for ${c.course.name}`, heading: `Your ${c.course.name} brochure`, body, unsubscribeUrl: c.unsubscribeUrl }),
    text: `Hi ${first(c.name)},\n\nThank you for your interest in ${c.course.name}. Your brochure is attached and available at ${abs(c.downloadUrl)}\n\nUpcoming dates:\n${d.text}\nCourse page: ${abs(`/courses/${c.course.slug}`)}\n\n${c.unsubscribeUrl ? `Unsubscribe: ${c.unsubscribeUrl}\n` : ""}${site.name}` };
}

// ───────────── Registration confirmation (transactional) ─────────────
export interface RegistrationCtx extends BaseCtx {
  startDate: string; endDate: string; length: Length; deliveryMode: "CLASSROOM" | "ONLINE"; centerName?: string; participants: number;
}
export function renderRegistration(c: RegistrationCtx): Rendered {
  const when = formatRange(c.startDate, c.endDate);
  const where = c.deliveryMode === "ONLINE" ? "Live online" : `Classroom${c.centerName ? ` · ${c.centerName}` : ""}`;
  const body = p(`Hi ${esc(first(c.name))},`) + p(`We have received your registration. Here are the details:`) +
    `<table role="presentation" cellpadding="0" cellspacing="0" style="margin:0 0 20px;font-size:14px;line-height:1.8"><tr><td style="color:${MUTED};padding-right:18px">Course</td><td><strong>${esc(c.course.name)}</strong></td></tr>
<tr><td style="color:${MUTED}">Dates</td><td><strong>${esc(when)}</strong> (Mon–Fri, ${lengthLabel[c.length]})</td></tr>
<tr><td style="color:${MUTED}">Format</td><td>${esc(where)}</td></tr><tr><td style="color:${MUTED}">Participants</td><td>${c.participants}</td></tr>
<tr><td style="color:${MUTED}">Fee</td><td>${esc(priceText(c.course.prices[c.length]))}</td></tr></table>` +
    p("Our team will contact you shortly with the invoice and joining instructions. If anything above is wrong, reply to this email.") +
    `<p style="margin:0">${button(abs(`/courses/${c.course.slug}`), "View course details")}</p>`;
  return { subject: `Registration received: ${c.course.name} (${when})`, html: layout({ preheader: `Your place on ${c.course.name} starting ${when}`, heading: "Registration received", body, unsubscribeUrl: c.unsubscribeUrl }),
    text: `Hi ${first(c.name)},\n\nWe have received your registration.\n\nCourse: ${c.course.name}\nDates: ${when} (Mon–Fri, ${lengthLabel[c.length]})\nFormat: ${where}\nParticipants: ${c.participants}\nFee: ${priceText(c.course.prices[c.length])}\n\nOur team will contact you with the invoice and joining instructions.\n\n${site.name}` };
}

// ───────────── Follow-up sequence ─────────────
export interface FollowUpCtx extends BaseCtx { stage: number; source: "BROCHURE" | "REGISTRATION" }

function copy(stage: number, source: FollowUpCtx["source"], course: string): { subject: string; heading: string; intro: string } {
  const reg = source === "REGISTRATION";
  if (stage === 1) return reg
    ? { subject: `Reminder: your registration for ${course}`, heading: "Your registration is on file", intro: `A quick reminder that you registered for <strong>${esc(course)}</strong>. Here are the dates currently open, in case you would like to confirm or change yours.` }
    : { subject: `Still thinking about ${course}?`, heading: `Still thinking about ${course}?`, intro: `You recently downloaded our brochure for <strong>${esc(course)}</strong>. Here are the next start dates so you can pick one while seats are available.` };
  if (stage === 2) return reg
    ? { subject: `Dates available for ${course}`, heading: "Available dates for your course", intro: `Here is the current schedule for <strong>${esc(course)}</strong>. Colleagues are welcome to join you; group rates are available.` }
    : { subject: `Seats are filling for ${course}`, heading: "Seats are filling up", intro: `Classes for <strong>${esc(course)}</strong> run every week, but individual dates fill up. These are the next available starts.` };
  if (stage === 3) return { subject: `Next dates for ${course}`, heading: `Next dates for ${course}`, intro: `It has been two weeks, so here is a fresh look at the upcoming dates for <strong>${esc(course)}</strong>. If a date does not suit you, reply and we will find an alternative, or arrange in-house training for your team.` };
  return { subject: `${course}: upcoming dates`, heading: `${course}: upcoming dates`, intro: `A periodic update on dates for <strong>${esc(course)}</strong>. We run new Monday starts every week, in the classroom and online.` };
}

export function renderFollowUp(c: FollowUpCtx): Rendered {
  const k = copy(c.stage, c.source, c.course.name);
  const d = datesBlock(c.course);
  const body = p(`Hi ${esc(first(c.name))},`) + p(k.intro) + d.html +
    `<p style="margin:0 0 24px">${button(abs(`/courses/${c.course.slug}#schedule`), "See all dates")}</p>` +
    p(`Questions? Reply to this email. We are happy to help.`);
  return { subject: k.subject, html: layout({ preheader: k.heading, heading: k.heading, body, unsubscribeUrl: c.unsubscribeUrl }),
    text: `Hi ${first(c.name)},\n\n${k.intro.replace(/<[^>]+>/g, "")}\n\n${d.text}\nAll dates: ${abs(`/courses/${c.course.slug}#schedule`)}\n\n${c.unsubscribeUrl ? `Unsubscribe: ${c.unsubscribeUrl}\n` : ""}${site.name}` };
}

// ───────────── Internal notification ─────────────
export function renderStaffNotification(c: { kind: "registration" | "brochure"; name: string; email: string; phone?: string; courseName: string; detail?: string }): Rendered {
  const label = c.kind === "registration" ? "New registration" : "New brochure download";
  const rows = [["Name", c.name], ["Email", c.email], ["Phone", c.phone ?? "—"], ["Course", c.courseName], ...(c.detail ? [["Details", c.detail]] : [])];
  return { subject: `${label}: ${c.name} — ${c.courseName}`,
    html: layout({ preheader: label, heading: label, body: `<table role="presentation" cellpadding="0" cellspacing="0" style="font-size:14px;line-height:1.9">${rows.map(([k, v]) => `<tr><td style="color:${MUTED};padding-right:18px">${k}</td><td><strong>${esc(v)}</strong></td></tr>`).join("")}</table>` }),
    text: rows.map(([k, v]) => `${k}: ${v}`).join("\n") };
}
