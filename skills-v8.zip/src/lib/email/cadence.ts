/**
 * Follow-up cadence, measured from the moment the person registered / downloaded the brochure:
 *   Stage 1 = +3 days     Stage 2 = +7 days     Stage 3 = +14 days
 *   Stage 4 = +2 months   Stage 5 = +3 months   Stage 6+ = one more every month after that
 * A hard cap (FOLLOWUP_MAX_STAGE, default 12) stops it running forever for people who never engage –
 * endless mail to cold contacts damages sender reputation for everyone.
 */
export const MAX_STAGE = Number(process.env.FOLLOWUP_MAX_STAGE ?? 12);

const DAY = 86_400_000;

/** Calendar-month arithmetic that clamps (31 Jan + 1 month = 28/29 Feb, not 3 Mar). */
export function addMonths(d: Date, n: number): Date {
  const out = new Date(d.getTime());
  const day = out.getUTCDate();
  out.setUTCDate(1);
  out.setUTCMonth(out.getUTCMonth() + n);
  const last = new Date(Date.UTC(out.getUTCFullYear(), out.getUTCMonth() + 1, 0)).getUTCDate();
  out.setUTCDate(Math.min(day, last));
  return out;
}

/** When stage `stage` (1-based) is due, relative to `start`. */
export function stageDueAt(start: Date, stage: number): Date {
  if (stage < 1) throw new Error("Stages start at 1");
  if (stage === 1) return new Date(start.getTime() + 3 * DAY);
  if (stage === 2) return new Date(start.getTime() + 7 * DAY);
  if (stage === 3) return new Date(start.getTime() + 14 * DAY);
  return addMonths(start, stage - 2); // 4 → +2 months, 5 → +3 months, 6 → +4 months …
}

/** Due time of the stage AFTER `lastSentStage`, or null when the sequence is finished. */
export function nextDueAt(start: Date, lastSentStage: number, max = MAX_STAGE): Date | null {
  const next = lastSentStage + 1;
  return next > max ? null : stageDueAt(start, next);
}

/**
 * Follow-ups are only released during business hours in Nairobi (UTC+3): Monday–Friday, 08:00–17:59.
 * Anything due outside the window simply waits for the next hourly run inside it.
 */
export function isSendWindow(now: Date): boolean {
  const n = new Date(now.getTime() + 3 * 3_600_000);
  const dow = n.getUTCDay(); // 0 Sun … 6 Sat
  const h = n.getUTCHours();
  return dow >= 1 && dow <= 5 && h >= 8 && h < 18;
}
