import type { EmailStore } from "./types";

let cached: EmailStore | undefined;

export async function getEmailStore(): Promise<EmailStore> {
  if (cached) return cached;
  cached = process.env.DATABASE_URL
    ? (await import("./store.prisma")).prismaEmailStore
    : (await import("./store.memory")).memoryEmailStore;
  return cached;
}
