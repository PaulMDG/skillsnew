// In-memory implementation for local preview and tests. Behaves like the Prisma store.
import { randomUUID } from "node:crypto";
import type { EmailStatus, FollowUpStatus } from "@prisma/client";
import type { DueFollowUp, EmailStats, EmailStore, MessageRow, NewMessage, ProviderEvent, QueuedMessage, FollowUpSourceT } from "./types";
import { nextStatus, shouldSuppress } from "./status";

interface FU { id: string; source: FollowUpSourceT; email: string; name: string; courseSlug: string; lastSentStage: number; startedAt: Date; nextDueAt: Date | null; status: FollowUpStatus; token: string; reason?: string }
interface Msg { id: string; followUpId: string | null; toEmail: string; subject: string; template: string; stage: number | null; context: Record<string, unknown>; providerId: string | null; status: EmailStatus; attempts: number; error: string | null; lockedUntil: Date | null; createdAt: Date; sentAt: Date | null; deliveredAt: Date | null; openedAt: Date | null; clickedAt: Date | null; bouncedAt: Date | null; bounceType: string | null }
interface State { followUps: Map<string, FU>; messages: Map<string, Msg>; events: Set<string>; suppressed: Map<string, "HARD_BOUNCE" | "COMPLAINT" | "UNSUBSCRIBED"> }

const g = globalThis as unknown as { __emailState?: State };
const S: State = (g.__emailState ??= { followUps: new Map(), messages: new Map(), events: new Set(), suppressed: new Map() });
const norm = (e: string) => e.trim().toLowerCase();

const toQueued = (m: Msg): QueuedMessage => ({
  id: m.id, toEmail: m.toEmail, template: m.template as QueuedMessage["template"], stage: m.stage, followUpId: m.followUpId,
  context: m.context, attempts: m.attempts, unsubscribeToken: (m.followUpId && S.followUps.get(m.followUpId)?.token) || null,
});

function stopAllFor(email: string, reason: string) {
  for (const f of S.followUps.values()) if (f.email === email && f.status === "ACTIVE") { f.status = "SUPPRESSED"; f.reason = reason; }
}

export const memoryEmailStore: EmailStore = {
  async startFollowUp(i) {
    const email = norm(i.email);
    if (await this.isSuppressed(email, "marketing")) return null;
    const existing = [...S.followUps.values()].find((f) => f.email === email && f.source === i.source && f.courseSlug === i.courseSlug);
    if (existing) return { id: existing.id, unsubscribeToken: existing.token };
    const f: FU = { id: randomUUID(), source: i.source, email, name: i.name, courseSlug: i.courseSlug, lastSentStage: 0, startedAt: i.startedAt, nextDueAt: i.firstDueAt, status: "ACTIVE", token: randomUUID().replace(/-/g, "") };
    S.followUps.set(f.id, f);
    return { id: f.id, unsubscribeToken: f.token };
  },

  async convertBrochureFollowUps(email, courseSlug) {
    for (const f of S.followUps.values()) if (f.email === norm(email) && f.courseSlug === courseSlug && f.source === "BROCHURE" && f.status === "ACTIVE") { f.status = "CONVERTED"; f.reason = "registered"; }
  },

  async enqueueMessage(m: NewMessage) {
    const id = randomUUID();
    S.messages.set(id, { id, followUpId: m.followUpId ?? null, toEmail: norm(m.toEmail), subject: "", template: m.template, stage: m.stage ?? null, context: m.context, providerId: null, status: "QUEUED", attempts: 0, error: null, lockedUntil: null, createdAt: new Date(), sentAt: null, deliveredAt: null, openedAt: null, clickedAt: null, bouncedAt: null, bounceType: null });
    return id;
  },

  async dueFollowUps(now, limit): Promise<DueFollowUp[]> {
    return [...S.followUps.values()].filter((f) => f.status === "ACTIVE" && f.nextDueAt && f.nextDueAt <= now)
      .sort((a, b) => a.nextDueAt!.getTime() - b.nextDueAt!.getTime()).slice(0, limit)
      .map((f) => ({ id: f.id, source: f.source, email: f.email, name: f.name, courseSlug: f.courseSlug, lastSentStage: f.lastSentStage, startedAt: f.startedAt }));
  },

  async enqueueFollowUpStage(i) {
    const f = S.followUps.get(i.followUpId);
    if (!f || f.status !== "ACTIVE" || f.lastSentStage !== i.expectedStage) return false;
    f.lastSentStage = i.nextStage; f.nextDueAt = i.nextDueAt;
    if (!i.nextDueAt) { f.status = "COMPLETED"; f.reason = "sequence complete"; } // finished: nothing more to send
    await this.enqueueMessage({ ...i.message, followUpId: f.id, stage: i.nextStage });
    return true;
  },

  async stopFollowUp(id, status, reason) { const f = S.followUps.get(id); if (f) { f.status = status; f.reason = reason; } },

  async claimMessage(id, now, maxAttempts) {
    const m = S.messages.get(id);
    if (!m || !["QUEUED", "FAILED"].includes(m.status) || m.attempts >= maxAttempts || (m.lockedUntil && m.lockedUntil > now)) return null;
    m.attempts += 1; m.lockedUntil = new Date(now.getTime() + 5 * 60_000);
    return toQueued(m);
  },

  async claimQueued(now, limit, maxAttempts, olderThanMs) {
    const ids = [...S.messages.values()].filter((m) => ["QUEUED", "FAILED"].includes(m.status) && m.attempts < maxAttempts && now.getTime() - m.createdAt.getTime() >= olderThanMs).slice(0, limit).map((m) => m.id);
    const out: QueuedMessage[] = [];
    for (const id of ids) { const c = await this.claimMessage(id, now, maxAttempts); if (c) out.push(c); }
    return out;
  },

  async markSent(id, subject, providerId, at) { const m = S.messages.get(id); if (m) { m.status = nextStatus(m.status, "SENT"); m.subject = subject; m.providerId = providerId; m.sentAt = at; m.error = null; m.lockedUntil = null; } },
  async markFailed(id, subject, error, now) { const m = S.messages.get(id); if (m) { m.status = "FAILED"; if (subject) m.subject = subject; m.error = error.slice(0, 500); m.lockedUntil = new Date(now.getTime() + 5 * 60_000); } },
  async markSuppressed(id) { const m = S.messages.get(id); if (m) { m.status = "SUPPRESSED"; m.lockedUntil = null; } },

  async isSuppressed(email, scope) {
    const r = S.suppressed.get(norm(email));
    return !!r && (scope === "marketing" || r !== "UNSUBSCRIBED");
  },

  async applyEvent(e: ProviderEvent) {
    if (S.events.has(e.providerEventId)) return "duplicate";
    const m = [...S.messages.values()].find((x) => x.providerId === e.providerMessageId);
    if (!m) return "unmatched";
    S.events.add(e.providerEventId);
    m.status = nextStatus(m.status, e.type);
    if (e.type === "DELIVERED") m.deliveredAt ??= e.occurredAt;
    if (e.type === "OPENED") m.openedAt ??= e.occurredAt;
    if (e.type === "CLICKED") m.clickedAt ??= e.occurredAt;
    if (e.type === "BOUNCED") { m.bouncedAt ??= e.occurredAt; m.bounceType = e.bounceType ?? m.bounceType; }
    const sup = shouldSuppress(e.type, e.bounceType);
    if (sup) { S.suppressed.set(m.toEmail, sup); stopAllFor(m.toEmail, sup); }
    return "applied";
  },

  async unsubscribeByToken(token) {
    const f = [...S.followUps.values()].find((x) => x.token === token);
    if (!f) return null;
    S.suppressed.set(f.email, S.suppressed.get(f.email) ?? "UNSUBSCRIBED");
    for (const x of S.followUps.values()) if (x.email === f.email && x.status === "ACTIVE") { x.status = "UNSUBSCRIBED"; x.reason = "unsubscribed"; }
    return { email: f.email };
  },

  async stats(): Promise<EmailStats> {
    const byStatus = { QUEUED: 0, SUPPRESSED: 0, SENT: 0, DELIVERED: 0, BOUNCED: 0, COMPLAINED: 0, FAILED: 0 } as Record<EmailStatus, number>;
    const msgs = [...S.messages.values()];
    msgs.forEach((m) => byStatus[m.status]++);
    const since = Date.now() - 30 * 86_400_000;
    const recent = msgs.filter((m) => m.createdAt.getTime() >= since);
    const fus = [...S.followUps.values()];
    const stage = new Map<number, number>();
    fus.filter((f) => f.status === "ACTIVE").forEach((f) => stage.set(f.lastSentStage, (stage.get(f.lastSentStage) ?? 0) + 1));
    const count = (s: FollowUpStatus) => fus.filter((f) => f.status === s).length;
    return {
      total: msgs.length, byStatus, opened: msgs.filter((m) => m.openedAt).length, clicked: msgs.filter((m) => m.clickedAt).length,
      last30: { sent: recent.filter((m) => m.sentAt).length, delivered: recent.filter((m) => m.deliveredAt).length, bounced: recent.filter((m) => m.status === "BOUNCED").length },
      followUps: { active: count("ACTIVE"), converted: count("CONVERTED"), unsubscribed: count("UNSUBSCRIBED"), suppressed: count("SUPPRESSED"), byStage: [...stage].map(([s, c]) => ({ stage: s, count: c })).sort((a, b) => a.stage - b.stage) },
      suppressed: S.suppressed.size,
    };
  },

  async listMessages({ status, q, limit }): Promise<MessageRow[]> {
    return [...S.messages.values()].filter((m) => (!status || m.status === status) && (!q || m.toEmail.includes(q.toLowerCase())))
      .sort((a, b) => b.createdAt.getTime() - a.createdAt.getTime()).slice(0, limit)
      .map((m) => ({ id: m.id, toEmail: m.toEmail, subject: m.subject, template: m.template, stage: m.stage, status: m.status, attempts: m.attempts, error: m.error, createdAt: m.createdAt.toISOString(), sentAt: m.sentAt?.toISOString() ?? null, deliveredAt: m.deliveredAt?.toISOString() ?? null, openedAt: m.openedAt?.toISOString() ?? null, clickedAt: m.clickedAt?.toISOString() ?? null, bounceType: m.bounceType }));
  },
};

/** test helper */
export const __memoryEmailState = S;
