import { Prisma, type EmailStatus, type FollowUpStatus } from "@prisma/client";
import { prisma } from "../db";
import type { EmailStats, EmailStore, MessageRow, NewMessage, QueuedMessage } from "./types";
import { nextStatus, shouldSuppress } from "./status";

const norm = (e: string) => e.trim().toLowerCase();
const json = (v: Record<string, unknown>) => v as Prisma.InputJsonValue;
const LEASE_MS = 5 * 60_000;

type MsgWithFu = Prisma.EmailMessageGetPayload<{ include: { followUp: { select: { unsubscribeToken: true } } } }>;
const toQueued = (m: MsgWithFu): QueuedMessage => ({
  id: m.id, toEmail: m.toEmail, template: m.template as QueuedMessage["template"], stage: m.stage, followUpId: m.followUpId,
  context: (m.context ?? {}) as Record<string, unknown>, attempts: m.attempts, unsubscribeToken: m.followUp?.unsubscribeToken ?? null,
});

const msgData = (m: NewMessage, stage?: number | null, followUpId?: string | null) => ({
  followUpId: followUpId ?? m.followUpId ?? null, toEmail: norm(m.toEmail), subject: "", template: m.template,
  stage: stage ?? m.stage ?? null, context: json(m.context),
});

export const prismaEmailStore: EmailStore = {
  async startFollowUp(i) {
    const email = norm(i.email);
    if (await this.isSuppressed(email, "marketing")) return null;
    const course = await prisma.course.findUnique({ where: { slug: i.courseSlug }, select: { id: true } });
    if (!course) return null;
    return prisma.followUp.upsert({
      where: { email_source_courseId: { email, source: i.source, courseId: course.id } },
      update: {},
      create: { source: i.source, email, name: i.name, courseId: course.id, nextSendAt: i.firstDueAt, createdAt: i.startedAt },
      select: { id: true, unsubscribeToken: true },
    }).then((f) => ({ id: f.id, unsubscribeToken: f.unsubscribeToken }));
  },

  async convertBrochureFollowUps(email, courseSlug) {
    await prisma.followUp.updateMany({
      where: { email: norm(email), source: "BROCHURE", status: "ACTIVE", course: { slug: courseSlug } },
      data: { status: "CONVERTED", stoppedReason: "registered" },
    });
  },

  async enqueueMessage(m) {
    return (await prisma.emailMessage.create({ data: msgData(m), select: { id: true } })).id;
  },

  async dueFollowUps(now, limit) {
    const rows = await prisma.followUp.findMany({
      where: { status: "ACTIVE", nextSendAt: { lte: now } },
      orderBy: { nextSendAt: "asc" }, take: limit,
      select: { id: true, source: true, email: true, name: true, lastSentStage: true, createdAt: true, course: { select: { slug: true } } },
    });
    return rows.map((r) => ({ id: r.id, source: r.source, email: r.email, name: r.name, courseSlug: r.course.slug, lastSentStage: r.lastSentStage, startedAt: r.createdAt }));
  },

  async enqueueFollowUpStage(i) {
    return prisma.$transaction(async (tx) => {
      const r = await tx.followUp.updateMany({
        where: { id: i.followUpId, status: "ACTIVE", lastSentStage: i.expectedStage },
        data: { lastSentStage: i.nextStage, lastSentAt: i.sentAt, nextSendAt: i.nextDueAt, ...(i.nextDueAt ? {} : { status: "COMPLETED" as const, stoppedReason: "sequence complete" }) },
      });
      if (r.count !== 1) return false; // someone else already advanced it
      await tx.emailMessage.create({ data: msgData(i.message, i.nextStage, i.followUpId) });
      return true;
    });
  },

  async stopFollowUp(id, status: FollowUpStatus, reason) {
    await prisma.followUp.update({ where: { id }, data: { status, stoppedReason: reason } });
  },

  async claimMessage(id, now, maxAttempts) {
    const r = await prisma.emailMessage.updateMany({
      where: { id, status: { in: ["QUEUED", "FAILED"] }, attempts: { lt: maxAttempts }, OR: [{ lockedUntil: null }, { lockedUntil: { lt: now } }] },
      data: { attempts: { increment: 1 }, lockedUntil: new Date(now.getTime() + LEASE_MS) },
    });
    if (r.count !== 1) return null;
    const m = await prisma.emailMessage.findUnique({ where: { id }, include: { followUp: { select: { unsubscribeToken: true } } } });
    return m && toQueued(m);
  },

  async claimQueued(now, limit, maxAttempts, olderThanMs) {
    const ids = await prisma.emailMessage.findMany({
      where: {
        status: { in: ["QUEUED", "FAILED"] }, attempts: { lt: maxAttempts }, createdAt: { lte: new Date(now.getTime() - olderThanMs) },
        OR: [{ lockedUntil: null }, { lockedUntil: { lt: now } }],
      },
      orderBy: { createdAt: "asc" }, take: limit, select: { id: true },
    });
    const out: QueuedMessage[] = [];
    for (const { id } of ids) { const c = await this.claimMessage(id, now, maxAttempts); if (c) out.push(c); }
    return out;
  },

  async markSent(id, subject, providerId, at) {
    await prisma.emailMessage.update({ where: { id }, data: { subject, providerId, sentAt: at, error: null, lockedUntil: null } });
    // only QUEUED/FAILED → SENT: if the delivered webhook already beat us here, do not downgrade it
    await prisma.emailMessage.updateMany({ where: { id, status: { in: ["QUEUED", "FAILED"] } }, data: { status: "SENT" } });
  },

  async markFailed(id, subject, error, now) {
    await prisma.emailMessage.update({ where: { id }, data: { status: "FAILED", error: error.slice(0, 500), ...(subject ? { subject } : {}), lockedUntil: new Date(now.getTime() + LEASE_MS) } });
  },

  async markSuppressed(id) {
    await prisma.emailMessage.update({ where: { id }, data: { status: "SUPPRESSED", lockedUntil: null } });
  },

  async isSuppressed(email, scope) {
    const r = await prisma.emailSuppression.findUnique({ where: { email: norm(email) } });
    return !!r && (scope === "marketing" || r.reason !== "UNSUBSCRIBED");
  },

  async applyEvent(e) {
    const msg = await prisma.emailMessage.findUnique({ where: { providerId: e.providerMessageId } });
    if (!msg) return "unmatched";
    try {
      await prisma.emailEvent.create({ data: { messageId: msg.id, type: e.type, providerEventId: e.providerEventId, occurredAt: e.occurredAt, payload: (e.payload ?? undefined) as Prisma.InputJsonValue | undefined } });
    } catch (err) {
      if (err instanceof Prisma.PrismaClientKnownRequestError && err.code === "P2002") return "duplicate"; // webhook retry
      throw err;
    }
    const data: Prisma.EmailMessageUpdateInput = {};
    const ns: EmailStatus = nextStatus(msg.status, e.type);
    if (ns !== msg.status) data.status = ns;
    if (e.type === "DELIVERED" && !msg.deliveredAt) data.deliveredAt = e.occurredAt;
    if (e.type === "OPENED" && !msg.firstOpenedAt) data.firstOpenedAt = e.occurredAt;
    if (e.type === "CLICKED" && !msg.firstClickedAt) data.firstClickedAt = e.occurredAt;
    if (e.type === "BOUNCED") { if (!msg.bouncedAt) data.bouncedAt = e.occurredAt; if (e.bounceType) data.bounceType = e.bounceType; }
    if (Object.keys(data).length) await prisma.emailMessage.update({ where: { id: msg.id }, data });

    const sup = shouldSuppress(e.type, e.bounceType);
    if (sup) {
      await prisma.emailSuppression.upsert({ where: { email: msg.toEmail }, update: {}, create: { email: msg.toEmail, reason: sup } });
      await prisma.followUp.updateMany({ where: { email: msg.toEmail, status: "ACTIVE" }, data: { status: "SUPPRESSED", stoppedReason: sup } });
    }
    return "applied";
  },

  async unsubscribeByToken(token) {
    const f = await prisma.followUp.findUnique({ where: { unsubscribeToken: token }, select: { email: true } });
    if (!f) return null;
    await prisma.emailSuppression.upsert({ where: { email: f.email }, update: {}, create: { email: f.email, reason: "UNSUBSCRIBED" } });
    await prisma.followUp.updateMany({ where: { email: f.email, status: "ACTIVE" }, data: { status: "UNSUBSCRIBED", stoppedReason: "unsubscribed" } });
    return { email: f.email };
  },

  async stats(): Promise<EmailStats> {
    const since = new Date(Date.now() - 30 * 86_400_000);
    const [groups, opened, clicked, sent30, delivered30, bounced30, fuGroups, stages, suppressed] = await Promise.all([
      prisma.emailMessage.groupBy({ by: ["status"], _count: true }),
      prisma.emailMessage.count({ where: { firstOpenedAt: { not: null } } }),
      prisma.emailMessage.count({ where: { firstClickedAt: { not: null } } }),
      prisma.emailMessage.count({ where: { sentAt: { gte: since } } }),
      prisma.emailMessage.count({ where: { deliveredAt: { gte: since } } }),
      prisma.emailMessage.count({ where: { bouncedAt: { gte: since } } }),
      prisma.followUp.groupBy({ by: ["status"], _count: true }),
      prisma.followUp.groupBy({ by: ["lastSentStage"], where: { status: "ACTIVE" }, _count: true, orderBy: { lastSentStage: "asc" } }),
      prisma.emailSuppression.count(),
    ]);
    const byStatus = { QUEUED: 0, SUPPRESSED: 0, SENT: 0, DELIVERED: 0, BOUNCED: 0, COMPLAINED: 0, FAILED: 0 } as Record<EmailStatus, number>;
    groups.forEach((g) => { byStatus[g.status] = g._count; });
    const fu = (s: FollowUpStatus) => fuGroups.find((g) => g.status === s)?._count ?? 0;
    return {
      total: Object.values(byStatus).reduce((a, b) => a + b, 0), byStatus, opened, clicked,
      last30: { sent: sent30, delivered: delivered30, bounced: bounced30 },
      followUps: { active: fu("ACTIVE"), converted: fu("CONVERTED"), unsubscribed: fu("UNSUBSCRIBED"), suppressed: fu("SUPPRESSED"), byStage: stages.map((s) => ({ stage: s.lastSentStage, count: s._count })) },
      suppressed,
    };
  },

  async listMessages({ status, q, limit }): Promise<MessageRow[]> {
    const rows = await prisma.emailMessage.findMany({
      where: { ...(status ? { status } : {}), ...(q ? { toEmail: { contains: q, mode: "insensitive" as const } } : {}) },
      orderBy: { createdAt: "desc" }, take: limit,
    });
    return rows.map((m) => ({
      id: m.id, toEmail: m.toEmail, subject: m.subject, template: m.template, stage: m.stage, status: m.status, attempts: m.attempts, error: m.error,
      createdAt: m.createdAt.toISOString(), sentAt: m.sentAt?.toISOString() ?? null, deliveredAt: m.deliveredAt?.toISOString() ?? null,
      openedAt: m.firstOpenedAt?.toISOString() ?? null, clickedAt: m.firstClickedAt?.toISOString() ?? null, bounceType: m.bounceType,
    }));
  },
};
