import { z } from "zod";
import type { CourseInput, CategoryInput, Length, PriceMap } from "./types";

/** "Project Management & M&E (Advanced)" → "project-management-m-e-advanced" */
export function slugify(s: string): string {
  return s.normalize("NFKD").replace(/[\u0300-\u036f]/g, "").toLowerCase().replace(/&/g, " and ").replace(/[^a-z0-9]+/g, "-").replace(/^-+|-+$/g, "").slice(0, 120);
}

/**
 * Outline textarea format – modules separated by a blank line; first line = title, the rest = description:
 *   Module 1 – Foundations
 *   Key concepts and terminology.
 *
 *   Module 2 – Core methods
 */
export function parseOutline(text: string): { title: string; body?: string }[] {
  return text.replace(/\r/g, "").split(/\n\s*\n/).map((blk) => blk.trim()).filter(Boolean).map((blk) => {
    const [title, ...rest] = blk.split("\n");
    const body = rest.join("\n").trim();
    return { title: title.trim().slice(0, 200), ...(body ? { body: body.slice(0, 3000) } : {}) };
  }).slice(0, 40);
}

export const outlineToText = (o: { title: string; body?: string | null }[]) => o.map((m) => (m.body ? `${m.title}\n${m.body}` : m.title)).join("\n\n");

const money = z.preprocess((v) => (v === "" || v == null ? undefined : Number(String(v).replace(/,/g, ""))), z.number().min(0).max(100_000_000).optional());
const opt = (max: number) => z.string().trim().max(max).optional().transform((v) => v || undefined);
const httpsUrl = z.string().trim().max(500).optional().transform((v) => v || undefined).refine((v) => !v || /^https:\/\/[^\s]+$/.test(v), "Use a full https:// link");
const checks = <T extends string>(vals: readonly [T, ...T[]]) => z.preprocess((v) => (Array.isArray(v) ? v : v == null || v === "" ? [] : [v]), z.array(z.enum(vals)));
const slugRule = z.string().trim().toLowerCase().max(120).regex(/^[a-z0-9]+(?:-[a-z0-9]+)*$/, "Lowercase letters, numbers and hyphens only");

export const courseFormSchema = z.object({
  id: opt(60),
  name: z.string().trim().min(3, "Enter the course name").max(150),
  slug: z.string().trim().max(120).optional(),
  categoryId: z.string().trim().min(1, "Choose a category"),
  summary: opt(300),
  description: z.string().trim().min(20, "Write at least a short description").max(20_000),
  objectives: opt(5000), targetAudience: opt(5000), methodology: opt(5000),
  imageUrl: httpsUrl,
  lengths: checks(["FIVE_DAY", "TEN_DAY"]),
  deliveryModes: checks(["CLASSROOM", "ONLINE"]),
  autoSchedule: z.preprocess((v) => v === "on", z.boolean()),
  status: z.enum(["DRAFT", "PUBLISHED", "ARCHIVED"]),
  metaTitle: opt(70), metaDescription: opt(320), metaKeywords: opt(500),
  outline: z.string().max(30_000).optional().default(""),
  price5Kes: money, price5Usd: money, price10Kes: money, price10Usd: money,
});

export function toCourseInput(d: z.infer<typeof courseFormSchema>): { ok: true; value: CourseInput } | { ok: false; fieldErrors: Record<string, string[]> } {
  const slug = d.id ? (d.slug ? d.slug : "") : slugify(d.slug || d.name);
  const sr = slugRule.safeParse(slug);
  if (!d.id && !sr.success) return { ok: false, fieldErrors: { slug: [sr.error.issues[0].message] } };
  const pm = (kes?: number, usd?: number): PriceMap | undefined => (kes == null && usd == null ? undefined : { ...(kes != null ? { KES: kes } : {}), ...(usd != null ? { USD: usd } : {}) });
  const prices: CourseInput["prices"] = {};
  const p5 = pm(d.price5Kes, d.price5Usd), p10 = pm(d.price10Kes, d.price10Usd);
  if (p5) prices.FIVE_DAY = p5;
  if (p10) prices.TEN_DAY = p10;
  const errs: Record<string, string[]> = {};
  if (d.status === "PUBLISHED" && !d.lengths.length) errs.lengths = ["Choose at least one length before publishing"];
  if (d.status === "PUBLISHED" && !d.deliveryModes.length) errs.deliveryModes = ["Choose at least one delivery mode"];
  if (Object.keys(errs).length) return { ok: false, fieldErrors: errs };
  const { price5Kes, price5Usd, price10Kes, price10Usd, outline, ...rest } = d;
  void price5Kes; void price5Usd; void price10Kes; void price10Usd;
  return { ok: true, value: { ...rest, slug, lengths: d.lengths as Length[], prices, outline: parseOutline(outline) } };
}

export const categoryFormSchema = z.object({
  id: opt(60),
  name: z.string().trim().min(2, "Enter the category name").max(100),
  slug: z.string().trim().max(120).optional(),
  description: opt(1000), iconKey: opt(40), imageUrl: httpsUrl,
  metaTitle: opt(70), metaDescription: opt(320), metaKeywords: opt(500),
  sortOrder: z.preprocess((v) => (v === "" || v == null ? 0 : Number(v)), z.number().int().min(0).max(9999)),
  status: z.enum(["DRAFT", "PUBLISHED", "ARCHIVED"]),
});

export function toCategoryInput(d: z.infer<typeof categoryFormSchema>): { ok: true; value: CategoryInput } | { ok: false; fieldErrors: Record<string, string[]> } {
  const slug = d.id ? d.slug ?? "" : slugify(d.slug || d.name);
  const sr = slugRule.safeParse(slug);
  if (!d.id && !sr.success) return { ok: false, fieldErrors: { slug: [sr.error.issues[0].message] } };
  return { ok: true, value: { ...d, slug } };
}

/** The icon "library" for categories (name → lucide icon, see CategoryIcon). */
export const ICON_LIBRARY = ["briefcase", "chart", "landmark", "cpu", "users", "truck", "health"] as const;
