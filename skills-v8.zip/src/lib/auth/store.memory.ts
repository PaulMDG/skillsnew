// Local preview only (no database). Seeds one admin: admin@example.com / DEV_ADMIN_PASSWORD.
import { randomUUID } from "node:crypto";
import type { AuditEntry, StaffRecord, StaffStore } from "./types";
import { hashPassword } from "./password";

const g = globalThis as unknown as { __staff?: Map<string, StaffRecord>; __ready?: Promise<void>; __audit?: AuditEntry[] };
const users = (g.__staff ??= new Map<string, StaffRecord>());
const auditLog = (g.__audit ??= []);

const ready = (g.__ready ??= (async () => {
  console.warn("[auth] Using the IN-MEMORY staff store – data is lost on restart. Local preview only.");
  const seed = async (email: string, name: string, role: StaffRecord["role"]) => {
    users.set(email, {
      id: randomUUID(), email, name, role, passwordHash: await hashPassword(process.env.DEV_ADMIN_PASSWORD ?? "dev-password-123456"),
      totpSecretEnc: null, totpEnabled: false, totpLastStep: null, isActive: true, failedLogins: 0, lockedUntil: null, sessionVersion: 0,
    });
  };
  await seed("admin@example.com", "Preview Admin", "ADMIN");
  await seed("marketing@example.com", "Preview Marketing", "MARKETING");
})());

const byId = (id: string) => [...users.values()].find((u) => u.id === id) ?? null;

export const memoryStaffStore: StaffStore = {
  async findByEmail(email) { await ready; return users.get(email) ?? null; },
  async findById(id) { await ready; return byId(id); },
  async recordFailedLogin(id, max, lockMs) {
    const u = byId(id); if (!u) return;
    u.failedLogins += 1;
    if (u.failedLogins >= max) { u.lockedUntil = new Date(Date.now() + lockMs); u.failedLogins = 0; }
  },
  async recordSuccessfulLogin(id) { const u = byId(id); if (u) { u.failedLogins = 0; u.lockedUntil = null; } },
  async consumeTotpStep(id, step) {
    const u = byId(id); if (!u || (u.totpLastStep != null && u.totpLastStep >= step)) return false;
    u.totpLastStep = step; return true;
  },
  async enableTotp(id, enc) { const u = byId(id); if (u) { u.totpSecretEnc = enc; u.totpEnabled = true; } },
  async setPassword(id, hash) { const u = byId(id)!; u.passwordHash = hash; return ++u.sessionVersion; },
  async audit(e) { auditLog.push(e); console.log("[audit]", e.action, e.actorId ?? "-"); },
};
