import { createCipheriv, createDecipheriv, createHash, randomBytes } from "node:crypto";
import { isProd } from "./config";

function key(): Buffer {
  const k = process.env.AUTH_ENCRYPTION_KEY;
  if (k) {
    const b = Buffer.from(k, "base64");
    if (b.length !== 32) throw new Error("AUTH_ENCRYPTION_KEY must be 32 bytes, base64 encoded (openssl rand -base64 32)");
    return b;
  }
  if (isProd) throw new Error("AUTH_ENCRYPTION_KEY is required in production");
  return createHash("sha256").update("dev-only-encryption-key").digest();
}

/** AES-256-GCM. Output: v1.<iv>.<tag>.<ciphertext> (base64url). Used for TOTP secrets at rest. */
export function encrypt(plain: string): string {
  const iv = randomBytes(12);
  const c = createCipheriv("aes-256-gcm", key(), iv);
  const ct = Buffer.concat([c.update(plain, "utf8"), c.final()]);
  return ["v1", iv.toString("base64url"), c.getAuthTag().toString("base64url"), ct.toString("base64url")].join(".");
}

export function decrypt(blob: string): string {
  const [v, iv, tag, ct] = blob.split(".");
  if (v !== "v1" || !iv || !tag || !ct) throw new Error("Bad ciphertext");
  const d = createDecipheriv("aes-256-gcm", key(), Buffer.from(iv, "base64url"));
  d.setAuthTag(Buffer.from(tag, "base64url"));
  return Buffer.concat([d.update(Buffer.from(ct, "base64url")), d.final()]).toString("utf8");
}
