import type { StaffStore } from "./types";
import { isProd } from "./config";

let cached: StaffStore | undefined;

export async function getStaffStore(): Promise<StaffStore> {
  if (cached) return cached;
  if (process.env.DATABASE_URL) cached = (await import("./store.prisma")).prismaStaffStore;
  else if (!isProd || process.env.AUTH_ALLOW_MEMORY_STORE === "1") cached = (await import("./store.memory")).memoryStaffStore;
  else throw new Error("Staff authentication needs DATABASE_URL in production");
  return cached;
}
