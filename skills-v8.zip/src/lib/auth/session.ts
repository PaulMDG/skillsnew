import "server-only";
import { cache } from "react";
import { cookies } from "next/headers";
import { notFound, redirect } from "next/navigation";
import { COOKIE_PENDING, COOKIE_SESSION, SESSION_TTL_S, PENDING_TTL_S, isProd } from "./config";
import { signSession, verifySession } from "./tokens";
import { getStaffStore } from "./store";
import type { Role, StaffSession } from "./types";

const base = { httpOnly: true, secure: isProd, sameSite: "lax" as const };

export async function createSession(user: { id: string; role: Role; sessionVersion: number }) {
  const token = await signSession({ sub: user.id, role: user.role, sv: user.sessionVersion });
  (await cookies()).set(COOKIE_SESSION, token, { ...base, path: "/", maxAge: SESSION_TTL_S });
}

/**
 * Clear by re-setting with the SAME attributes and maxAge 0. A bare `delete` omits `Secure`,
 * and browsers silently ignore removal of a `__Host-` cookie that lacks it – the session would survive logout.
 */
async function expire(name: string, path: string) {
  (await cookies()).set(name, "", { ...base, path, maxAge: 0, expires: new Date(0) });
}

export async function destroySession() {
  await expire(COOKIE_SESSION, "/");
  await expire(COOKIE_PENDING, "/admin");
}

export async function setPendingCookie(token: string) {
  (await cookies()).set(COOKIE_PENDING, token, { ...base, path: "/admin", maxAge: PENDING_TTL_S });
}

export async function clearPendingCookie() {
  await expire(COOKIE_PENDING, "/admin");
}

/**
 * The signed cookie proves who the user is; the database decides whether they are STILL allowed in
 * (account active, role unchanged, no password change since the session was issued).
 */
export const getStaff = cache(async (): Promise<StaffSession | null> => {
  const claims = await verifySession((await cookies()).get(COOKIE_SESSION)?.value);
  if (!claims) return null;
  const user = await (await getStaffStore()).findById(claims.sub);
  if (!user || !user.isActive || user.sessionVersion !== claims.sv || !user.totpEnabled) return null;
  return { id: user.id, email: user.email, name: user.name, role: user.role };
});

/** Call at the top of EVERY admin page and server action – middleware is only the first gate. */
export async function requireStaff(roles?: Role[]): Promise<StaffSession> {
  const staff = await getStaff();
  if (!staff) redirect("/admin/login");
  if (roles && !roles.includes(staff.role)) notFound();
  return staff;
}

export function safeNext(v: unknown): string {
  return typeof v === "string" && v.startsWith("/admin") && !v.startsWith("//") && !v.includes("\\") && !v.startsWith("/admin/login") ? v : "/admin";
}
