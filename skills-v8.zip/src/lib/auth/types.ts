export type Role = "ADMIN" | "EDITOR" | "MARKETING";

export interface StaffRecord {
  id: string;
  email: string;
  name: string;
  passwordHash: string;
  role: Role;
  totpSecretEnc: string | null;
  totpEnabled: boolean;
  totpLastStep: number | null;
  isActive: boolean;
  failedLogins: number;
  lockedUntil: Date | null;
  sessionVersion: number;
}

export interface AuditEntry {
  actorId?: string | null;
  action: string;
  entity?: string;
  entityId?: string;
  ipHash?: string;
  meta?: Record<string, unknown>;
}

export interface StaffStore {
  findByEmail(email: string): Promise<StaffRecord | null>;
  findById(id: string): Promise<StaffRecord | null>;
  /** Increments the failure counter and locks the account once `max` is reached. */
  recordFailedLogin(id: string, max: number, lockMs: number): Promise<void>;
  recordSuccessfulLogin(id: string): Promise<void>;
  /** Atomically accept a TOTP step only if it is newer than the last one used. */
  consumeTotpStep(id: string, step: number): Promise<boolean>;
  enableTotp(id: string, secretEnc: string): Promise<void>;
  /** Returns the new sessionVersion (all older sessions become invalid). */
  setPassword(id: string, passwordHash: string): Promise<number>;
  audit(entry: AuditEntry): Promise<void>;
}

export interface StaffSession {
  id: string;
  email: string;
  name: string;
  role: Role;
}

export type AuthFormState = { error?: string; success?: string };
