import { test } from "node:test";
import assert from "node:assert/strict";

process.env.AUTH_SECRET = "x".repeat(40);
process.env.AUTH_ENCRYPTION_KEY = Buffer.alloc(32, 7).toString("base64");

import { base32Encode, base32Decode, hotp, verifyTotp, stepAt, generateSecret, otpauthUri } from "./totp";
import { encrypt, decrypt } from "./crypto";
import { hashPassword, verifyPassword, validateNewPassword } from "./password";
import { signSession, verifySession, signPending, verifyPending } from "./tokens";

// RFC 6238 appendix B: secret "12345678901234567890", T=59s → 94287082 (8 digits) so 6 digits = 287082
const RFC = base32Encode(Buffer.from("12345678901234567890"));

test("base32 round trip", () => {
  const b = Buffer.from([1, 2, 3, 250, 251, 252, 0, 99]);
  assert.deepEqual(base32Decode(base32Encode(b)), b);
});

test("TOTP matches the RFC 6238 test vectors", () => {
  assert.equal(hotp(RFC, Math.floor(59 / 30), 8), "94287082");
  assert.equal(hotp(RFC, Math.floor(1111111109 / 30), 8), "07081804");
  assert.equal(hotp(RFC, Math.floor(20000000000 / 30), 8), "65353130");
});

test("verifyTotp accepts ±1 step, rejects further, returns the step", () => {
  const now = 1_700_000_000_000, step = stepAt(now);
  assert.equal(verifyTotp(RFC, hotp(RFC, step), now), step);
  assert.equal(verifyTotp(RFC, hotp(RFC, step - 1), now), step - 1);
  assert.equal(verifyTotp(RFC, hotp(RFC, step + 1), now), step + 1);
  assert.equal(verifyTotp(RFC, hotp(RFC, step + 3), now), null);
  assert.equal(verifyTotp(RFC, "abcdef", now), null);
  assert.equal(verifyTotp(RFC, "12345", now), null);
});

test("otpauth URI is well formed", () => {
  const u = otpauthUri(generateSecret(), "a@b.co");
  assert.match(u, /^otpauth:\/\/totp\/Skills%20for%20Africa%3Aa%40b\.co\?secret=[A-Z2-7]{32}&issuer=/);
});

test("encryption round trips and rejects tampering", () => {
  const c = encrypt("JBSWY3DPEHPK3PXP");
  assert.equal(decrypt(c), "JBSWY3DPEHPK3PXP");
  assert.notEqual(encrypt("same"), encrypt("same")); // random IV
  const parts = c.split("."); parts[3] = Buffer.from("tampered").toString("base64url");
  assert.throws(() => decrypt(parts.join(".")));
});

test("argon2id hashing", async () => {
  const h = await hashPassword("correct horse battery");
  assert.match(h, /^\$argon2id\$/);
  assert.equal(await verifyPassword(h, "correct horse battery"), true);
  assert.equal(await verifyPassword(h, "wrong"), false);
  assert.equal(await verifyPassword("not-a-hash", "x"), false);
});

test("password policy", () => {
  assert.ok(validateNewPassword("short", "a@b.co"));
  assert.ok(validateNewPassword("aaaaaaaaaaaaaaaa", "a@b.co"));
  assert.ok(validateNewPassword("johnsmith-secret-99", "johnsmith@x.org"));
  assert.equal(validateNewPassword("Tr4velling-Zebra-Lamp", "jo@x.org"), null);
});

test("session tokens: valid, wrong audience and tampered are handled", async () => {
  const s = await signSession({ sub: "u1", role: "ADMIN", sv: 3 });
  assert.deepEqual(await verifySession(s), { sub: "u1", role: "ADMIN", sv: 3 });
  const p = await signPending({ sub: "u1", sv: 3, purpose: "verify" });
  assert.equal(await verifySession(p), null);               // a pending token can never act as a session
  assert.equal((await verifyPending(s)), null);             // and vice versa
  assert.equal(await verifySession(s.slice(0, -2) + "xx"), null);
  assert.equal(await verifySession(undefined), null);
  assert.equal((await verifyPending(p))?.purpose, "verify");
});
