import { hash, verify } from "@node-rs/argon2";

// argon2id, OWASP minimum profile (19 MiB, t=2, p=1)
const OPTS = { memoryCost: 19456, timeCost: 2, parallelism: 1 };

export const hashPassword = (plain: string) => hash(plain, OPTS);

export async function verifyPassword(hashed: string, plain: string): Promise<boolean> {
  try { return await verify(hashed, plain); } catch { return false; }
}

let dummy: Promise<string> | undefined;
/** Verified against when the email is unknown, so response time doesn't reveal which emails exist. */
export const dummyHash = () => (dummy ??= hashPassword(`dummy-${Math.random()}-${Date.now()}`));

export function validateNewPassword(pw: string, email: string): string | null {
  if (pw.length < 12) return "Use at least 12 characters.";
  if (pw.length > 128) return "Use at most 128 characters.";
  if (pw.toLowerCase().includes(email.split("@")[0].toLowerCase()) && email.split("@")[0].length >= 4) return "Password must not contain your email name.";
  if (/^(.)\1+$/.test(pw) || /^(password|123456|qwerty|letmein|welcome)/i.test(pw)) return "That password is too easy to guess.";
  if (new Set(pw).size < 6) return "Use a more varied password.";
  return null;
}
