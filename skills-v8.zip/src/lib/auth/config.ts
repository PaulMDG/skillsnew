// Edge-safe: imported by middleware, so no Node-only modules here.
export const isProd = process.env.NODE_ENV === "production";

/** `__Host-` prefix (prod): Secure, Path=/, no Domain – the browser refuses to let subdomains overwrite it. */
export const COOKIE_SESSION = isProd ? "__Host-sfa_session" : "sfa_session";
export const COOKIE_PENDING = "sfa_pending";

export const SESSION_TTL_S = 8 * 3600; // 8 hours
export const PENDING_TTL_S = 5 * 60;   // password → 2FA must complete within 5 minutes
export const MAX_FAILED = 5;
export const LOCK_MS = 15 * 60_000;
export const ISSUER = "skills-for-africa";
export const AUD_SESSION = "admin";
export const AUD_PENDING = "admin-pending";

let warned = false;
export function authSecret(): Uint8Array {
  const s = process.env.AUTH_SECRET;
  if (s && s.length >= 32) return new TextEncoder().encode(s);
  if (!isProd) {
    if (!warned) { warned = true; console.warn("[auth] AUTH_SECRET not set – using an insecure development secret"); }
    return new TextEncoder().encode("dev-only-secret-do-not-use-in-production-0000");
  }
  throw new Error("AUTH_SECRET must be set to a random string of at least 32 characters");
}
