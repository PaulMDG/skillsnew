import type { StaffUser } from "@prisma/client";
import { prisma } from "../db";
import type { Role, StaffRecord, StaffStore } from "./types";

const toRecord = (u: StaffUser): StaffRecord => ({
  id: u.id, email: u.email, name: u.name, passwordHash: u.passwordHash, role: u.role as Role,
  totpSecretEnc: u.totpSecret, totpEnabled: u.totpEnabled, totpLastStep: u.totpLastStep, isActive: u.isActive,
  failedLogins: u.failedLogins, lockedUntil: u.lockedUntil, sessionVersion: u.sessionVersion,
});

export const prismaStaffStore: StaffStore = {
  async findByEmail(email) { const u = await prisma.staffUser.findUnique({ where: { email } }); return u && toRecord(u); },
  async findById(id) { const u = await prisma.staffUser.findUnique({ where: { id } }); return u && toRecord(u); },

  async recordFailedLogin(id, max, lockMs) {
    const u = await prisma.staffUser.update({ where: { id }, data: { failedLogins: { increment: 1 } }, select: { failedLogins: true } });
    if (u.failedLogins >= max) {
      await prisma.staffUser.update({ where: { id }, data: { lockedUntil: new Date(Date.now() + lockMs), failedLogins: 0 } });
    }
  },

  async recordSuccessfulLogin(id) {
    await prisma.staffUser.update({ where: { id }, data: { failedLogins: 0, lockedUntil: null, lastLoginAt: new Date() } });
  },

  // Single atomic statement: concurrent replays of the same code cannot both succeed
  async consumeTotpStep(id, step) {
    const r = await prisma.staffUser.updateMany({
      where: { id, OR: [{ totpLastStep: null }, { totpLastStep: { lt: step } }] },
      data: { totpLastStep: step },
    });
    return r.count === 1;
  },

  async enableTotp(id, secretEnc) { await prisma.staffUser.update({ where: { id }, data: { totpSecret: secretEnc, totpEnabled: true } }); },

  async setPassword(id, passwordHash) {
    const u = await prisma.staffUser.update({
      where: { id },
      data: { passwordHash, passwordChangedAt: new Date(), sessionVersion: { increment: 1 }, failedLogins: 0, lockedUntil: null },
      select: { sessionVersion: true },
    });
    return u.sessionVersion;
  },

  async audit(e) {
    await prisma.auditLog.create({
      data: { actorId: e.actorId ?? null, action: e.action, entity: e.entity, entityId: e.entityId, ipHash: e.ipHash, diff: e.meta as object | undefined },
    });
  },
};
