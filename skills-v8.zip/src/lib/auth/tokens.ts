// Edge-safe (jose only). Session = fully authenticated. Pending = password OK, 2FA outstanding.
import { SignJWT, jwtVerify } from "jose";
import { AUD_PENDING, AUD_SESSION, ISSUER, PENDING_TTL_S, SESSION_TTL_S, authSecret } from "./config";
import type { Role } from "./types";

export interface SessionClaims { sub: string; role: Role; sv: number }
export interface PendingClaims { sub: string; sv: number; purpose: "verify" | "enroll"; enc?: string }

export function signSession(c: SessionClaims): Promise<string> {
  return new SignJWT({ role: c.role, sv: c.sv })
    .setProtectedHeader({ alg: "HS256" }).setSubject(c.sub).setIssuer(ISSUER).setAudience(AUD_SESSION)
    .setIssuedAt().setExpirationTime(`${SESSION_TTL_S}s`).sign(authSecret());
}

export async function verifySession(token?: string): Promise<SessionClaims | null> {
  if (!token) return null;
  try {
    const { payload } = await jwtVerify(token, authSecret(), { issuer: ISSUER, audience: AUD_SESSION, algorithms: ["HS256"] });
    if (!payload.sub || typeof payload.role !== "string" || typeof payload.sv !== "number") return null;
    return { sub: payload.sub, role: payload.role as Role, sv: payload.sv };
  } catch { return null; }
}

export function signPending(c: PendingClaims): Promise<string> {
  return new SignJWT({ sv: c.sv, purpose: c.purpose, enc: c.enc })
    .setProtectedHeader({ alg: "HS256" }).setSubject(c.sub).setIssuer(ISSUER).setAudience(AUD_PENDING)
    .setIssuedAt().setExpirationTime(`${PENDING_TTL_S}s`).sign(authSecret());
}

export async function verifyPending(token?: string): Promise<PendingClaims | null> {
  if (!token) return null;
  try {
    const { payload } = await jwtVerify(token, authSecret(), { issuer: ISSUER, audience: AUD_PENDING, algorithms: ["HS256"] });
    if (!payload.sub || typeof payload.sv !== "number" || (payload.purpose !== "verify" && payload.purpose !== "enroll")) return null;
    return { sub: payload.sub, sv: payload.sv, purpose: payload.purpose, enc: typeof payload.enc === "string" ? payload.enc : undefined };
  } catch { return null; }
}
