// Sample data so the UI runs with no database. Fully editable in memory; schedules come from the real engine logic.
import { randomUUID } from "node:crypto";
import type { Repo } from "./repo";
import type {
  AdminPostRow, PostInput, PublishStatusT as PubStatus, BlogFormatT,
  AdminFaqRow, FaqStatusT,
  AdminScheduleRow,
  AdminCategoryRow, AdminCourseRow, CategoryDTO, CategoryEditDTO, CourseCard, CourseDetail, CourseEditDTO, CourseInput, DeliveryModeT, LeadRow,
  Length, PriceMap, PublishStatusT, RegistrationSummary, ScheduleDTO, StudentRow, UnscheduledRow,
} from "./types";
import { toCard as postCard, toDetail as postDetail } from "./blog/mapping";
import { courseContentHash } from "./faq/hash";
import { nairobiToday, planTopUp, toISODate, addDays, buildSchedule, assertWeekdayOnly } from "./schedules/dates";

interface MCat { id: string; name: string; slug: string; description?: string; iconKey?: string; imageUrl?: string; metaTitle?: string; metaDescription?: string; metaKeywords?: string; sortOrder: number; status: PublishStatusT }
interface MCourse extends Omit<CourseEditDTO, "outline"> { outline: { title: string; body?: string }[]; contentHash?: string; faqSourceHash?: string | null }
interface MFaq { id: string; courseId: string; question: string; answer: string; status: FaqStatusT; aiGenerated: boolean; model?: string; createdAt: string; sortOrder: number }
interface MPost { id: string; slug: string; title: string; excerpt?: string; body: string; format: BlogFormatT; coverUrl?: string; tags: string[]; metaTitle?: string; metaDescription?: string; metaKeywords?: string; status: PubStatus; publishedAt?: string; author: string; updatedAt: string }
interface MRun { courseId: string; status: string; at: number }
interface MemLead extends LeadRow {}
interface MemStudent { id: string; name: string; email: string; phone: string; organisation?: string; createdAt: string }
interface MemReg extends RegistrationSummary { studentId: string; createdAt: string }
interface State { posts: MPost[]; faqs: MFaq[]; runs: MRun[]; extra: (ScheduleDTO & { courseId: string })[]; cancelled: Set<string>; cats: MCat[]; courses: MCourse[]; leads: MemLead[]; students: Map<string, MemStudent>; regs: MemReg[] }

const today = nairobiToday();
const g = globalThis as unknown as { __mock?: State };

const catSeeds: [string, string, string, string, string][] = [
  ["c1", "Project Management", "project-management", "briefcase", "Plan, deliver and govern projects with globally recognised methods."],
  ["c2", "Monitoring & Evaluation", "monitoring-evaluation", "chart", "Measure results, learn and report with confidence."],
  ["c3", "Finance & Accounting", "finance-accounting", "landmark", "Budgeting, reporting and financial control for every organisation."],
  ["c4", "Data & Analytics", "data-analytics", "cpu", "Turn raw data into decisions with Excel, Power BI and AI tools."],
  ["c5", "Leadership & HR", "leadership-hr", "users", "Lead teams, manage talent and build resilient organisations."],
  ["c6", "Procurement & Supply Chain", "procurement-supply-chain", "truck", "Source smarter and keep supply chains moving."],
];

type Seed = [name: string, slug: string, cat: string, lengths: Length[], kes5: number, summary: string];
const seeds: Seed[] = [
  ["Project Management Professional (PMP) Prep", "pmp-prep", "c1", ["FIVE_DAY", "TEN_DAY"], 85000, "Prepare for the PMP exam with applied practice, case studies and a full mock test."],
  ["Project Planning & Management with MS Project", "ms-project-planning", "c1", ["FIVE_DAY"], 65000, "Build schedules, resource plans and baselines in Microsoft Project."],
  ["Monitoring, Evaluation & Learning (MEL)", "monitoring-evaluation-learning", "c2", ["FIVE_DAY", "TEN_DAY"], 75000, "Design results frameworks, indicators and learning systems for programmes."],
  ["Data Collection with KoboToolbox & ODK", "kobotoolbox-odk-data-collection", "c2", ["FIVE_DAY"], 60000, "Design mobile surveys, collect data offline and clean it for analysis."],
  ["Financial Management for Non-Finance Managers", "financial-management-non-finance", "c3", ["FIVE_DAY"], 70000, "Read financial statements and manage budgets with confidence."],
  ["IFRS & Financial Reporting", "ifrs-financial-reporting", "c3", ["FIVE_DAY", "TEN_DAY"], 80000, "Apply IFRS standards to real-world reporting scenarios."],
  ["Data Analysis with Excel & Power BI", "data-analysis-excel-power-bi", "c4", ["FIVE_DAY"], 65000, "Clean, model and visualise data with Excel and Power BI dashboards."],
  ["Artificial Intelligence for Business Productivity", "ai-for-business-productivity", "c4", ["FIVE_DAY"], 70000, "Use AI assistants and automation to save hours every week."],
  ["Strategic Leadership & Management", "strategic-leadership-management", "c5", ["FIVE_DAY", "TEN_DAY"], 78000, "Set direction, align teams and lead through change."],
  ["Human Resource Management & Talent Strategy", "hr-management-talent-strategy", "c5", ["FIVE_DAY"], 68000, "Recruit, develop and retain people with modern HR practice."],
  ["Procurement & Contract Management", "procurement-contract-management", "c6", ["FIVE_DAY"], 72000, "Run compliant tenders and manage supplier contracts end to end."],
  ["Logistics & Supply Chain Management", "logistics-supply-chain-management", "c6", ["FIVE_DAY", "TEN_DAY"], 74000, "Optimise inventory, transport and warehousing for resilience."],
  // deliberately unscheduled, to exercise the admin "Unscheduled Courses" screen
  ["Grant Writing & Proposal Development", "grant-writing-proposal-development", "c5", [], 62000, "Craft winning proposals for donors and funders."],
  ["Occupational Health & Safety Management", "occupational-health-safety", "c6", [], 64000, "Build a safety culture and meet statutory requirements."],
];

const priceFor = (kes5: number, length: Length): PriceMap => {
  const k = length === "FIVE_DAY" ? kes5 : Math.round(kes5 * 1.8);
  return { KES: k, USD: Math.round(k / 130 / 10) * 10 };
};

function init(): State {
  const cats: MCat[] = catSeeds.map(([id, name, slug, iconKey, description], i) => ({ id, name, slug, iconKey, description, sortOrder: i, status: "PUBLISHED" }));
  const courses: MCourse[] = seeds.map(([name, slug, categoryId, lengths, kes5, summary]) => ({
    id: slug, name, slug, categoryId, summary,
    description: `${name} is a practical, instructor-led programme built for working professionals across Africa. Sessions combine short expert input with hands-on exercises, regional case studies and templates you can take back to your workplace on Monday morning.`,
    objectives: "Apply core concepts to real workplace problems\nBuild practical tools and templates\nLearn from regional case studies\nLeave with an action plan for your organisation",
    targetAudience: "Managers, officers and team leads who want practical, job-ready skills — no prior specialist background required.",
    methodology: "Interactive lectures, group work, case studies, practical exercises and individual coaching from experienced trainers.",
    lengths, deliveryModes: ["CLASSROOM", "ONLINE"], autoSchedule: true, status: "PUBLISHED",
    outline: [
      { title: "Module 1 — Foundations", body: "Key concepts, terminology and the context for your sector." },
      { title: "Module 2 — Core methods", body: "Step-by-step techniques with worked examples." },
      { title: "Module 3 — Tools & practice", body: "Hands-on exercises using real-world templates." },
      { title: "Module 4 — Applying it at work", body: "Action planning, common pitfalls and next steps." },
    ],
    prices: Object.fromEntries(lengths.map((l) => [l, priceFor(kes5, l)])),
  }));
  const faqs: MFaq[] = courses.flatMap((c) => [
    [`Who should attend ${c.name}?`, "Professionals who want practical skills they can apply immediately. No specialist background is required."],
    ["Will I receive a certificate?", "Yes. Every participant who completes the programme receives a Skills for Africa certificate of completion."],
    ["Can this course be delivered at my organisation?", "Yes. We run tailor-made in-house sessions for teams. Contact us for a quote."],
    ["What does the fee include?", "Tuition, course materials, certificate, and refreshments for classroom attendance."],
  ].map(([question, answer], i) => ({ id: `${c.id}:faq:${i}`, courseId: c.id, question, answer, status: "PUBLISHED" as const, aiGenerated: false, createdAt: new Date().toISOString(), sortOrder: i })));
  for (const c of courses) { c.contentHash = courseContentHash(c); c.faqSourceHash = c.contentHash; } // seeded courses already have FAQs

  const topics: [string, string[], string][] = [
    ["How to Choose the Right Project Management Course", ["project-management", "career"], "Choosing between PMP prep, agile and practical planning courses starts with your role and your next career step."],
    ["Monitoring and Evaluation: 7 Mistakes Programme Teams Make", ["monitoring-evaluation", "programmes"], "Weak indicators, late baselines and unused data quietly undermine good programmes. Here is how to avoid them."],
    ["Excel or Power BI? A Practical Guide for Busy Managers", ["data", "excel"], "Both tools are valuable. The right choice depends on how often your data changes and who needs to read it."],
    ["Financial Statements Without the Jargon", ["finance", "management"], "A plain-language tour of the balance sheet, income statement and cash flow statement for non-finance managers."],
    ["Five Habits of Effective Leaders in Growing Organisations", ["leadership", "management"], "Clear priorities, honest feedback and consistent follow-through separate good leaders from busy ones."],
    ["Procurement Basics: Running a Compliant Tender", ["procurement", "compliance"], "From specification to award, each step of a tender needs a record that can withstand an audit."],
    ["Using AI Assistants at Work: A Safe Starter Guide", ["ai", "productivity"], "Start with low-risk tasks, protect confidential data and always review what the assistant produces."],
    ["Building a Training Plan That People Actually Finish", ["learning", "management"], "Short cycles, real work projects and manager support turn training from an event into a habit."],
    ["Writing a Results Framework in One Afternoon", ["monitoring-evaluation", "planning"], "A results framework links activities to outcomes. This simple template keeps it to a single page."],
    ["Supply Chain Resilience: Lessons for African Organisations", ["logistics", "procurement"], "Diversified suppliers, honest lead times and clear stock policies reduce the shock of disruption."],
    ["A Beginner's Guide to Grant Proposals", ["fundraising", "writing"], "Funders read hundreds of proposals. Clarity about the problem, the plan and the evidence helps yours stand out."],
  ];
  const posts: MPost[] = topics.map(([title, tags, excerpt], i) => ({
    id: `post-${i + 1}`, slug: title.toLowerCase().replace(/&/g, "and").replace(/[^a-z0-9]+/g, "-").replace(/^-|-$/g, ""), title, excerpt, tags, format: "MARKDOWN" as const, author: "",
    body: `${excerpt}\n\n## Why it matters\n\nPeople who build this skill make better decisions, communicate more clearly and deliver results faster. The ideas below are practical, and you can apply them on Monday morning.\n\n## What to do first\n\n1. Write down the outcome you want.\n2. Choose one small step you can finish this week.\n3. Ask a colleague to review your approach.\n\n### Common pitfalls\n\n- Trying to change everything at once.\n- Skipping the review step.\n- Measuring activity instead of results.\n\n## Next steps\n\nBrowse our [course catalogue](/courses) to find a programme that builds this skill with expert guidance.`,
    status: "PUBLISHED" as const, publishedAt: new Date(Date.now() - (i + 1) * 5 * 86_400_000).toISOString(), updatedAt: new Date(Date.now() - (i + 1) * 5 * 86_400_000).toISOString(),
  }));
  return { posts, faqs, runs: [], extra: [], cancelled: new Set(), cats, courses, leads: [], students: new Map(), regs: [] };
}
const S = (g.__mock ??= init());

const catOf = (id: string) => S.cats.find((c) => c.id === id)!;
const scheduleFor = (c: MCourse, length: Length): ScheduleDTO[] =>
  planTopUp(length, [], today).map((p, i) => ({ id: `${c.id}:${length}:${i}`, length, startDate: toISODate(p.startDate), endDate: toISODate(p.endDate) }));
const allSchedulesOf = (c: MCourse) => [
  ...(c.autoSchedule ? c.lengths.flatMap((l) => scheduleFor(c, l)) : []),
  ...S.extra.filter((x) => x.courseId === c.id),
].sort((a, b) => a.startDate.localeCompare(b.startDate));
const schedulesOf = (c: MCourse) => allSchedulesOf(c).filter((x) => !S.cancelled.has(x.id) && c.lengths.includes(x.length));

function minPrice(c: MCourse): PriceMap {
  const out: PriceMap = {};
  for (const l of c.lengths) for (const cur of ["KES", "USD"] as const) { const v = c.prices[l]?.[cur]; if (v != null) out[cur] = Math.min(out[cur] ?? Infinity, v); }
  return out;
}
const card = (c: MCourse): CourseCard => ({
  id: c.id, name: c.name, slug: c.slug, summary: c.summary ?? c.description.slice(0, 160), categoryName: catOf(c.categoryId).name, categorySlug: catOf(c.categoryId).slug,
  iconKey: catOf(c.categoryId).iconKey, imageUrl: c.imageUrl, lengths: c.lengths, priceFrom: minPrice(c),
});
const detail = (c: MCourse): CourseDetail => ({
  ...card(c), description: c.description, objectives: c.objectives, targetAudience: c.targetAudience, methodology: c.methodology, outline: c.outline,
  prices: c.prices, schedules: schedulesOf(c), metaTitle: c.metaTitle, metaDescription: c.metaDescription,
  faqs: S.faqs.filter((f) => f.courseId === c.id && f.status === "PUBLISHED").sort((x, y) => x.sortOrder - y.sortOrder).map((f) => ({ question: f.question, answer: f.answer })),
});
const live = () => S.courses.filter((c) => c.status === "PUBLISHED" && catOf(c.categoryId).status === "PUBLISHED");
const toCategory = (c: MCat): CategoryDTO => ({ id: c.id, name: c.name, slug: c.slug, description: c.description, iconKey: c.iconKey, imageUrl: c.imageUrl, courseCount: live().filter((x) => x.categoryId === c.id).length });
const pubCats = () => S.cats.filter((c) => c.status === "PUBLISHED").sort((a, b) => a.sortOrder - b.sortOrder);
const centerNames = ["Nairobi, Kenya", "Mombasa, Kenya", "Dubai, UAE", "Kigali, Rwanda", "Johannesburg, South Africa", "Dar es Salaam, Tanzania", "Singapore", "Pretoria, South Africa", "Mauritius"];

const livePosts = () => S.posts.filter((p) => p.status === "PUBLISHED" && p.publishedAt && new Date(p.publishedAt) <= new Date()).sort((a, b) => b.publishedAt!.localeCompare(a.publishedAt!));
const toPostRow = (p: MPost) => ({ ...p, publishedAt: p.publishedAt ?? p.updatedAt, coverUrl: p.coverUrl ?? null });

export const mockRepo: Repo = {
  async listCategories() { return pubCats().map(toCategory); },
  async getCategory(slug) { const c = pubCats().find((x) => x.slug === slug); return c ? toCategory(c) : null; },
  async listCourses(f = {}) {
    const q = f.q?.toLowerCase().trim();
    return live().map(card).filter((c) => (!f.categorySlug || c.categorySlug === f.categorySlug) && (!q || c.name.toLowerCase().includes(q) || c.summary.toLowerCase().includes(q)));
  },
  async getCourse(slug) { const c = live().find((x) => x.slug === slug); return c ? detail(c) : null; },
  async getHomeData() {
    const upcoming = live().filter((c) => c.lengths.length && c.autoSchedule).slice(0, 8).map((c) => {
      const l = c.lengths[0]; const first = scheduleFor(c, l)[0];
      return { scheduleId: first.id, courseName: c.name, courseSlug: c.slug, length: l, startDate: first.startDate, endDate: first.endDate, price: c.prices[l] ?? {} };
    });
    return { categories: pubCats().map(toCategory), featured: live().filter((c) => c.lengths.length).slice(0, 6).map(card), upcoming, totals: { courses: live().length, categories: pubCats().length, centers: 9 } };
  },
  async listCenters() { return centerNames.map((name, i) => ({ id: String(i + 1), name })); },

  async createLead(input) {
    const c = S.courses.find((x) => x.slug === input.courseSlug && x.status === "PUBLISHED");
    if (!c) return { ok: false, error: "Course not found" };
    const id = randomUUID();
    S.leads.unshift({ id, name: input.fullName, email: input.email, phone: input.phone, company: input.company, country: input.country, course: c.name, courseSlug: c.slug, createdAt: new Date().toISOString(), downloadCount: 0, lastDownloadedAt: null });
    return { ok: true, leadId: id, courseName: c.name };
  },
  async createRegistration(input) {
    const c = S.courses.find((x) => x.slug === input.courseSlug && x.status === "PUBLISHED");
    const sched = c && schedulesOf(c).find((x) => x.id === input.scheduleId);
    if (!c || !sched) return { ok: false, error: "That start date is no longer available. Please pick another." };
    if (S.regs.some((r) => r.email === input.email && r.startDate === sched.startDate && r.courseSlug === c.slug)) return { ok: false, error: "You are already registered for this date." };
    const stu = S.students.get(input.email) ?? { id: randomUUID(), name: `${input.firstName} ${input.lastName}`, email: input.email, phone: input.phone, organisation: input.organisation, createdAt: new Date().toISOString() };
    S.students.set(input.email, stu);
    const summary: RegistrationSummary = { registrationId: randomUUID(), email: input.email, name: stu.name, phone: input.phone, courseSlug: c.slug, courseName: c.name, startDate: sched.startDate, endDate: sched.endDate, length: sched.length, deliveryMode: input.deliveryMode, centerName: input.deliveryMode === "CLASSROOM" ? centerNames[Number(input.centerId) - 1] : undefined, participants: input.participants };
    S.regs.unshift({ ...summary, studentId: stu.id, createdAt: new Date().toISOString() });
    return { ok: true, summary };
  },
  async recordBrochureDownload(leadId) { const l = S.leads.find((x) => x.id === leadId); if (l) { l.downloadCount++; l.lastDownloadedAt = new Date().toISOString(); } },
  async listLeads({ q, limit }) { const n = q?.toLowerCase(); return S.leads.filter((l) => !n || l.email.includes(n) || l.name.toLowerCase().includes(n)).slice(0, limit); },
  async listStudents({ q, limit }): Promise<StudentRow[]> {
    const n = q?.toLowerCase();
    return [...S.students.values()].filter((x) => !n || x.email.includes(n) || x.name.toLowerCase().includes(n)).slice(0, limit).map((x) => ({
      ...x, registrations: S.regs.filter((r) => r.studentId === x.id).map((r) => ({ id: r.registrationId, course: r.courseName, courseSlug: r.courseSlug, startDate: r.startDate, endDate: r.endDate, length: r.length, status: "PENDING", mode: r.deliveryMode, center: r.centerName, registeredAt: r.createdAt })),
    }));
  },

  async getDashboardStats() {
    return {
      students: 1284 + S.students.size, registrations: 1731 + S.regs.length, registrationsLast30: 96 + S.regs.length, publishedCourses: live().length,
      categories: pubCats().length, brochureDownloads: 5420 + S.leads.length, brochureDownloadsLast30: 312 + S.leads.length,
      recentRegistrations: [
        ...S.regs.slice(0, 3).map((r) => ({ id: r.registrationId, student: r.name, course: r.courseName, startDate: r.startDate, createdAt: r.createdAt })),
        { id: "r1", student: "Amina Wanjiru", course: seeds[0][0], startDate: toISODate(addDays(today, 3)), createdAt: new Date().toISOString() },
        { id: "r2", student: "Joseph Okello", course: seeds[2][0], startDate: toISODate(addDays(today, 10)), createdAt: new Date().toISOString() },
      ].slice(0, 5),
      recentLeads: [
        ...S.leads.slice(0, 3).map((l) => ({ id: l.id, name: l.name, email: l.email, course: l.course, createdAt: l.createdAt })),
        { id: "l1", name: "Peter Kamau", email: "peter@example.com", course: seeds[4][0], createdAt: new Date().toISOString() },
      ].slice(0, 5),
    };
  },

  async adminListCourses(): Promise<AdminCourseRow[]> {
    return S.courses.map((c) => ({ id: c.id, name: c.name, slug: c.slug, category: catOf(c.categoryId).name, lengths: c.lengths, status: c.status, upcoming: schedulesOf(c).length }));
  },
  async listUnscheduled(): Promise<UnscheduledRow[]> {
    return S.courses.filter((c) => c.status !== "ARCHIVED" && (!c.lengths.length || !c.autoSchedule)).map((c) => ({
      id: c.id, name: c.name, slug: c.slug, category: catOf(c.categoryId).name, counts: { FIVE_DAY: 0, TEN_DAY: 0 },
      reason: !c.lengths.length ? "No course length selected" : "Auto-scheduling is off",
    }));
  },

  async listSchedulesAdmin({ courseId, from, limit }): Promise<AdminScheduleRow[]> {
    return S.courses.filter((c) => !courseId || c.id === courseId).flatMap((c) => allSchedulesOf(c).filter((x) => !from || x.startDate >= from).map((x) => ({
      id: x.id, courseId: c.id, course: c.name, courseSlug: c.slug, length: x.length, startDate: x.startDate, endDate: x.endDate,
      status: S.cancelled.has(x.id) ? "CANCELLED" as const : "OPEN" as const, generated: !S.extra.some((e) => e.id === x.id), legacy: false,
      registrations: S.regs.filter((r) => r.courseSlug === c.slug && r.startDate === x.startDate && r.length === x.length).length,
    }))).sort((a, b) => a.startDate.localeCompare(b.startDate) || a.course.localeCompare(b.course)).slice(0, limit);
  },
  async addSchedule({ courseId, length, startDate }) {
    const c = S.courses.find((x) => x.id === courseId);
    if (!c) return { ok: false, error: "Course not found" };
    if (!c.lengths.includes(length)) return { ok: false, error: "This course is not offered in that length. Change it on the course page first." };
    const plan = buildSchedule(length, new Date(`${startDate}T00:00:00Z`));
    try { assertWeekdayOnly(plan); } catch (e) { return { ok: false, error: e instanceof Error ? e.message : "Invalid dates" }; }
    if (plan.startDate.getTime() <= today.getTime()) return { ok: false, error: "The start date must be in the future." };
    if (allSchedulesOf(c).some((x) => x.length === length && x.startDate === startDate)) return { ok: false, error: "A schedule already exists for that course, length and start date." };
    S.extra.push({ id: `${c.id}:${length}:manual:${startDate}`, courseId: c.id, length, startDate, endDate: toISODate(plan.endDate) });
    return { ok: true, courseSlug: c.slug };
  },
  async setScheduleStatus(id, status) {
    const c = S.courses.find((x) => allSchedulesOf(x).some((s) => s.id === id));
    if (!c) return { ok: false, error: "Schedule not found" };
    if (status === "CANCELLED") S.cancelled.add(id); else S.cancelled.delete(id);
    return { ok: true, courseSlug: c.slug };
  },

  async getFaqContext(courseId) {
    const c = S.courses.find((x) => x.id === courseId);
    if (!c) return null;
    return { course: structuredClone(c), categoryName: catOf(c.categoryId).name, faqSourceHash: c.faqSourceHash ?? null,
      existingQuestions: S.faqs.filter((f) => f.courseId === courseId && f.status !== "DRAFT").map((f) => f.question) };
  },
  async listFaqCandidates() {
    return S.courses.filter((c) => c.status === "PUBLISHED").map((c) => ({ id: c.id, slug: c.slug, name: c.name, contentHash: c.contentHash ?? null, faqSourceHash: c.faqSourceHash ?? null,
      recentFailures: S.runs.filter((r) => r.courseId === c.id && r.status === "FAILED" && Date.now() - r.at < 86_400_000).length }));
  },
  async saveGeneratedFaqs({ courseId, hash, faqs, model, publish }) {
    const c = S.courses.find((x) => x.id === courseId); if (!c) return 0;
    S.faqs = S.faqs.filter((f) => !(f.courseId === courseId && f.aiGenerated && f.status === "DRAFT"));
    const start = Math.max(-1, ...S.faqs.filter((f) => f.courseId === courseId).map((f) => f.sortOrder)) + 1;
    faqs.forEach((f, i) => S.faqs.push({ id: randomUUID(), courseId, question: f.question, answer: f.answer, status: publish ? "PUBLISHED" : "DRAFT", aiGenerated: true, model, createdAt: new Date().toISOString(), sortOrder: start + i }));
    c.faqSourceHash = hash; c.contentHash ??= hash;
    return faqs.length;
  },
  async logFaqRun(r) { S.runs.push({ courseId: r.courseId, status: r.status, at: Date.now() }); },
  async listFaqsAdmin({ status, courseId, limit }): Promise<AdminFaqRow[]> {
    return S.faqs.filter((f) => (!status || f.status === status) && (!courseId || f.courseId === courseId)).map((f) => {
      const c = S.courses.find((x) => x.id === f.courseId)!;
      return { id: f.id, courseId: f.courseId, course: c.name, courseSlug: c.slug, question: f.question, answer: f.answer, status: f.status, aiGenerated: f.aiGenerated, model: f.model, createdAt: f.createdAt };
    }).sort((a, b) => a.course.localeCompare(b.course)).slice(0, limit);
  },
  async faqCounts() {
    const n = (s: FaqStatusT) => S.faqs.filter((f) => f.status === s).length;
    return { published: n("PUBLISHED"), draft: n("DRAFT"), rejected: n("REJECTED"), coursesWithPublished: new Set(S.faqs.filter((f) => f.status === "PUBLISHED").map((f) => f.courseId)).size };
  },
  async updateFaq(id, patch) {
    const f = S.faqs.find((x) => x.id === id); if (!f) return { ok: false, error: "FAQ not found" };
    Object.assign(f, Object.fromEntries(Object.entries(patch).filter(([, v]) => v !== undefined)));
    return { ok: true, courseSlug: S.courses.find((c) => c.id === f.courseId)!.slug };
  },
  async addFaq(courseId, question, answer) {
    const c = S.courses.find((x) => x.id === courseId); if (!c) return { ok: false, error: "Course not found" };
    const start = Math.max(-1, ...S.faqs.filter((f) => f.courseId === courseId).map((f) => f.sortOrder)) + 1;
    S.faqs.push({ id: randomUUID(), courseId, question, answer, status: "PUBLISHED", aiGenerated: false, createdAt: new Date().toISOString(), sortOrder: start });
    return { ok: true, courseSlug: c.slug };
  },
  async setCourseFaqsStatus(courseId, from, to) {
    const c = S.courses.find((x) => x.id === courseId); if (!c) return { ok: false, error: "Course not found" };
    const hit = S.faqs.filter((f) => f.courseId === courseId && f.status === from); hit.forEach((f) => { f.status = to; });
    return { ok: true, courseSlug: c.slug, count: hit.length };
  },


  async listPosts({ page, pageSize, tag }) {
    const vis = livePosts().filter((p) => !tag || p.tags.includes(tag));
    return { posts: vis.slice((page - 1) * pageSize, page * pageSize).map(toPostRow).map(postCard), total: vis.length };
  },
  async getPost(slug) {
    const p = livePosts().find((x) => x.slug === slug); if (!p) return null;
    const others = livePosts().filter((x) => x.slug !== slug);
    const rel = [...others.filter((x) => x.tags.some((t) => p.tags.includes(t))), ...others].filter((x, i, a) => a.indexOf(x) === i).slice(0, 3);
    return postDetail(toPostRow(p), rel.map(toPostRow));
  },
  async listPostTags() {
    const m = new Map<string, number>(); for (const p of livePosts()) for (const t of p.tags) m.set(t, (m.get(t) ?? 0) + 1);
    return [...m].map(([tag, count]) => ({ tag, count })).sort((a, b) => b.count - a.count || a.tag.localeCompare(b.tag));
  },
  async listPostSlugs() { return livePosts().map((p) => ({ slug: p.slug, updatedAt: p.updatedAt })); },
  async adminListPosts({ status, q, limit }): Promise<AdminPostRow[]> {
    const n = q?.toLowerCase();
    return [...S.posts].filter((p) => (!status || p.status === status) && (!n || p.title.toLowerCase().includes(n))).sort((a, b) => b.updatedAt.localeCompare(a.updatedAt)).slice(0, limit)
      .map((p) => ({ id: p.id, title: p.title, slug: p.slug, status: p.status, publishedAt: p.publishedAt ?? null, tags: p.tags, author: p.author, updatedAt: p.updatedAt, scheduled: p.status === "PUBLISHED" && !!p.publishedAt && new Date(p.publishedAt) > new Date() }));
  },
  async getPostForEdit(id) { const p = S.posts.find((x) => x.id === id); return p ? { ...p, id: p.id } : null; },
  async getPostPreview(id) { const p = S.posts.find((x) => x.id === id); return p ? postDetail(toPostRow(p), []) : null; },
  async savePost(i: PostInput, author) {
    if (S.posts.some((p) => p.slug === i.slug && p.id !== i.id)) return { ok: false, error: "A post with this URL already exists", fieldErrors: { slug: ["Already used by another post"] } };
    const ex = i.id ? S.posts.find((p) => p.id === i.id) : undefined;
    if (i.id && !ex) return { ok: false, error: "Post not found" };
    const { id: _id, slug: _slug, ...rest } = i; void _id; void _slug;
    if (ex) { Object.assign(ex, { ...rest, publishedAt: i.publishedAt ?? ex.publishedAt, updatedAt: new Date().toISOString() }); return { ok: true, id: ex.id, slug: ex.slug }; }
    const n: MPost = { id: randomUUID(), slug: i.slug, ...rest, author: author.name, updatedAt: new Date().toISOString() };
    S.posts.push(n); return { ok: true, id: n.id, slug: n.slug };
  },

  async findRedirect(path) { return path === "/course/pmp-prep" ? "/courses/pmp-prep" : null; }, // demo mapping so the redirect route can be tried in preview

  async generateSchedules(courseId) {
    const c = S.courses.find((x) => x.id === courseId);
    if (!c || !c.lengths.length) return 0;
    c.autoSchedule = true;
    return c.lengths.reduce((n, l) => n + (l === "FIVE_DAY" ? 52 : 26), 0);
  },

  async getCourseForEdit(id) { const c = S.courses.find((x) => x.id === id); return c ? structuredClone(c) : null; },
  async saveCourse(i) {
    if (!S.cats.some((c) => c.id === i.categoryId)) return { ok: false, error: "Category not found", fieldErrors: { categoryId: ["Choose a category"] } };
    if (S.courses.some((c) => c.slug === i.slug && c.id !== i.id)) return { ok: false, error: "A course with this URL already exists", fieldErrors: { slug: ["Already used by another course"] } };
    const { id: _id, ...rest } = i; void _id;
    const prices: CourseInput["prices"] = {}; for (const l of ["FIVE_DAY", "TEN_DAY"] as Length[]) if (i.prices[l]) prices[l] = { ...i.prices[l] };
    const existing = i.id ? S.courses.find((c) => c.id === i.id) : undefined;
    if (i.id && !existing) return { ok: false, error: "Course not found" };
    const contentHash = courseContentHash(i);
    if (existing) Object.assign(existing, { ...rest, slug: existing.slug, prices, contentHash });
    else S.courses.push({ id: randomUUID(), ...rest, prices, deliveryModes: i.deliveryModes as DeliveryModeT[], contentHash, faqSourceHash: null });
    const saved = existing ?? S.courses[S.courses.length - 1];
    return { ok: true, id: saved.id, slug: saved.slug };
  },
  async listCategoryOptions() { return S.cats.filter((c) => c.status !== "ARCHIVED").map((c) => ({ id: c.id, name: c.name })); },
  async adminListCategories(): Promise<AdminCategoryRow[]> {
    return [...S.cats].sort((a, b) => a.sortOrder - b.sortOrder).map((c) => ({ id: c.id, name: c.name, slug: c.slug, iconKey: c.iconKey, status: c.status, courses: S.courses.filter((x) => x.categoryId === c.id).length, sortOrder: c.sortOrder }));
  },
  async getCategoryForEdit(id): Promise<CategoryEditDTO | null> { const c = S.cats.find((x) => x.id === id); return c ? { ...c } : null; },
  async saveCategory(i) {
    if (S.cats.some((c) => c.slug === i.slug && c.id !== i.id)) return { ok: false, error: "A category with this URL already exists", fieldErrors: { slug: ["Already used by another category"] } };
    const ex = i.id ? S.cats.find((c) => c.id === i.id) : undefined;
    if (i.id && !ex) return { ok: false, error: "Category not found" };
    if (ex) { const { id: _i, slug: _s, ...rest } = i; void _i; void _s; Object.assign(ex, rest); return { ok: true, id: ex.id, slug: ex.slug }; }
    const n: MCat = { id: randomUUID(), name: i.name, slug: i.slug, description: i.description, iconKey: i.iconKey, imageUrl: i.imageUrl, metaTitle: i.metaTitle, metaDescription: i.metaDescription, metaKeywords: i.metaKeywords, sortOrder: i.sortOrder, status: i.status };
    S.cats.push(n);
    return { ok: true, id: n.id, slug: n.slug };
  },
  async listPriceRows() {
    return S.courses.filter((c) => c.status !== "ARCHIVED").map((c) => ({ courseId: c.id, name: c.name, category: catOf(c.categoryId).name, lengths: c.lengths, prices: structuredClone(c.prices) }));
  },
  async setCoursePrices(courseId, prices) {
    const c = S.courses.find((x) => x.id === courseId); if (!c) return;
    c.prices = {}; for (const l of ["FIVE_DAY", "TEN_DAY"] as Length[]) if (prices[l]) c.prices[l] = { ...prices[l] };
  },
};
