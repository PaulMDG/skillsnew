import type {
  AdminPostRow, PostCard, PostDetail, PostEditDTO, PostInput, PublishStatusT,
  AdminFaqRow, FaqCandidate, FaqContextDTO, FaqCounts, FaqRunInput, FaqStatusT,
  AdminScheduleRow, ScheduleResult,
  AdminCategoryRow, CategoryEditDTO, CategoryInput, CourseEditDTO, CourseInput, Length, PriceMap, PriceRow, SaveResult,
  AdminCourseRow, LeadResult, LeadRow, RegistrationResult, StudentRow, CategoryDTO, CenterDTO, CourseCard, CourseDetail,
  DashboardStats, HomeData, LeadInput, RegistrationInput, UnscheduledRow,
} from "./types";

/** Everything the UI needs from storage. Two implementations: Prisma (real) and mock (preview without a DB). */
export interface Repo {
  listCategories(): Promise<CategoryDTO[]>;
  getCategory(slug: string): Promise<CategoryDTO | null>;
  listCourses(filter?: { categorySlug?: string; q?: string }): Promise<CourseCard[]>;
  getCourse(slug: string): Promise<CourseDetail | null>;
  getHomeData(): Promise<HomeData>;
  listCenters(): Promise<CenterDTO[]>;
  createLead(input: LeadInput): Promise<LeadResult>;
  createRegistration(input: RegistrationInput): Promise<RegistrationResult>;
  recordBrochureDownload(leadId: string): Promise<void>;
  listLeads(f: { q?: string; limit: number }): Promise<LeadRow[]>;
  listStudents(f: { q?: string; limit: number }): Promise<StudentRow[]>;
  getDashboardStats(): Promise<DashboardStats>;
  adminListCourses(): Promise<AdminCourseRow[]>;
  listUnscheduled(): Promise<UnscheduledRow[]>;
  getCourseForEdit(id: string): Promise<CourseEditDTO | null>;
  saveCourse(input: CourseInput): Promise<SaveResult>;
  listCategoryOptions(): Promise<{ id: string; name: string }[]>;
  adminListCategories(): Promise<AdminCategoryRow[]>;
  getCategoryForEdit(id: string): Promise<CategoryEditDTO | null>;
  saveCategory(input: CategoryInput): Promise<SaveResult>;
  listPriceRows(): Promise<PriceRow[]>;
  setCoursePrices(courseId: string, prices: Partial<Record<Length, PriceMap>>): Promise<void>;
  listSchedulesAdmin(f: { courseId?: string; from?: string; limit: number }): Promise<AdminScheduleRow[]>;
  /** Manual schedule: must be a Monday start; the end date is computed (Friday). */
  addSchedule(i: { courseId: string; length: Length; startDate: string }): Promise<ScheduleResult>;
  setScheduleStatus(id: string, status: "OPEN" | "CANCELLED"): Promise<ScheduleResult>;
  getFaqContext(courseId: string): Promise<FaqContextDTO | null>;
  listFaqCandidates(): Promise<FaqCandidate[]>;
  /** Replaces this course's older AI drafts with the new ones (published FAQs are never touched). Returns how many were stored. */
  saveGeneratedFaqs(i: { courseId: string; hash: string; faqs: { question: string; answer: string }[]; model: string; publish: boolean }): Promise<number>;
  logFaqRun(r: FaqRunInput): Promise<void>;
  listFaqsAdmin(f: { status?: FaqStatusT; courseId?: string; limit: number }): Promise<AdminFaqRow[]>;
  faqCounts(): Promise<FaqCounts>;
  updateFaq(id: string, patch: { question?: string; answer?: string; status?: FaqStatusT }): Promise<ScheduleResult>;
  addFaq(courseId: string, question: string, answer: string): Promise<ScheduleResult>;
  setCourseFaqsStatus(courseId: string, from: FaqStatusT, to: FaqStatusT): Promise<(ScheduleResult & { count?: number })>;
  listPosts(f: { page: number; pageSize: number; tag?: string }): Promise<{ posts: PostCard[]; total: number }>;
  getPost(slug: string): Promise<PostDetail | null>;
  listPostTags(): Promise<{ tag: string; count: number }[]>;
  listPostSlugs(): Promise<{ slug: string; updatedAt: string }[]>;
  adminListPosts(f: { status?: PublishStatusT; q?: string; limit: number }): Promise<AdminPostRow[]>;
  getPostForEdit(id: string): Promise<PostEditDTO | null>;
  /** Staff preview: any status, ignores the publish date. */
  getPostPreview(id: string): Promise<PostDetail | null>;
  savePost(input: PostInput, author: { id: string; name: string }): Promise<SaveResult>;
  /** Old-site URL → new URL (301). Null when there is no mapping. */
  findRedirect(path: string): Promise<string | null>;
  /** Runs the schedule engine for one course; returns number of schedules created. */
  generateSchedules(courseId: string): Promise<number>;
}

let cached: Repo | undefined;

export async function getRepo(): Promise<Repo> {
  if (cached) return cached;
  cached = process.env.DATABASE_URL
    ? (await import("./repo.prisma")).prismaRepo
    : (await import("./repo.mock")).mockRepo;
  return cached;
}
