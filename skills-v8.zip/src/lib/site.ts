export const site = {
  name: "Skills for Africa",
  tagline: "Professional training that moves African organisations forward",
  url: (process.env.NEXT_PUBLIC_SITE_URL ?? "http://localhost:3000").replace(/\/$/, ""),
  email: "info@skillsforafrica.org",
  phone: "+254 700 000 000",
  locale: "en_KE",
};

export const abs = (path: string) => `${site.url}${path.startsWith("/") ? path : `/${path}`}`;
