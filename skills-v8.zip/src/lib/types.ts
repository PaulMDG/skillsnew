export type Length = "FIVE_DAY" | "TEN_DAY";
export type Currency = "KES" | "USD";
export type PriceMap = Partial<Record<Currency, number>>;

export interface CategoryDTO {
  id: string;
  name: string;
  slug: string;
  description?: string | null;
  iconKey?: string | null;
  imageUrl?: string | null;
  courseCount: number;
}

export interface CourseCard {
  id: string;
  name: string;
  slug: string;
  summary: string;
  categoryName: string;
  categorySlug: string;
  iconKey?: string | null;
  imageUrl?: string | null;
  lengths: Length[];
  /** lowest price per currency across the offered lengths */
  priceFrom: PriceMap;
}

export interface ScheduleDTO {
  id: string;
  length: Length;
  startDate: string; // ISO yyyy-mm-dd
  endDate: string;
}

export interface CourseDetail extends CourseCard {
  description: string;
  objectives?: string | null;
  targetAudience?: string | null;
  methodology?: string | null;
  outline: { title: string; body?: string | null }[];
  prices: Partial<Record<Length, PriceMap>>;
  schedules: ScheduleDTO[];
  faqs: { question: string; answer: string }[];
  metaTitle?: string | null;
  metaDescription?: string | null;
}

export interface UpcomingStart {
  scheduleId: string;
  courseName: string;
  courseSlug: string;
  length: Length;
  startDate: string;
  endDate: string;
  price: PriceMap;
}

export interface HomeData {
  categories: CategoryDTO[];
  featured: CourseCard[];
  upcoming: UpcomingStart[];
  totals: { courses: number; categories: number; centers: number };
}

export interface CenterDTO { id: string; name: string }

export interface LeadInput {
  courseSlug: string;
  fullName: string;
  email: string;
  phone?: string;
  country?: string;
  company?: string;
  ipHash?: string;
}

export interface RegistrationInput {
  courseSlug: string;
  scheduleId: string;
  firstName: string;
  lastName: string;
  email: string;
  phone: string;
  organisation?: string;
  deliveryMode: "CLASSROOM" | "ONLINE";
  centerId?: string;
  participants: number;
  needsAccommodation: boolean;
  needsAirportPickup: boolean;
  notes?: string;
}

export type ActionResult = { ok: true } | { ok: false; error: string };
export type LeadResult = { ok: true; leadId: string; courseName: string } | { ok: false; error: string };

export interface RegistrationSummary {
  registrationId: string; email: string; name: string; phone: string; courseSlug: string; courseName: string;
  startDate: string; endDate: string; length: Length; deliveryMode: "CLASSROOM" | "ONLINE"; centerName?: string; participants: number;
}
export type RegistrationResult = { ok: true; summary: RegistrationSummary } | { ok: false; error: string };

export interface LeadRow {
  id: string; name: string; email: string; phone?: string | null; company?: string | null; country?: string | null;
  course: string; courseSlug: string; createdAt: string; downloadCount: number; lastDownloadedAt?: string | null;
}

export interface StudentRow {
  id: string; name: string; email: string; phone?: string | null; organisation?: string | null; createdAt: string;
  registrations: { id: string; course: string; courseSlug: string; startDate: string; endDate: string; length: Length; status: string; mode: string; center?: string | null; registeredAt: string }[];
}

export interface DashboardStats {
  students: number;
  registrations: number;
  registrationsLast30: number;
  publishedCourses: number;
  categories: number;
  brochureDownloads: number;
  brochureDownloadsLast30: number;
  recentRegistrations: { id: string; student: string; course: string; startDate: string; createdAt: string }[];
  recentLeads: { id: string; name: string; email: string; course: string; createdAt: string }[];
}

export interface AdminCourseRow {
  id: string;
  name: string;
  slug: string;
  category: string;
  lengths: Length[];
  status: string;
  upcoming: number;
}

export interface UnscheduledRow {
  id: string;
  name: string;
  slug: string;
  category: string;
  counts: Record<Length, number>;
  reason: string;
}

// ───────────── Admin editing ─────────────
export type PublishStatusT = "DRAFT" | "PUBLISHED" | "ARCHIVED";
export type DeliveryModeT = "CLASSROOM" | "ONLINE";

export interface CourseInput {
  id?: string;
  name: string;
  slug: string;
  categoryId: string;
  summary?: string;
  description: string;
  objectives?: string;
  targetAudience?: string;
  methodology?: string;
  imageUrl?: string;
  lengths: Length[];
  deliveryModes: DeliveryModeT[];
  autoSchedule: boolean;
  status: PublishStatusT;
  metaTitle?: string;
  metaDescription?: string;
  metaKeywords?: string;
  outline: { title: string; body?: string }[];
  prices: Partial<Record<Length, PriceMap>>;
}

export interface CourseEditDTO extends Omit<CourseInput, "id"> { id: string }

export interface CategoryInput {
  id?: string;
  name: string;
  slug: string;
  description?: string;
  iconKey?: string;
  imageUrl?: string;
  metaTitle?: string;
  metaDescription?: string;
  metaKeywords?: string;
  sortOrder: number;
  status: PublishStatusT;
}
export interface CategoryEditDTO extends Omit<CategoryInput, "id"> { id: string }
export interface AdminCategoryRow { id: string; name: string; slug: string; iconKey?: string | null; status: string; courses: number; sortOrder: number }

export interface PriceRow { courseId: string; name: string; category: string; lengths: Length[]; prices: Partial<Record<Length, PriceMap>> }

export type SaveResult = { ok: true; id: string; slug: string } | { ok: false; error: string; fieldErrors?: Record<string, string[] | undefined> };

export interface AdminScheduleRow {
  id: string; courseId: string; course: string; courseSlug: string; length: Length; startDate: string; endDate: string;
  status: "OPEN" | "CANCELLED"; generated: boolean; legacy: boolean; registrations: number;
}
export type ScheduleResult = { ok: true; courseSlug: string } | { ok: false; error: string };

// ───────────── FAQs ─────────────
export type FaqStatusT = "DRAFT" | "PUBLISHED" | "REJECTED";
export interface AdminFaqRow { id: string; courseId: string; course: string; courseSlug: string; question: string; answer: string; status: FaqStatusT; aiGenerated: boolean; model?: string | null; createdAt: string }
export interface FaqCandidate { id: string; slug: string; name: string; contentHash: string | null; faqSourceHash: string | null; recentFailures: number }
export interface FaqRunInput { courseId: string; status: "SUCCESS" | "FAILED" | "SKIPPED"; model?: string; promptTokens?: number; completionTokens?: number; durationMs?: number; error?: string }
export interface FaqContextDTO { course: CourseEditDTO; categoryName: string; existingQuestions: string[]; faqSourceHash: string | null }
export interface FaqCounts { published: number; draft: number; rejected: number; coursesWithPublished: number }

// ───────────── Blog ─────────────
export type BlogFormatT = "MARKDOWN" | "HTML";
export interface PostCard { slug: string; title: string; excerpt: string; coverUrl?: string | null; publishedAt: string; tags: string[]; readingMinutes: number; author: string }
export interface PostDetail extends PostCard { body: string; format: BlogFormatT; updatedAt: string; metaTitle?: string | null; metaDescription?: string | null; related: PostCard[] }
export interface PostInput {
  id?: string; title: string; slug: string; excerpt?: string; body: string; format: BlogFormatT; coverUrl?: string; tags: string[];
  metaTitle?: string; metaDescription?: string; metaKeywords?: string; status: PublishStatusT; publishedAt?: string; // ISO instant
}
export interface PostEditDTO extends Omit<PostInput, "id"> { id: string; author: string }
export interface AdminPostRow { id: string; title: string; slug: string; status: PublishStatusT; publishedAt: string | null; tags: string[]; author: string; updatedAt: string; scheduled: boolean }
