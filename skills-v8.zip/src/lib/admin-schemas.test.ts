import { test } from "node:test";
import assert from "node:assert/strict";
import { slugify, parseOutline, outlineToText, courseFormSchema, toCourseInput } from "./admin-schemas";

test("slugify", () => {
  assert.equal(slugify("Project Management & M&E (Advanced)"), "project-management-and-m-and-e-advanced");
  assert.equal(slugify("  Café Résumé  "), "cafe-resume");
  assert.equal(slugify("***"), "");
});

test("outline round trip", () => {
  const t = "Module 1 – Basics\nKey ideas\nMore detail\n\n\nModule 2\n\nModule 3 – Tools\nHands-on";
  const o = parseOutline(t);
  assert.deepEqual(o.map((m) => m.title), ["Module 1 – Basics", "Module 2", "Module 3 – Tools"]);
  assert.equal(o[0].body, "Key ideas\nMore detail");
  assert.equal(o[1].body, undefined);
  assert.deepEqual(parseOutline(outlineToText(o)), o);
});

const base = { name: "Data Analysis", categoryId: "c1", description: "A practical course on analysing data.", status: "PUBLISHED", lengths: ["FIVE_DAY"], deliveryModes: ["ONLINE"], outline: "", price5Kes: "65,000", price5Usd: "500", price10Kes: "", price10Usd: "" };

test("course form: slug generated, prices parsed, empty prices dropped", () => {
  const p = courseFormSchema.parse(base); const r = toCourseInput(p);
  assert.ok(r.ok); if (!r.ok) return;
  assert.equal(r.value.slug, "data-analysis");
  assert.deepEqual(r.value.prices, { FIVE_DAY: { KES: 65000, USD: 500 } });
  assert.equal(r.value.autoSchedule, false);
});

test("course form: single checkbox value arrives as a string and is accepted", () => {
  const p = courseFormSchema.parse({ ...base, lengths: "TEN_DAY", deliveryModes: "CLASSROOM" });
  assert.deepEqual(p.lengths, ["TEN_DAY"]);
});

test("course form rejects: short name, bad status, negative price, http image, non-https", () => {
  assert.equal(courseFormSchema.safeParse({ ...base, name: "ab" }).success, false);
  assert.equal(courseFormSchema.safeParse({ ...base, status: "LIVE" }).success, false);
  assert.equal(courseFormSchema.safeParse({ ...base, price5Kes: "-5" }).success, false);
  assert.equal(courseFormSchema.safeParse({ ...base, imageUrl: "http://x.org/a.jpg" }).success, false);
  assert.equal(courseFormSchema.safeParse({ ...base, imageUrl: "javascript:alert(1)" }).success, false);
  assert.equal(courseFormSchema.safeParse({ ...base, imageUrl: "https://cdn.org/a.jpg" }).success, true);
});

test("publishing needs a length and a delivery mode", () => {
  const r = toCourseInput(courseFormSchema.parse({ ...base, lengths: [] }));
  assert.equal(r.ok, false); if (!r.ok) assert.ok(r.fieldErrors.lengths);
  assert.equal(toCourseInput(courseFormSchema.parse({ ...base, lengths: [], status: "DRAFT" })).ok, true); // drafts may be incomplete
});

test("existing course keeps its slug; new course with an unusable name is refused", () => {
  const e = toCourseInput(courseFormSchema.parse({ ...base, id: "abc", slug: "old-slug-kept", name: "Totally New Name" }));
  assert.ok(e.ok && e.value.slug === "old-slug-kept");
  const bad = toCourseInput(courseFormSchema.parse({ ...base, name: "***" }));
  assert.equal(bad.ok, false);
});
