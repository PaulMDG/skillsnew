import "server-only";
import { revalidatePath } from "next/cache";
import { getRepo } from "./repo";

/**
 * Public pages are cached for an hour. After any admin change, refresh exactly the pages that can show it.
 * Exact paths are used (not "/courses/[slug]" patterns), which are not reliably purged for pre-rendered pages.
 */
export async function revalidatePublicSite(opts: { courseSlug?: string } = {}) {
  for (const p of ["/", "/courses", "/sitemap.xml", "/llms.txt"]) revalidatePath(p);
  const cats = await (await getRepo()).adminListCategories(); // listing prices/names appear on category pages too
  for (const c of cats) revalidatePath(`/categories/${c.slug}`);
  if (opts.courseSlug) revalidatePath(`/courses/${opts.courseSlug}`);
}

/** After a blog change: the post, the index, feed, sitemap, llms.txt and every tag page it appears on (old and new tags). */
export function revalidateBlog(slug: string, tags: string[]) {
  for (const p of ["/", "/blog", "/blog/feed.xml", "/sitemap.xml", "/llms.txt"]) revalidatePath(p);
  revalidatePath(`/blog/${slug}`);
  for (const t of new Set(tags)) revalidatePath(`/blog/tag/${t}`);
}
