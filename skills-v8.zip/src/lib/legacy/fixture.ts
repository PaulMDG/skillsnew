import type { LegacyData, Options } from "./transform";

export const NOW = new Date("2026-10-12T07:00:00Z");
export const opts: Options = { studentUserType: 3, activeStatus: 1, statusMap: { 1: "CONFIRMED", 2: "CANCELLED" }, mediaBase: "https://old.example.org/uploads", legacyPaths: { course: "/course/", category: "/faculty/", blog: "/news/" }, now: NOW };

export const empty = (): LegacyData => ({ faculties: [], courses: [], courseoutlines: [], groupcharges: [], course_faqs: [], centers: [], courseschedules: [], users: [], courseapplications: [], usersCourses: [], usersCourses2: [], brochure_requests: [], download_leads: [], pdf_downloads: [], user_followups: [], news: [], pages: [] });

/** Synthetic old-system rows covering every rule in the transform (bad data, duplicates, opt-outs, off-rule schedules, hostile HTML). */
export function fixture(): LegacyData {
  const d = empty();
  d.faculties = [{ facultyID: 1, facultyName: "Project Management", slug: "project-management", img: "pm.jpg", facultyStatus: 1, meta_desc: "<b>PM</b>" }];
  d.courses = [
    { courseID: 10, facultyID: 1, courseName: "PMP Prep", introText: "<p>Prepare.</p><p>Practice.</p>", slug: "pmp-prep", duration: 5, durationType: 1, feeKshs: "85000.00", feeUsd: "650.00", courseObjectives: "<ul><li>Plan</li><li>Deliver</li></ul>", classtype: "Online and Classroom", imgUrl: "pmp.png", status: 1 },
    { courseID: 11, facultyID: 99, courseName: "Odd Course", introText: "", slug: "pmp-prep", duration: 3, durationType: 3, feeKshs: 0, feeUsd: 0, status: 0 },
    { courseID: 12, facultyID: 1, courseName: "Two Weeker", introText: "x", slug: "", duration: 2, durationType: 2, feeKshs: 120000, feeUsd: 0, status: 1 },
    { courseID: 13, facultyID: 1, courseName: "", slug: "none", status: 1 },
  ];
  d.courseoutlines = [{ outlineID: 2, courseID: 10, outlineItem: "Module 2", outlineItems: "<p>Tools</p>", status: 1 }, { outlineID: 1, courseID: 10, outlineItem: "Module 1", outlineItems: "<p>Basics</p>", status: 1 }, { outlineID: 3, courseID: 10, outlineItem: "Hidden", status: 0 }];
  d.course_faqs = [{ faq_id: 1, courseID: 10, question: "Q?", answer: "<p>A.</p>", sort_order: 1, is_published: 1, is_ai_generated: 1, ai_model: "gpt-4o" }, { faq_id: 2, courseID: 999, question: "Orphan", answer: "x" }];
  d.centers = [{ centerID: 1, centerName: "Nairobi, Kenya" }];
  d.courseschedules = [
    { scheduleID: 100, courseID: 10, startDate: "2026-10-12", endDate: "2026-10-16", scheduleType: "5" },   // valid week
    { scheduleID: 101, courseID: 10, startDate: "2026-09-26", endDate: "2026-09-30", scheduleType: "5" },   // Saturday start (history)
    { scheduleID: 102, courseID: 12, startDate: "2026-11-02", endDate: "2026-11-13", scheduleType: "10" },
  ];
  d.users = [
    { userID: 1, firstName: "Amina", surName: "Wanjiru", email: "Amina@Example.com", phone: "0712", userType: 3, accomodation: 1, pickAirport: 0 },
    { userID: 2, firstName: "Amina", surName: "W", email: "amina@example.com", userType: 3 },     // duplicate email
    { userID: 3, firstName: "Bad", email: "not-an-email", userType: 3 },
    { userID: 4, firstName: "Trainer", email: "trainer@x.org", userType: 2 },                      // staff, not imported
    { userID: 5, firstName: "Joseph", surName: "Okello", email: "joseph@example.com", userType: 3 },
  ];
  d.courseapplications = [
    { applicationID: 1, scheduleID: 100, courseID: 10, studentID: 1, status: 1 },
    { applicationID: 2, scheduleID: 101, courseID: 10, studentID: 5, status: 2 },
    { applicationID: 3, scheduleID: 555, courseID: 10, studentID: 5, status: 1 },                   // schedule row missing → orphan
    { applicationID: 4, scheduleID: 100, courseID: 10, studentID: 2, status: 1 },                   // dup user merged → same registration
    { applicationID: 5, scheduleID: 100, courseID: 10, studentID: 4, status: 1 },                   // staff user → skipped
  ];
  d.usersCourses = [{ id: 1, user_id: 1, course_id: 10, scheduleID: 100, startDate: "2026-10-12", endDate: "2026-10-16" }, { id: 2, user_id: 5, course_id: 10, scheduleID: 777, startDate: "2026-12-07", endDate: "2026-12-11" }];
  d.brochure_requests = [{ id: 1, fullName: "Peter", email: "peter@example.com", phone: "07", courseID: 10, created_at: "2026-09-01 10:00:00" }];
  d.download_leads = [{ id: 1, courseID: 10, fullName: "Peter K", email: "PETER@example.com", created_at: "2026-09-01 15:00:00" }, { id: 2, courseID: 10, fullName: "X", email: "bad", created_at: "2026-09-02 15:00:00" }];
  d.pdf_downloads = [{ id: 1, course_id: "10", name: "Esther", email: "esther@example.com", company: "Acme", country: "KE", created_at: "2026-09-03 09:00:00" }, { id: 2, course_id: "404", name: "Z", email: "z@example.com", created_at: "2026-09-03 09:00:00" }];
  d.user_followups = [
    { id: 1, email: "peter@example.com", name: "Peter", event_type: "brochure", course_name: "pmp  PREP", last_sent_stage: 2, next_send_date: "2026-10-01 08:00:00", status: "active", unsubscribe_token: "tok1", created_at: "2026-09-01 10:00:00" },
    { id: 2, email: "gone@example.com", name: "Gone", event_type: "brochure", course_name: "PMP Prep", last_sent_stage: 1, status: "unsubscribed", created_at: "2026-08-01 10:00:00" },
    { id: 3, email: "esther@example.com", name: "Esther", event_type: "registration", course_name: "Deleted Course", status: "active", created_at: "2026-08-01 10:00:00" },
    { id: 4, email: "far@example.com", name: "Far", event_type: "registration", course_name: "PMP Prep", last_sent_stage: 3, next_send_date: "2026-12-20 08:00:00", status: "active", created_at: "2026-09-20 10:00:00" },
  ];
  d.news = [{ newsID: 1, title: "Hello", slug: "hello", body: "<p>Hi</p><script>x</script>", status: 1, dateCreated: "2026-01-01 00:00:00" }, { newsID: 2, title: "Hello", slug: "hello", body: "<p>Dup</p>", status: 0 }];
  d.pages = [{ id: 1, title: "About", slug: "about", text: "<h2>About</h2>" }];
  return d;
}

