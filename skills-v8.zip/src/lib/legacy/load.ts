import { createHash } from "node:crypto";
import { type CourseLength, type DeliveryMode, type PrismaClient } from "@prisma/client";
import type { Plan } from "./transform";

const chunk = <T,>(a: T[], n = 500) => Array.from({ length: Math.ceil(a.length / n) }, (_, i) => a.slice(i * n, i * n + n));
const day = (s: string) => new Date(`${s}T00:00:00Z`);

/** Writes an import plan into the new database. Insert-only: existing records (matched by old id / unique key) are never overwritten. */
export async function loadPlan(db: PrismaClient, plan: Plan, log: (s: string) => void = (s) => console.log(`  ${s}`)) {
  const t0 = Date.now();
  {
    // ── media (images are linked by URL until file storage is connected)
    const mediaId = new Map<string, string>();
    const urls = [...new Set([...plan.categories.map((c) => c.imageUrl), ...plan.courses.map((c) => c.imageUrl), ...plan.posts.map((p) => p.imageUrl)].filter((u): u is string => !!u))];
    for (const u of urls) { const key = `url:${createHash("sha1").update(u).digest("hex")}`; mediaId.set(u, (await db.media.upsert({ where: { key }, update: {}, create: { key, url: u, kind: "image" }, select: { id: true } })).id); }
    log(`media: ${urls.length}`);

    // ── categories
    const catId = new Map<number, string>();
    for (const c of plan.categories) {
      const ex = c.legacyId > 0 ? await db.category.findUnique({ where: { legacyId: c.legacyId } }) : await db.category.findUnique({ where: { slug: c.slug } });
      catId.set(c.legacyId, (ex ?? await db.category.create({ data: {
        legacyId: c.legacyId > 0 ? c.legacyId : null, name: c.name, slug: c.slug, alias: c.alias, imageId: c.imageUrl ? mediaId.get(c.imageUrl) : null,
        metaKeywords: c.metaKeywords, metaDescription: c.metaDescription, status: c.status, sortOrder: c.sortOrder } })).id);
    }
    log(`categories: ${plan.categories.length}`);

    // ── centers
    for (const c of plan.centers) await db.center.upsert({ where: { legacyId: c.legacyId }, update: {}, create: { legacyId: c.legacyId, name: c.name } });
    log(`centers: ${plan.centers.length}`);

    // ── courses (+ outline, prices) — only newly created ones get children, so re-runs never duplicate or overwrite
    const courseId = new Map<number, string>();
    let newCourses = 0;
    for (const c of plan.courses) {
      const ex = await db.course.findUnique({ where: { legacyId: c.legacyId }, select: { id: true } });
      if (ex) { courseId.set(c.legacyId, ex.id); continue; }
      const made = await db.course.create({ data: {
        legacyId: c.legacyId, categoryId: catId.get(c.categoryLegacyId)!, name: c.name, slug: c.slug, description: c.description, objectives: c.objectives,
        targetAudience: c.targetAudience, methodology: c.methodology, imageId: c.imageUrl ? mediaId.get(c.imageUrl) : null,
        lengths: c.lengths as CourseLength[], deliveryModes: c.deliveryModes as DeliveryMode[], autoSchedule: true,
        metaDescription: c.metaDescription?.slice(0, 320), metaKeywords: c.metaKeywords, status: c.status,
      } });
      courseId.set(c.legacyId, made.id); newCourses++;
      const mod = plan.outline.filter((o) => o.courseLegacyId === c.legacyId);
      if (mod.length) await db.courseOutlineItem.createMany({ data: mod.map((o, i) => ({ courseId: made.id, title: o.title, body: o.body, sortOrder: i })) });
      const prices = (["FIVE_DAY", "TEN_DAY"] as const).flatMap((l) => (["KES", "USD"] as const).flatMap((cur) => { const v = c.prices[l]?.[cur]; return v != null ? [{ courseId: made.id, length: l, currency: cur, amount: v }] : []; }));
      if (prices.length) await db.coursePrice.createMany({ data: prices });
    }
    log(`courses: ${plan.courses.length} (${newCourses} new)`);

    for (const c of chunk(plan.groupRates)) await db.groupRate.createMany({ skipDuplicates: true, data: c.filter((g) => courseId.has(g.courseLegacyId)).map((g) => ({ legacyId: g.legacyId, courseId: courseId.get(g.courseLegacyId)!, groupSize: g.groupSize, rateKes: g.rateKes, rateUsd: g.rateUsd, isActive: g.isActive })) });
    for (const c of chunk(plan.faqs)) await db.courseFaq.createMany({ skipDuplicates: true, data: c.map((f) => ({ legacyId: f.legacyId, courseId: courseId.get(f.courseLegacyId)!, question: f.question, answer: f.answer, sortOrder: f.sortOrder, status: f.published ? "PUBLISHED" as const : "DRAFT" as const, aiGenerated: f.aiGenerated, aiModel: f.aiModel })) });
    log(`group rates: ${plan.groupRates.length}, faqs: ${plan.faqs.length}`);

    // ── schedules referenced by registrations
    const scheduleId = new Map<string, string>();
    for (const c of chunk(plan.schedules)) {
      await db.schedule.createMany({ skipDuplicates: true, data: c.map((s) => ({ courseId: courseId.get(s.courseLegacyId)!, length: s.length as CourseLength, startDate: day(s.startDate), endDate: day(s.endDate), generated: false, isLegacy: s.isLegacy })) });
    }
    for (const s of await db.schedule.findMany({ where: { courseId: { in: [...courseId.values()] } }, select: { id: true, courseId: true, length: true, startDate: true } })) {
      const legacy = [...courseId].find(([, v]) => v === s.courseId)?.[0];
      scheduleId.set(`${legacy}|${s.length}|${s.startDate.toISOString().slice(0, 10)}`, s.id);
    }
    log(`schedules: ${plan.schedules.length}`);

    // ── students → registrations
    for (const c of chunk(plan.students)) await db.student.createMany({ skipDuplicates: true, data: c.map((s) => ({ legacyId: s.legacyId, email: s.email, firstName: s.firstName, lastName: s.lastName, phone: s.phone, gender: s.gender, nationality: s.nationality, organisation: s.organisation, employerName: s.employerName, employerPhone: s.employerPhone, employerEmail: s.employerEmail, createdAt: s.createdAt ? new Date(s.createdAt) : undefined })) });
    const studentId = new Map((await db.student.findMany({ where: { email: { in: plan.students.map((s) => s.email) } }, select: { id: true, email: true } })).map((s) => [s.email, s.id]));
    for (const c of chunk(plan.registrations)) await db.registration.createMany({ skipDuplicates: true, data: c.flatMap((r) => {
      const sid = studentId.get(r.studentEmail), sch = scheduleId.get(r.scheduleKey), cid = courseId.get(r.courseLegacyId);
      return sid && sch && cid ? [{ legacyId: r.legacyId, studentId: sid, courseId: cid, scheduleId: sch, status: r.status as "PENDING", needsAccommodation: r.needsAccommodation, needsAirportPickup: r.needsAirportPickup }] : [];
    }) });
    log(`students: ${plan.students.length}, registrations: ${plan.registrations.length}`);

    // ── leads, opt-outs, follow-ups  (opt-outs FIRST so nothing below can ever email them)
    for (const c of chunk(plan.suppressions)) await db.emailSuppression.createMany({ skipDuplicates: true, data: c.map((email) => ({ email, reason: "UNSUBSCRIBED" as const })) });
    for (const c of chunk(plan.leads)) await db.lead.createMany({ skipDuplicates: true, data: c.map((l) => ({ legacyKey: l.legacyKey, courseId: courseId.get(l.courseLegacyId)!, fullName: l.fullName, email: l.email, phone: l.phone, company: l.company, country: l.country, createdAt: new Date(l.createdAt) })) });
    for (const c of chunk(plan.followUps)) await db.followUp.createMany({ skipDuplicates: true, data: c.map((f) => ({
      source: f.source, email: f.email, name: f.name, courseId: courseId.get(f.courseLegacyId)!, lastSentStage: f.lastSentStage, nextSendAt: f.nextSendAt ? new Date(f.nextSendAt) : null,
      status: f.status, createdAt: new Date(f.createdAt), ...(f.token ? { unsubscribeToken: f.token } : {}),
    })) });
    log(`leads: ${plan.leads.length}, follow-ups: ${plan.followUps.length}, opt-outs: ${plan.suppressions.length}`);

    // ── content + redirects
    for (const p of plan.posts) await db.blogPost.upsert({ where: { legacyId: p.legacyId }, update: {}, create: { legacyId: p.legacyId, title: p.title, slug: p.slug, body: p.body, format: "HTML", excerpt: p.excerpt, coverId: p.imageUrl ? mediaId.get(p.imageUrl) : null, metaDescription: p.metaDescription?.slice(0, 320), metaKeywords: p.metaKeywords, status: p.status, publishedAt: p.publishedAt ? new Date(p.publishedAt) : null, tags: [] } });
    for (const p of plan.pages) await db.page.upsert({ where: { legacyId: p.legacyId }, update: {}, create: { legacyId: p.legacyId, title: p.title, slug: p.slug, body: p.body, metaDescription: p.metaDescription, metaKeywords: p.metaKeywords } });
    for (const c of chunk(plan.redirects)) await db.redirect.createMany({ skipDuplicates: true, data: c });
    log(`posts: ${plan.posts.length}, pages: ${plan.pages.length}, redirects: ${plan.redirects.length}`);

    log(`done in ${((Date.now() - t0) / 1000).toFixed(1)}s`);
  }
}

