/**
 * Old (CodeIgniter/MySQL) data → new data model. PURE: no database, no network, so every rule is unit-tested.
 * The loader (scripts/import-legacy.ts) reads the old rows, calls buildPlan(), then writes the plan.
 */
import sanitizeHtml from "sanitize-html";
import { slugify } from "../admin-schemas";
import { assertWeekdayOnly, type PlannedSchedule } from "../schedules/dates";

export type Row = Record<string, unknown>;
export type Length = "FIVE_DAY" | "TEN_DAY";
export type Status = "PUBLISHED" | "DRAFT";

export interface LegacyData {
  faculties: Row[]; courses: Row[]; courseoutlines: Row[]; groupcharges: Row[]; course_faqs: Row[]; centers: Row[];
  courseschedules: Row[]; users: Row[]; courseapplications: Row[]; usersCourses: Row[]; usersCourses2: Row[];
  brochure_requests: Row[]; download_leads: Row[]; pdf_downloads: Row[]; user_followups: Row[]; news: Row[]; pages: Row[];
}

export interface Options {
  /** users.userType value that means "student" (the old usertypes table has no data, so this must be told). */
  studentUserType: number;
  /** status value meaning live/active (courses, faculties, news, outlines). */
  activeStatus: number;
  /** courseapplications.status → new registration status, e.g. {1:"CONFIRMED",2:"CANCELLED"}. Unmapped = PENDING. */
  statusMap: Record<number, "PENDING" | "CONFIRMED" | "ATTENDED" | "CANCELLED">;
  /** Public base URL of the old uploads folder, e.g. https://old-site.org/uploads/ (image filenames are appended). */
  mediaBase?: string;
  /** Old URL prefixes for 301 redirects, e.g. { course: "/course/", category: "/faculty/", blog: "/news/" }. */
  legacyPaths?: { course?: string; category?: string; blog?: string; page?: string };
  now: Date;
}

export interface Anomaly { kind: string; detail: string }

// ───────────── small pure helpers ─────────────
const str = (v: unknown): string => (v == null ? "" : String(v).trim());
const num = (v: unknown): number | null => { const n = Number(v); return v == null || v === "" || !Number.isFinite(n) ? null : n; };

const ENTITIES: Record<string, string> = { amp: "&", lt: "<", gt: ">", quot: '"', apos: "'", nbsp: " ", rsquo: "’", lsquo: "‘", ldquo: "“", rdquo: "”", ndash: "–", mdash: "—", hellip: "…", bull: "•" };
const decode = (s: string) => s.replace(/&(#x?[0-9a-f]+|[a-z]+);/gi, (m, e: string) => {
  if (e[0] === "#") { const c = e[1].toLowerCase() === "x" ? parseInt(e.slice(2), 16) : parseInt(e.slice(1), 10); return Number.isFinite(c) && c > 0 && c < 0x110000 ? String.fromCodePoint(c) : m; }
  return ENTITIES[e.toLowerCase()] ?? m;
});

/** Old content is HTML; course text in the new site is plain paragraphs. `bullets:false` puts list items on their own lines. */
export function htmlToText(html: unknown, opts: { bullets?: boolean } = {}): string {
  const bullet = opts.bullets === false ? "" : "• ";
  return decode(str(html)
    .replace(/<\s*(script|style)[^>]*>[\s\S]*?<\/\s*\1\s*>/gi, "")
    .replace(/<\s*br\s*\/?>/gi, "\n")
    .replace(/<\s*li[^>]*>/gi, `\n${bullet}`)
    .replace(/<\/\s*(p|div|h[1-6]|ul|ol|table|tr|blockquote)\s*>/gi, "\n\n")
    .replace(/<[^>]+>/g, ""))
    .replace(/[ \t\u00a0]+/g, " ").split("\n").map((l) => l.trim()).join("\n").replace(/\n{3,}/g, "\n\n").trim();
}

/** Rich content that must stay HTML (blog, pages): strictly allow-listed, scripts/handlers/iframes removed. */
export const cleanHtml = (html: unknown): string => sanitizeHtml(str(html), {
  allowedTags: ["p", "br", "h2", "h3", "h4", "ul", "ol", "li", "strong", "b", "em", "i", "u", "a", "blockquote", "img", "table", "thead", "tbody", "tr", "th", "td", "hr", "span", "div"],
  allowedAttributes: { a: ["href", "title", "target", "rel"], img: ["src", "alt", "title", "width", "height"] },
  allowedSchemes: ["http", "https", "mailto", "tel"], allowedSchemesByTag: { img: ["http", "https"] },
  transformTags: { a: sanitizeHtml.simpleTransform("a", { rel: "noopener noreferrer" }) },
});

export function normalizeEmail(v: unknown): string | null {
  const e = str(v).toLowerCase();
  return /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(e) && e.length <= 190 ? e : null;
}

/** MySQL dates arrive as 'YYYY-MM-DD' / 'YYYY-MM-DD HH:MM:SS' strings (mysql2 `dateStrings`). Zero dates → null. */
export function parseDate(v: unknown): Date | null {
  const s = str(v);
  if (!s || s.startsWith("0000")) return null;
  const d = new Date(s.length <= 10 ? `${s}T00:00:00Z` : `${s.replace(" ", "T")}Z`);
  return Number.isNaN(d.getTime()) ? null : d;
}
const iso = (d: Date) => d.toISOString().slice(0, 10);

/** courses.duration + durationType (1 Days, 2 Weeks, 3 Months, 4 Years) → a length we can schedule, else null. */
export function mapDuration(duration: unknown, type: unknown): Length | null {
  const d = num(duration), t = num(type);
  if (d == null) return null;
  if (t === 1) return d === 5 ? "FIVE_DAY" : d === 10 ? "TEN_DAY" : null;
  if (t === 2) return d === 1 ? "FIVE_DAY" : d === 2 ? "TEN_DAY" : null;
  return null;
}

export function scheduleLength(type: unknown, start: Date, end: Date): Length | null {
  const t = str(type);
  if (t === "5") return "FIVE_DAY";
  if (t === "10") return "TEN_DAY";
  const span = Math.round((end.getTime() - start.getTime()) / 86_400_000);
  return span >= 0 && span <= 6 ? "FIVE_DAY" : span <= 14 ? "TEN_DAY" : null;
}

export function followsWeekdayRule(length: Length, start: Date, end: Date): boolean {
  try { assertWeekdayOnly({ length, startDate: start, endDate: end } as PlannedSchedule); return true; } catch { return false; }
}

export function splitName(first: unknown, second: unknown, sur: unknown): { firstName: string; lastName: string } {
  const f = str(first), l = str(sur) || str(second);
  if (f && l) return { firstName: f, lastName: l };
  const parts = (f || l || "Unknown").split(/\s+/);
  return { firstName: parts[0], lastName: parts.slice(1).join(" ") || "-" };
}

const normName = (s: unknown) => str(s).toLowerCase().replace(/\s+/g, " ");

// ───────────── plan ─────────────
export interface PlanCategory { legacyId: number; name: string; slug: string; alias?: string; imageUrl?: string; metaKeywords?: string; metaDescription?: string; status: Status; sortOrder: number }
export interface PlanCourse {
  legacyId: number; categoryLegacyId: number; name: string; slug: string; description: string; objectives?: string; targetAudience?: string; methodology?: string;
  imageUrl?: string; lengths: Length[]; deliveryModes: ("CLASSROOM" | "ONLINE")[]; metaDescription?: string; metaKeywords?: string; status: Status;
  prices: Partial<Record<Length, { KES?: number; USD?: number }>>;
}
export interface PlanSchedule { key: string; courseLegacyId: number; length: Length; startDate: string; endDate: string; isLegacy: boolean }
export interface PlanStudent { email: string; firstName: string; lastName: string; legacyId: number; phone?: string; gender?: string; nationality?: string; organisation?: string; employerName?: string; employerPhone?: string; employerEmail?: string; createdAt?: string }
export interface PlanRegistration { legacyId?: number; studentEmail: string; scheduleKey: string; courseLegacyId: number; status: string; needsAccommodation: boolean; needsAirportPickup: boolean }
export interface PlanLead { legacyKey: string; courseLegacyId: number; fullName: string; email: string; phone?: string; company?: string; country?: string; createdAt: string }
export interface PlanFollowUp { source: "BROCHURE" | "REGISTRATION"; email: string; name: string; courseLegacyId: number; lastSentStage: number; nextSendAt: string | null; status: "ACTIVE" | "CONVERTED" | "UNSUBSCRIBED"; token?: string; createdAt: string }

export interface Plan {
  categories: PlanCategory[]; courses: PlanCourse[];
  outline: { courseLegacyId: number; title: string; body?: string; sortOrder: number }[];
  groupRates: { legacyId: number; courseLegacyId: number; groupSize: string; rateKes: number; rateUsd: number; isActive: boolean }[];
  faqs: { legacyId: number; courseLegacyId: number; question: string; answer: string; sortOrder: number; published: boolean; aiGenerated: boolean; aiModel?: string }[];
  centers: { legacyId: number; name: string }[];
  schedules: PlanSchedule[]; students: PlanStudent[]; registrations: PlanRegistration[]; leads: PlanLead[]; followUps: PlanFollowUp[];
  suppressions: string[];
  posts: { legacyId: number; title: string; slug: string; body: string; excerpt?: string; imageUrl?: string; metaDescription?: string; metaKeywords?: string; status: Status; publishedAt?: string }[];
  pages: { legacyId: number; title: string; slug: string; body: string; metaDescription?: string; metaKeywords?: string }[];
  redirects: { fromPath: string; toPath: string }[];
  report: { counts: Record<string, number>; anomalies: Anomaly[]; distributions: Record<string, Record<string, number>> };
}

function uniqueSlug(base: string, used: Set<string>, anomalies: Anomaly[], what: string): string {
  const root = slugify(base) || "item";
  let s = root, i = 2;
  while (used.has(s)) s = `${root}-${i++}`;
  if (s !== root) anomalies.push({ kind: `${what}_duplicate_slug`, detail: `"${base}" → ${s}` });
  used.add(s);
  return s;
}
const tally = (rows: Row[], key: string) => rows.reduce<Record<string, number>>((m, r) => { const k = str(r[key]) || "(empty)"; m[k] = (m[k] ?? 0) + 1; return m; }, {});
const media = (base: string | undefined, file: unknown) => (base && str(file) ? `${base.replace(/\/?$/, "/")}${str(file).replace(/^\/+/, "")}` : undefined);

export function buildPlan(d: LegacyData, o: Options): Plan {
  const A: Anomaly[] = [];
  const dist: Plan["report"]["distributions"] = {
    "users.userType": tally(d.users, "userType"), "courses.status": tally(d.courses, "status"),
    "courseapplications.status": tally(d.courseapplications, "status"), "courses.duration+type": tally(d.courses.map((c) => ({ k: `${str(c.duration)} ${str(c.durationType)}` })), "k"),
  };
  const active = (v: unknown): Status => (num(v) === o.activeStatus ? "PUBLISHED" : "DRAFT");

  // categories (old "faculties")
  const catSlugs = new Set<string>();
  const categories: PlanCategory[] = d.faculties.map((f, i) => ({
    legacyId: num(f.facultyID)!, name: str(f.facultyName) || `Category ${f.facultyID}`, slug: uniqueSlug(str(f.slug) || str(f.facultyName), catSlugs, A, "category"),
    alias: str(f.facultyAlias) || undefined, imageUrl: media(o.mediaBase, f.img), metaKeywords: str(f.meta_keywords) || undefined,
    metaDescription: str(f.meta_desc) ? htmlToText(f.meta_desc) : undefined, status: active(f.facultyStatus), sortOrder: i,
  })).filter((c) => c.legacyId != null);
  const catIds = new Set(categories.map((c) => c.legacyId));
  let fallback: PlanCategory | undefined;

  // schedules grouped per course (to learn which lengths a course has really run)
  const schedRows = d.courseschedules.map((s) => ({ row: s, id: num(s.scheduleID), course: num(s.courseID), start: parseDate(s.startDate), end: parseDate(s.endDate) }));
  const lengthsFromSchedules = new Map<number, Set<Length>>();
  for (const s of schedRows) {
    if (s.course == null || !s.start || !s.end) continue;
    const l = scheduleLength(s.row.scheduleType, s.start, s.end);
    if (l) (lengthsFromSchedules.get(s.course) ?? lengthsFromSchedules.set(s.course, new Set()).get(s.course)!).add(l);
  }

  // courses
  const courseSlugs = new Set<string>();
  const courses: PlanCourse[] = [];
  for (const c of d.courses) {
    const id = num(c.courseID); if (id == null) continue;
    const name = str(c.courseName); if (!name) { A.push({ kind: "course_no_name", detail: `courseID ${id} skipped` }); continue; }
    let catId = num(c.facultyID);
    if (catId == null || !catIds.has(catId)) {
      A.push({ kind: "course_no_category", detail: `"${name}" (facultyID ${str(c.facultyID)}) → "Uncategorised"` });
      fallback ??= { legacyId: -1, name: "Uncategorised", slug: uniqueSlug("uncategorised", catSlugs, A, "category"), status: "DRAFT", sortOrder: 999 };
      catId = -1;
    }
    const primary = mapDuration(c.duration, c.durationType);
    const lengths = new Set<Length>(primary ? [primary] : []);
    lengthsFromSchedules.get(id)?.forEach((l) => lengths.add(l));
    if (!lengths.size) A.push({ kind: "course_unmappable_duration", detail: `"${name}" (${str(c.duration)} type ${str(c.durationType)}) → no length; will appear under Unscheduled` });
    const prices: PlanCourse["prices"] = {};
    const kes = num(c.feeKshs), usd = num(c.feeUsd);
    if (primary && ((kes ?? 0) > 0 || (usd ?? 0) > 0)) prices[primary] = { ...((kes ?? 0) > 0 ? { KES: kes! } : {}), ...((usd ?? 0) > 0 ? { USD: usd! } : {}) };
    for (const l of lengths) if (!prices[l]) A.push({ kind: "course_needs_price", detail: `"${name}" has no ${l === "FIVE_DAY" ? "5" : "10"}-day price` });
    const cls = str(c.classtype).toLowerCase();
    courses.push({
      legacyId: id, categoryLegacyId: catId, name, slug: uniqueSlug(str(c.slug) || name, courseSlugs, A, "course"),
      description: htmlToText(c.introText) || name, objectives: htmlToText(c.courseObjectives, { bullets: false }) || undefined,
      targetAudience: htmlToText(c.targetAudience) || undefined, methodology: htmlToText(c.methodology) || undefined,
      imageUrl: media(o.mediaBase, c.imgUrl), lengths: [...lengths], deliveryModes: cls.includes("online") && !cls.includes("class") ? ["ONLINE"] : cls.includes("class") && !cls.includes("online") ? ["CLASSROOM"] : ["CLASSROOM", "ONLINE"],
      metaDescription: str(c.meta_desc) || undefined, metaKeywords: str(c.meta_keywords) || undefined, status: active(c.status), prices,
    });
  }
  if (fallback) categories.push(fallback);
  const courseIds = new Set(courses.map((c) => c.legacyId));
  const courseByName = new Map(courses.map((c) => [normName(c.name), c.legacyId]));

  const outline = d.courseoutlines.filter((r) => courseIds.has(num(r.courseID)!) && num(r.status) !== 0 && str(r.outlineItem)).map((r, i) => ({
    courseLegacyId: num(r.courseID)!, title: htmlToText(r.outlineItem).slice(0, 200), body: htmlToText(r.outlineItems, { bullets: true }) || undefined, sortOrder: num(r.outlineID) ?? i,
  })).sort((a, b) => a.courseLegacyId - b.courseLegacyId || a.sortOrder - b.sortOrder);

  const groupRates = d.groupcharges.filter((g) => courseIds.has(num(g.courseID)!)).map((g) => ({
    legacyId: num(g.groupChargeID)!, courseLegacyId: num(g.courseID)!, groupSize: str(g.groupSize), rateKes: num(g.rateKshs) ?? 0, rateUsd: num(g.rateUsd) ?? 0, isActive: num(g.status) === o.activeStatus,
  }));

  const faqs = d.course_faqs.filter((f) => courseIds.has(num(f.courseID)!) && str(f.question) && str(f.answer)).map((f) => ({
    legacyId: num(f.faq_id)!, courseLegacyId: num(f.courseID)!, question: str(f.question).slice(0, 512), answer: htmlToText(f.answer),
    sortOrder: num(f.sort_order) ?? 0, published: num(f.is_published) === 1, aiGenerated: num(f.is_ai_generated) === 1, aiModel: str(f.ai_model) || undefined,
  }));

  const centers = d.centers.map((c) => ({ legacyId: num(c.centerID)!, name: str(c.centerName) })).filter((c) => c.name);

  // students
  const students = new Map<string, PlanStudent>();
  const studentByLegacy = new Map<number, string>();
  let nonStudents = 0;
  for (const u of d.users) {
    const id = num(u.userID); if (id == null) continue;
    if (num(u.userType) !== o.studentUserType) { nonStudents++; continue; }
    const email = normalizeEmail(u.email);
    if (!email) { A.push({ kind: "student_bad_email", detail: `userID ${id} "${str(u.email)}" skipped (their registrations are skipped too)` }); continue; }
    if (students.has(email)) { A.push({ kind: "student_duplicate_email", detail: `userID ${id} merged into ${email}` }); studentByLegacy.set(id, email); continue; }
    students.set(email, {
      email, legacyId: id, ...splitName(u.firstName, u.secondName, u.surName), phone: str(u.phone) || undefined, gender: str(u.gender) || undefined, nationality: str(u.nationality) || undefined,
      organisation: str(u.organisationName) || undefined, employerName: str(u.employerName) || undefined, employerPhone: str(u.employerPhone) || undefined,
      employerEmail: normalizeEmail(u.employerEmail) ?? undefined, createdAt: parseDate(u.dateCreated)?.toISOString(),
    });
    studentByLegacy.set(id, email);
  }

  // registrations: union of courseapplications + usersCourses + usersCourses2, de-duplicated per student × schedule
  const schedById = new Map(schedRows.filter((s) => s.id != null).map((s) => [s.id!, s]));
  const schedules = new Map<string, PlanSchedule>();
  const registrations = new Map<string, PlanRegistration>();
  const userRow = new Map(d.users.map((u) => [num(u.userID), u]));

  const addReg = (src: string, userId: number | null, scheduleId: number | null, courseId: number | null, fallbackDates: { s: Date | null; e: Date | null }, legacyId: number | undefined, status: string) => {
    const email = userId != null ? studentByLegacy.get(userId) : undefined;
    if (!email) { A.push({ kind: "registration_missing_student", detail: `${src}: user ${userId} is not an importable student` }); return; }
    const sr = scheduleId != null ? schedById.get(scheduleId) : undefined;
    const courseLegacy = sr?.course ?? courseId;
    const start = sr?.start ?? fallbackDates.s, end = sr?.end ?? fallbackDates.e;
    if (courseLegacy == null || !courseIds.has(courseLegacy) || !start || !end) { A.push({ kind: "registration_orphan_schedule", detail: `${src}: schedule ${scheduleId}/course ${courseId} cannot be resolved` }); return; }
    const length = (sr && scheduleLength(sr.row.scheduleType, start, end)) ?? scheduleLength("", start, end);
    if (!length) { A.push({ kind: "registration_orphan_schedule", detail: `${src}: schedule ${scheduleId} has an unusable length` }); return; }
    const key = `${courseLegacy}|${length}|${iso(start)}`;
    if (!schedules.has(key)) {
      const ok = followsWeekdayRule(length, start, end);
      if (!ok) A.push({ kind: "schedule_not_weekday", detail: `course ${courseLegacy} ${iso(start)}→${iso(end)}: kept as OLD SYSTEM history` });
      schedules.set(key, { key, courseLegacyId: courseLegacy, length, startDate: iso(start), endDate: iso(end), isLegacy: !ok });
    }
    const rk = `${email}|${key}`;
    if (registrations.has(rk)) { const ex = registrations.get(rk)!; if (ex.legacyId == null) ex.legacyId = legacyId; return; }
    const u = userRow.get(userId);
    registrations.set(rk, { legacyId, studentEmail: email, scheduleKey: key, courseLegacyId: courseLegacy, status, needsAccommodation: num(u?.accomodation) === 1, needsAirportPickup: num(u?.pickAirport) === 1 });
  };
  for (const a of d.courseapplications) addReg("courseapplications", num(a.studentID), num(a.scheduleID), num(a.courseID), { s: null, e: null }, num(a.applicationID) ?? undefined, o.statusMap[num(a.status) ?? -1] ?? "PENDING");
  for (const [name, rows] of [["usersCourses", d.usersCourses], ["usersCourses2", d.usersCourses2]] as const)
    for (const r of rows) addReg(name, num(r.user_id), num(r.scheduleID), num(r.course_id), { s: parseDate(r.startDate), e: parseDate(r.endDate) }, undefined, "PENDING");

  // leads: three old tables, one new one
  const leads = new Map<string, PlanLead>();
  const addLead = (legacyKey: string, courseId: number | null, name: unknown, email: unknown, phone: unknown, company: unknown, country: unknown, at: unknown) => {
    const e = normalizeEmail(email);
    if (!e) { A.push({ kind: "lead_bad_email", detail: `${legacyKey} "${str(email)}" skipped` }); return; }
    if (courseId == null || !courseIds.has(courseId)) { A.push({ kind: "lead_unknown_course", detail: `${legacyKey} course ${courseId} skipped` }); return; }
    const created = parseDate(at) ?? o.now;
    const dedupe = `${e}|${courseId}|${iso(created)}`;
    if (leads.has(dedupe)) return;
    leads.set(dedupe, { legacyKey, courseLegacyId: courseId, fullName: str(name) || e, email: e, phone: str(phone) || undefined, company: str(company) || undefined, country: str(country) || undefined, createdAt: created.toISOString() });
  };
  for (const r of d.brochure_requests) addLead(`brochure_requests:${str(r.id)}`, num(r.courseID), r.fullName, r.email, r.phone, null, null, r.created_at);
  for (const r of d.download_leads) addLead(`download_leads:${str(r.id)}`, num(r.courseID), r.fullName, r.email, r.phone, null, null, r.created_at);
  for (const r of d.pdf_downloads) addLead(`pdf_downloads:${str(r.id)}`, num(r.course_id), r.name, r.email, r.phone, r.company, r.country, r.created_at);

  // follow-ups: carry live sequences over (so nobody restarts or is skipped) and, above all, honour opt-outs
  const followUps = new Map<string, PlanFollowUp>();
  const suppressions = new Set<string>();
  for (const f of d.user_followups) {
    const email = normalizeEmail(f.email); if (!email) continue;
    const status = str(f.status) as "active" | "converted" | "unsubscribed";
    if (status === "unsubscribed") suppressions.add(email);
    const cid = courseByName.get(normName(f.course_name));
    if (cid == null) { A.push({ kind: "followup_unmatched_course", detail: `"${str(f.course_name)}" (${email})` }); continue; }
    const source = str(f.event_type) === "registration" ? "REGISTRATION" : "BROCHURE";
    const created = parseDate(f.created_at) ?? o.now;
    const next = parseDate(f.next_send_date);
    // overdue stages must not fire all at once after go-live: resume no earlier than tomorrow
    const resume = next && next > o.now ? next : new Date(o.now.getTime() + 86_400_000);
    followUps.set(`${email}|${source}|${cid}`, {
      source, email, name: str(f.name) || email, courseLegacyId: cid, lastSentStage: num(f.last_sent_stage) ?? 0,
      nextSendAt: status === "active" ? resume.toISOString() : null, status: status === "converted" ? "CONVERTED" : status === "unsubscribed" ? "UNSUBSCRIBED" : "ACTIVE",
      token: str(f.unsubscribe_token) || undefined, createdAt: created.toISOString(),
    });
  }

  // content
  const postSlugs = new Set<string>();
  const posts = d.news.filter((n) => str(n.title)).map((n) => ({
    legacyId: num(n.newsID)!, title: str(n.title), slug: uniqueSlug(str(n.slug) || str(n.title), postSlugs, A, "post"), body: cleanHtml(n.body),
    excerpt: str(n.meta_desc) ? htmlToText(n.meta_desc).slice(0, 300) : undefined, imageUrl: media(o.mediaBase, n.img), metaDescription: str(n.meta_desc) || undefined,
    metaKeywords: str(n.meta_keywords) || undefined, status: active(n.status), publishedAt: parseDate(n.dateCreated)?.toISOString(),
  }));
  const pageSlugs = new Set<string>();
  const pages = d.pages.filter((p) => str(p.title)).map((p) => ({
    legacyId: num(p.id)!, title: str(p.title), slug: uniqueSlug(str(p.slug) || str(p.title), pageSlugs, A, "page"), body: cleanHtml(p.text),
    metaDescription: str(p.meta_desc) || undefined, metaKeywords: str(p.meta_keyword) || undefined,
  }));

  // 301s so existing Google rankings and bookmarks survive
  const redirects: Plan["redirects"] = [];
  const lp = o.legacyPaths ?? {};
  const add = (prefix: string | undefined, slug: string, to: string) => { if (prefix) { const from = `${prefix.replace(/\/?$/, "/")}${slug}`; if (from !== to) redirects.push({ fromPath: from, toPath: to }); } };
  for (const c of courses) { add(lp.course, c.slug, `/courses/${c.slug}`); }
  for (const c of categories) add(lp.category, c.slug, `/categories/${c.slug}`);
  for (const p of posts) add(lp.blog, p.slug, `/blog/${p.slug}`);
  for (const p of pages) add(lp.page, p.slug, `/${p.slug}`);

  const sched = [...schedules.values()];
  return {
    categories, courses, outline, groupRates, faqs, centers, schedules: sched, students: [...students.values()], registrations: [...registrations.values()],
    leads: [...leads.values()], followUps: [...followUps.values()], suppressions: [...suppressions], posts, pages, redirects,
    report: {
      counts: {
        categories: categories.length, courses: courses.length, "courses without any length": courses.filter((c) => !c.lengths.length).length, outlineModules: outline.length, groupRates: groupRates.length,
        faqs: faqs.length, centers: centers.length, students: students.size, "non-student users (not imported)": nonStudents,
        "schedules kept (needed by registrations)": sched.length, "of which off-rule history": sched.filter((s) => s.isLegacy).length,
        registrations: registrations.size, leads: leads.size, followUps: followUps.size, "opted-out addresses": suppressions.size, posts: posts.length, pages: pages.length, redirects: redirects.length,
      },
      anomalies: A, distributions: dist,
    },
  };
}
