import { test } from "node:test";
import assert from "node:assert/strict";
import { buildPlan, htmlToText, cleanHtml, mapDuration, scheduleLength, normalizeEmail, parseDate, splitName, followsWeekdayRule, type LegacyData, type Options } from "./transform";

import { NOW, opts, empty, fixture } from "./fixture";

test("html → text keeps paragraphs and list items, drops scripts, decodes entities", () => {
  const t = htmlToText("<p>Learn&nbsp;PM &amp; M&amp;E</p><script>alert(1)</script><p>Second<br>line</p><ul><li>One</li><li>Two &rsquo;x&rsquo;</li></ul>");
  assert.equal(t, "Learn PM & M&E\n\nSecond\nline\n\n• One\n• Two ’x’");
  assert.equal(htmlToText("<ul><li>A</li><li>B</li></ul>", { bullets: false }), "A\nB");
  assert.equal(htmlToText(null), "");
  assert.equal(htmlToText("&#8211; &#x2014; &bogus;"), "– — &bogus;");
});

test("rich html is sanitised: no scripts, handlers, iframes or javascript: links", () => {
  const c = cleanHtml('<p onclick="x()">Hi</p><script>alert(1)</script><iframe src="//evil"></iframe><a href="javascript:alert(1)">bad</a><a href="https://ok.org">ok</a><img src="javascript:x" onerror="y()"><img src="https://ok.org/a.png" alt="a">');
  assert.ok(!/script|iframe|onclick|onerror|javascript:/i.test(c), c);
  assert.match(c, /<a href="https:\/\/ok\.org" rel="noopener noreferrer">ok<\/a>/);
  assert.match(c, /<img src="https:\/\/ok\.org\/a\.png" alt="a" \/>/);
});

test("duration mapping: only 5/10 days or 1/2 weeks are schedulable", () => {
  assert.equal(mapDuration(5, 1), "FIVE_DAY"); assert.equal(mapDuration("10", 1), "TEN_DAY");
  assert.equal(mapDuration(1, 2), "FIVE_DAY"); assert.equal(mapDuration(2, 2), "TEN_DAY");
  assert.equal(mapDuration(3, 1), null); assert.equal(mapDuration(1, 3), null); assert.equal(mapDuration(null, 1), null);
});

test("schedule length from type or span; weekday rule check", () => {
  const d = (s: string) => parseDate(s)!;
  assert.equal(scheduleLength("5", d("2026-10-12"), d("2026-10-16")), "FIVE_DAY");
  assert.equal(scheduleLength("", d("2026-10-12"), d("2026-10-23")), "TEN_DAY");
  assert.equal(scheduleLength("", d("2026-10-12"), d("2026-12-23")), null);
  assert.equal(followsWeekdayRule("FIVE_DAY", d("2026-10-12"), d("2026-10-16")), true);
  assert.equal(followsWeekdayRule("FIVE_DAY", d("2026-10-10"), d("2026-10-14")), false); // Saturday start
  assert.equal(parseDate("0000-00-00"), null); assert.equal(parseDate("2026-10-12 08:30:00")?.toISOString(), "2026-10-12T08:30:00.000Z");
});

test("emails and names", () => {
  assert.equal(normalizeEmail("  Amina@Example.COM "), "amina@example.com");
  for (const bad of ["", "nope", "a@b", "a b@c.org", null]) assert.equal(normalizeEmail(bad), null);
  assert.deepEqual(splitName("Amina", "W.", "Wanjiru"), { firstName: "Amina", lastName: "Wanjiru" });
  assert.deepEqual(splitName("Joseph Okello", "", ""), { firstName: "Joseph", lastName: "Okello" });
  assert.deepEqual(splitName("", "", ""), { firstName: "Unknown", lastName: "-" });
});

test("plan: categories, fallback category, slug de-duplication, lengths, prices, drafts", () => {
  const p = buildPlan(fixture(), opts);
  assert.equal(p.categories.find((c) => c.legacyId === 1)!.imageUrl, "https://old.example.org/uploads/pm.jpg");
  assert.ok(p.categories.some((c) => c.name === "Uncategorised"), "orphaned courses get a home");
  assert.deepEqual(p.courses.map((c) => c.name), ["PMP Prep", "Odd Course", "Two Weeker"], "nameless course skipped");
  const [pmp, odd, two] = p.courses;
  assert.equal(pmp.slug, "pmp-prep"); assert.equal(odd.slug, "pmp-prep-2"); assert.equal(two.slug, "two-weeker");
  assert.deepEqual(pmp.lengths, ["FIVE_DAY"]); assert.deepEqual(pmp.prices, { FIVE_DAY: { KES: 85000, USD: 650 } });
  assert.deepEqual(odd.lengths, []); assert.equal(odd.status, "DRAFT"); assert.equal(odd.categoryLegacyId, -1);
  assert.deepEqual(two.lengths, ["TEN_DAY"]); assert.deepEqual(two.prices, { TEN_DAY: { KES: 120000 } });
  assert.equal(pmp.description, "Prepare.\n\nPractice."); assert.equal(pmp.objectives, "Plan\nDeliver");
  assert.deepEqual(pmp.deliveryModes, ["CLASSROOM", "ONLINE"]);
  const kinds = p.report.anomalies.map((a) => a.kind);
  for (const k of ["course_no_category", "course_unmappable_duration", "course_duplicate_slug", "course_no_name"]) assert.ok(kinds.includes(k), k);
});

test("plan: outline ordered, hidden modules dropped; faqs keep published/AI flags; orphans dropped", () => {
  const p = buildPlan(fixture(), opts);
  assert.deepEqual(p.outline.map((o) => o.title), ["Module 1", "Module 2"]);
  assert.equal(p.outline[0].body, "Basics");
  assert.equal(p.faqs.length, 1); assert.deepEqual([p.faqs[0].published, p.faqs[0].aiGenerated, p.faqs[0].aiModel], [true, true, "gpt-4o"]);
});

test("plan: students merged/filtered; registrations de-duplicated; off-rule history kept but flagged", () => {
  const p = buildPlan(fixture(), opts);
  assert.deepEqual(p.students.map((s) => s.email).sort(), ["amina@example.com", "joseph@example.com"]);
  assert.equal(p.report.counts["non-student users (not imported)"], 1);
  const regs = p.registrations;
  const amina = regs.filter((r) => r.studentEmail === "amina@example.com");
  assert.equal(amina.length, 1, "same student × schedule from 3 sources and a merged duplicate user = ONE registration");
  assert.deepEqual([amina[0].status, amina[0].needsAccommodation, amina[0].legacyId], ["CONFIRMED", true, 1]);
  const joseph = regs.filter((r) => r.studentEmail === "joseph@example.com");
  assert.equal(joseph.length, 2, "one from schedule 101, one rebuilt from usersCourses dates when schedule 777 is missing");
  assert.equal(joseph.find((r) => r.scheduleKey.endsWith("2026-09-26"))!.status, "CANCELLED");
  const hist = p.schedules.find((s) => s.startDate === "2026-09-26")!;
  assert.equal(hist.isLegacy, true);                                      // Saturday start → history, exempt from the DB rule
  assert.equal(p.schedules.find((s) => s.startDate === "2026-10-12")!.isLegacy, false);
  assert.equal(p.schedules.find((s) => s.startDate === "2026-12-07")!.isLegacy, false);  // rebuilt from dates, valid Mon–Fri
  assert.ok(p.report.anomalies.some((a) => a.kind === "registration_orphan_schedule"), "application pointing at a missing schedule is reported");
  assert.ok(p.report.anomalies.some((a) => a.kind === "student_bad_email"));
  // only schedules somebody is registered for are carried over; the engine regenerates the rest
  assert.equal(p.schedules.some((s) => s.courseLegacyId === 12), false);
});

test("plan: leads merged across three tables, bad rows reported", () => {
  const p = buildPlan(fixture(), opts);
  assert.deepEqual(p.leads.map((l) => l.email).sort(), ["esther@example.com", "peter@example.com"], "Peter appears in two tables the same day → once");
  assert.equal(p.leads.find((l) => l.email === "esther@example.com")!.company, "Acme");
  const kinds = p.report.anomalies.map((a) => a.kind);
  assert.ok(kinds.includes("lead_bad_email") && kinds.includes("lead_unknown_course"));
});

test("plan: follow-ups – sequences resume (never burst), unsubscribes become suppressions, tokens kept", () => {
  const p = buildPlan(fixture(), opts);
  const peter = p.followUps.find((f) => f.email === "peter@example.com")!;
  assert.equal(peter.lastSentStage, 2); assert.equal(peter.token, "tok1");
  assert.equal(new Date(peter.nextSendAt!).getTime(), NOW.getTime() + 86_400_000, "overdue next_send_date → resume tomorrow, not immediately");
  assert.equal(p.followUps.find((f) => f.email === "far@example.com")!.nextSendAt, "2026-12-20T08:00:00.000Z", "future date kept");
  const gone = p.followUps.find((f) => f.email === "gone@example.com")!;
  assert.deepEqual([gone.status, gone.nextSendAt], ["UNSUBSCRIBED", null]);
  assert.deepEqual(p.suppressions, ["gone@example.com"]);
  assert.equal(p.followUps.some((f) => f.email === "esther@example.com"), false, "course no longer exists");
});

test("plan: blog/pages sanitised, duplicate post slug handled, redirects for old URLs", () => {
  const p = buildPlan(fixture(), opts);
  assert.equal(p.posts[0].body, "<p>Hi</p>"); assert.deepEqual(p.posts.map((x) => x.slug), ["hello", "hello-2"]); assert.equal(p.posts[1].status, "DRAFT");
  assert.equal(p.pages[0].body, "<h2>About</h2>");
  assert.ok(p.redirects.some((r) => r.fromPath === "/course/pmp-prep" && r.toPath === "/courses/pmp-prep"));
  assert.ok(p.redirects.some((r) => r.fromPath === "/faculty/project-management" && r.toPath === "/categories/project-management"));
  assert.ok(p.redirects.some((r) => r.fromPath === "/news/hello" && r.toPath === "/blog/hello"));
});

test("plan: report shows distributions so the owner can confirm the guessed codes", () => {
  const p = buildPlan(fixture(), opts);
  assert.deepEqual(p.report.distributions["users.userType"], { "3": 4, "2": 1 });
  assert.deepEqual(p.report.distributions["courseapplications.status"], { "1": 4, "2": 1 });
});

test("empty database produces an empty, valid plan", () => {
  const p = buildPlan(empty(), opts);
  assert.equal(p.courses.length, 0); assert.deepEqual(p.report.anomalies, []);
});
