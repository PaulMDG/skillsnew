import { createHash } from "node:crypto";
import { headers } from "next/headers";

/** Client IP from the proxy header. Never stored raw – only a salted hash. */
export async function clientIp(): Promise<string> {
  const h = await headers();
  return (h.get("x-forwarded-for")?.split(",")[0] ?? h.get("x-real-ip") ?? "unknown").trim();
}

export const hashIp = (ip: string) =>
  createHash("sha256").update(`${ip}:${process.env.IP_HASH_SALT ?? "dev-salt"}`).digest("hex").slice(0, 32);
