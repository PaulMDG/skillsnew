import type { PrismaClient } from "@prisma/client";
import { createPrismaClient } from "./prisma-client";

const g = globalThis as unknown as { prisma?: PrismaClient };

function create(): PrismaClient {
  // No database configured (local preview on sample data): never connect, fail loudly if something tries to use one.
  if (!process.env.DATABASE_URL) return new Proxy({} as PrismaClient, { get: () => { throw new Error("DATABASE_URL is not set"); } });
  return createPrismaClient();
}

export const prisma = (g.prisma ??= create());
