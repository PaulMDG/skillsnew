import { PrismaClient } from "@prisma/client";
import { PrismaPg } from "@prisma/adapter-pg";

/**
 * One place that knows how to talk to PostgreSQL. The Rust-free client runs queries through the `pg` driver:
 * works on Vercel/Neon/Supabase/any Postgres, with no native engine file to ship.
 * Pool is small by default because serverless functions each hold their own pool; use your provider's pooled connection string.
 */
export function createPrismaClient(connectionString = process.env.DATABASE_URL): PrismaClient {
  if (!connectionString) throw new Error("DATABASE_URL is not set");
  return new PrismaClient({ adapter: new PrismaPg({ connectionString, max: Number(process.env.DB_POOL_MAX ?? 5) }) });
}
