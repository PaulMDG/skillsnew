import { z } from "zod";
import { slugify } from "../admin-schemas";
import type { PostInput } from "../types";

const opt = (max: number) => z.string().trim().max(max).optional().transform((v) => v || undefined);

/** "Leadership, M&E ,  leadership" → ["leadership","m-and-e"] : unique, URL-safe, max 8. */
export function parseTags(s: string): string[] {
  return [...new Set(s.split(",").map((t) => slugify(t).slice(0, 40)).filter(Boolean))].slice(0, 8);
}

/** The editor works in Nairobi time (UTC+3, no daylight saving). "2026-10-20T09:00" → 2026-10-20T06:00:00Z. */
export const eatToIso = (v: string): string | undefined => { const d = new Date(`${v}:00+03:00`); return v && !Number.isNaN(d.getTime()) ? d.toISOString() : undefined; };
export const isoToEat = (iso?: string | null): string => (iso ? new Date(new Date(iso).getTime() + 3 * 3_600_000).toISOString().slice(0, 16) : "");

export const postFormSchema = z.object({
  id: opt(60),
  title: z.string().trim().min(5, "Give the post a title").max(160),
  slug: z.string().trim().max(120).optional(),
  excerpt: opt(320),
  body: z.string().trim().min(1, "Write the post").max(200_000),
  format: z.enum(["MARKDOWN", "HTML"]),
  coverUrl: z.string().trim().max(500).optional().transform((v) => v || undefined).refine((v) => !v || /^https:\/\/\S+$/.test(v), "Use a full https:// link"),
  tags: z.string().max(300).optional().default(""),
  metaTitle: opt(70), metaDescription: opt(320), metaKeywords: opt(500),
  status: z.enum(["DRAFT", "PUBLISHED", "ARCHIVED"]),
  publishAt: z.string().optional().default(""),
  /** the publish time the form was opened with (exact, to the second) */
  publishedAtOrig: z.string().optional().default(""),
});

export function toPostInput(d: z.infer<typeof postFormSchema>, now = new Date()): { ok: true; value: PostInput } | { ok: false; fieldErrors: Record<string, string[]> } {
  const slug = d.id ? d.slug ?? "" : slugify(d.slug || d.title);
  if (!d.id && !/^[a-z0-9]+(?:-[a-z0-9]+)*$/.test(slug)) return { ok: false, fieldErrors: { slug: ["Lowercase letters, numbers and hyphens only"] } };
  if (d.status === "PUBLISHED" && d.body.length < 100) return { ok: false, fieldErrors: { body: ["Write at least a few sentences before publishing"] } };
  // The editor only shows minutes. If the person did not change the time, keep the exact stored instant (seconds included).
  const unchanged = !!d.publishedAtOrig && isoToEat(d.publishedAtOrig) === d.publishAt;
  const when = unchanged ? new Date(d.publishedAtOrig).toISOString() : eatToIso(d.publishAt);
  if (d.publishAt && !when) return { ok: false, fieldErrors: { publishAt: ["Enter a valid date and time"] } };
  const { publishAt: _p, publishedAtOrig: _o, tags, ...rest } = d; void _p; void _o;
  // first publication stamps "now" unless a date (past, or future = scheduled) was chosen
  const publishedAt = d.status === "PUBLISHED" ? (when ?? now.toISOString()) : when;
  return { ok: true, value: { ...rest, slug, tags: parseTags(tags), publishedAt } };
}
