import type { PostCard } from "../types";
import { abs, site } from "../site";

const x = (s: string) => s.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;").replace(/'/g, "&apos;");

/** RSS 2.0 for feed readers and AI/search crawlers. Titles/excerpts are escaped; no raw HTML is embedded. */
export function buildFeed(posts: PostCard[], now = new Date()): string {
  const items = posts.map((p) => `    <item>
      <title>${x(p.title)}</title>
      <link>${x(abs(`/blog/${p.slug}`))}</link>
      <guid isPermaLink="true">${x(abs(`/blog/${p.slug}`))}</guid>
      <pubDate>${new Date(p.publishedAt).toUTCString()}</pubDate>
      <description>${x(p.excerpt)}</description>${p.tags.map((t) => `\n      <category>${x(t)}</category>`).join("")}
    </item>`).join("\n");
  return `<?xml version="1.0" encoding="UTF-8"?>
<rss version="2.0" xmlns:atom="http://www.w3.org/2005/Atom">
  <channel>
    <title>${x(site.name)} Insights</title>
    <link>${x(abs("/blog"))}</link>
    <description>${x(site.tagline)}</description>
    <language>en</language>
    <lastBuildDate>${now.toUTCString()}</lastBuildDate>
    <atom:link href="${x(abs("/blog/feed.xml"))}" rel="self" type="application/rss+xml"/>
${items}
  </channel>
</rss>
`;
}
