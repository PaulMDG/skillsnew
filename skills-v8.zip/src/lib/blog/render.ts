import { marked } from "marked";
import sanitizeHtml from "sanitize-html";
import { slugify } from "../admin-schemas";
import type { BlogFormatT } from "../types";

export interface TocItem { id: string; text: string; level: 2 | 3 }

const stripTags = (h: string) => h.replace(/<[^>]+>/g, "").replace(/&amp;/g, "&").replace(/&lt;/g, "<").replace(/&gt;/g, ">").replace(/&quot;/g, '"').replace(/&#39;/g, "'").trim();

/**
 * Markdown or HTML in, SAFE HTML out. Whatever the author wrote (or pasted, or imported), only this allow-list survives:
 * no scripts, iframes, event handlers, inline styles, javascript:/data: links, or non-https images.
 */
export function renderPost(body: string, format: BlogFormatT): { html: string; toc: TocItem[] } {
  const raw = format === "MARKDOWN" ? (marked.parse(body, { async: false, gfm: true, breaks: false }) as string) : body;
  const clean = sanitizeHtml(raw, {
    allowedTags: ["p", "br", "h2", "h3", "h4", "ul", "ol", "li", "strong", "b", "em", "i", "u", "del", "sup", "sub", "a", "blockquote", "img", "figure", "figcaption", "table", "thead", "tbody", "tr", "th", "td", "hr", "pre", "code"],
    allowedAttributes: { a: ["href", "title", "rel", "target"], img: ["src", "alt", "title", "width", "height", "loading", "decoding"], th: ["align"], td: ["align"] },
    allowedSchemes: ["http", "https", "mailto", "tel"], allowedSchemesByTag: { img: ["https"] }, allowProtocolRelative: false,
    transformTags: {
      h1: "h2", // the post title is the page's only H1
      a: (tag, attribs) => {
        const external = /^https?:\/\//i.test(attribs.href ?? "");
        return { tagName: "a", attribs: { ...attribs, ...(external ? { rel: "noopener noreferrer nofollow", target: "_blank" } : {}) } };
      },
      img: (tag, attribs) => ({ tagName: "img", attribs: { ...attribs, loading: "lazy", decoding: "async", alt: attribs.alt ?? "" } }),
    },
  });

  // anchor ids + table of contents for long articles
  const toc: TocItem[] = [], used = new Set<string>();
  const html = clean.replace(/<h([23])>([\s\S]*?)<\/h\1>/g, (_m, lvl: string, inner: string) => {
    const text = stripTags(inner);
    let id = slugify(text) || "section", n = 2; const root = id;
    while (used.has(id)) id = `${root}-${n++}`;
    used.add(id); toc.push({ id, text, level: Number(lvl) as 2 | 3 });
    return `<h${lvl} id="${id}">${inner}</h${lvl}>`;
  });
  return { html, toc };
}

/** Plain text of a rendered post (used for reading time and auto-excerpts). */
export const plainText = (body: string, format: BlogFormatT) => stripTags(renderPost(body, format).html.replace(/<(?:\/p|\/h[1-6]|\/li|br\s*\/?)>/g, " "));

export const readingMinutes = (text: string) => Math.max(1, Math.round(text.split(/\s+/).filter(Boolean).length / 200));

export function autoExcerpt(body: string, format: BlogFormatT, max = 160): string {
  const t = plainText(body, format).replace(/\s+/g, " ");
  if (t.length <= max) return t;
  return `${t.slice(0, max).replace(/\s+\S*$/, "")}…`;
}
