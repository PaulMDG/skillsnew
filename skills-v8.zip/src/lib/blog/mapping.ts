import type { BlogFormatT, PostCard, PostDetail } from "../types";
import { site } from "../site";
import { autoExcerpt, plainText, readingMinutes } from "./render";

export interface PostRow {
  slug: string; title: string; excerpt?: string | null; body: string; format: BlogFormatT; coverUrl?: string | null;
  publishedAt: Date | string; updatedAt: Date | string; tags: string[]; author?: string | null; metaTitle?: string | null; metaDescription?: string | null;
}
const iso = (d: Date | string) => new Date(d).toISOString();

export const toCard = (r: PostRow): PostCard => ({
  slug: r.slug, title: r.title, excerpt: r.excerpt?.trim() || autoExcerpt(r.body, r.format), coverUrl: r.coverUrl ?? null,
  publishedAt: iso(r.publishedAt), tags: r.tags, readingMinutes: readingMinutes(plainText(r.body, r.format)), author: r.author?.trim() || site.name,
});

export const toDetail = (r: PostRow, related: PostRow[]): PostDetail => ({
  ...toCard(r), body: r.body, format: r.format, updatedAt: iso(r.updatedAt), metaTitle: r.metaTitle, metaDescription: r.metaDescription, related: related.map(toCard),
});
