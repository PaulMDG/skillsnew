import { test } from "node:test";
import assert from "node:assert/strict";
import { renderPost, plainText, readingMinutes, autoExcerpt } from "./render";
import { parseTags, eatToIso, isoToEat, postFormSchema, toPostInput } from "./schema";
import { buildFeed } from "./feed";

test("markdown renders; every dangerous construct is stripped", () => {
  const md = `# Big title\n\nIntro with **bold** and a [course](/courses/pmp-prep) and [site](https://example.org).\n\n## Section A\n\n<script>alert(1)</script>\n<iframe src="https://evil.example"></iframe>\n<p onclick="x()" style="color:red">Click</p>\n\n[bad](javascript:alert(1)) [data](data:text/html;base64,AAAA)\n\n![ok](https://cdn.example.org/a.png) ![http](http://cdn.example.org/b.png) ![js](javascript:alert(1))\n\n| a | b |\n|---|---|\n| 1 | 2 |\n\n\`\`\`\ncode block\n\`\`\`\n\n### Sub`;
  const { html, toc } = renderPost(md, "MARKDOWN");
  assert.ok(!/<script|<iframe|onclick|style=|javascript:|data:text|http:\/\/cdn/i.test(html), html);
  assert.ok(!/<h1/.test(html) && /<h2 id="big-title">/.test(html), "h1 demoted to h2");
  assert.match(html, /<a href="\/courses\/pmp-prep">course<\/a>/);                                // internal link untouched
  assert.match(html, /<a href="https:\/\/example\.org" rel="noopener noreferrer nofollow" target="_blank">site<\/a>/);
  assert.match(html, /<img src="https:\/\/cdn\.example\.org\/a\.png" alt="ok" loading="lazy" decoding="async" \/>/);
  assert.match(html, /<table>/); assert.match(html, /<pre><code>code block/);
  assert.deepEqual(toc.map((t) => [t.level, t.id]), [[2, "big-title"], [2, "section-a"], [3, "sub"]]);
});

test("HTML format (imported posts) is sanitised the same way, ids de-duplicated", () => {
  const { html, toc } = renderPost('<h2>Intro</h2><p onmouseover="x()">hi</p><script>x</script><h2>Intro</h2><a href="https://a.org">a</a><object data="x"></object>', "HTML");
  assert.ok(!/script|onmouseover|object/.test(html));
  assert.deepEqual(toc.map((t) => t.id), ["intro", "intro-2"]);
});

test("reading time and excerpts", () => {
  assert.equal(readingMinutes("word ".repeat(100)), 1); assert.equal(readingMinutes("word ".repeat(1000)), 5); assert.equal(readingMinutes(""), 1);
  const body = "## Heading\n\n" + "This is a sentence about training. ".repeat(20);
  const ex = autoExcerpt(body, "MARKDOWN", 100);
  assert.ok(ex.length <= 102 && ex.endsWith("…") && !ex.includes("#") && !ex.includes("<"), ex);
  assert.equal(autoExcerpt("Short post.", "MARKDOWN"), "Short post.");
  assert.match(plainText("**a** & b", "MARKDOWN"), /^a & b$/);
});

test("tags: unique, URL-safe, capped", () => {
  assert.deepEqual(parseTags("Leadership, M&E ,  leadership, Café,,"), ["leadership", "m-and-e", "cafe"]);
  assert.equal(parseTags(Array.from({ length: 20 }, (_, i) => `t${i}`).join(",")).length, 8);
  assert.deepEqual(parseTags(""), []);
});

test("Nairobi time conversion round-trips (UTC+3, no DST)", () => {
  assert.equal(eatToIso("2026-10-20T09:00"), "2026-10-20T06:00:00.000Z");
  assert.equal(isoToEat("2026-10-20T06:00:00.000Z"), "2026-10-20T09:00");
  assert.equal(isoToEat(eatToIso("2026-12-31T23:30")), "2026-12-31T23:30");
  assert.equal(eatToIso("garbage"), undefined); assert.equal(isoToEat(null), "");
});

const base = { title: "How to plan a project", body: "x".repeat(150), format: "MARKDOWN", status: "PUBLISHED", tags: "PM, Planning" };
test("post form: slug from title, publishing stamps now, schedule and draft rules", () => {
  const now = new Date("2026-10-12T07:00:00Z");
  const r = toPostInput(postFormSchema.parse(base), now); assert.ok(r.ok); if (!r.ok) return;
  assert.equal(r.value.slug, "how-to-plan-a-project"); assert.equal(r.value.publishedAt, now.toISOString()); assert.deepEqual(r.value.tags, ["pm", "planning"]);
  const sch = toPostInput(postFormSchema.parse({ ...base, publishAt: "2026-11-01T08:00" }), now); assert.ok(sch.ok && sch.value.publishedAt === "2026-11-01T05:00:00.000Z");
  const draft = toPostInput(postFormSchema.parse({ ...base, status: "DRAFT", body: "short" }), now); assert.ok(draft.ok && draft.value.publishedAt === undefined, "drafts may be unfinished and unscheduled");
  assert.equal(toPostInput(postFormSchema.parse({ ...base, body: "too short" }), now).ok, false);
  assert.equal(toPostInput(postFormSchema.parse({ ...base, publishAt: "nonsense" }), now).ok, false);
  assert.equal(postFormSchema.safeParse({ ...base, coverUrl: "http://x.org/a.jpg" }).success, false);
  assert.equal(postFormSchema.safeParse({ ...base, title: "abc" }).success, false);
  const edit = toPostInput(postFormSchema.parse({ ...base, id: "p1", slug: "kept-slug", title: "Totally different title" }), now); assert.ok(edit.ok && edit.value.slug === "kept-slug");
});

test("re-saving a published post keeps its exact publish instant; changing the time changes it", () => {
  const exact = "2026-10-12T07:00:42.123Z"; // seconds the editor cannot display
  const keep = toPostInput(postFormSchema.parse({ ...base, id: "p1", slug: "s", publishAt: isoToEat(exact), publishedAtOrig: exact }));
  assert.ok(keep.ok && keep.value.publishedAt === exact, "unchanged → untouched");
  const moved = toPostInput(postFormSchema.parse({ ...base, id: "p1", slug: "s", publishAt: "2026-12-01T10:00", publishedAtOrig: exact }));
  assert.ok(moved.ok && moved.value.publishedAt === "2026-12-01T07:00:00.000Z", "edited → new time");
});

test("RSS feed is well-formed and escapes hostile titles", () => {
  const xml = buildFeed([{ slug: "a-b", title: `M&E <script>"Tips"</script> & 'more'`, excerpt: "5 < 6 & 7", coverUrl: null, publishedAt: "2026-10-01T06:00:00.000Z", tags: ["m&e"], readingMinutes: 3, author: "Team" }], new Date("2026-10-12T07:00:00Z"));
  assert.ok(!xml.includes("<script>")); assert.match(xml, /<title>M&amp;E &lt;script&gt;&quot;Tips&quot;&lt;\/script&gt; &amp; &apos;more&apos;<\/title>/);
  assert.match(xml, /<pubDate>Thu, 01 Oct 2026 06:00:00 GMT<\/pubDate>/); assert.match(xml, /<category>m&amp;e<\/category>/);
  assert.equal((xml.match(/<item>/g) ?? []).length, 1); assert.ok(xml.startsWith('<?xml version="1.0"'));
});
