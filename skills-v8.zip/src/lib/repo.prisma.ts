import { Prisma, type CourseLength, type Currency } from "@prisma/client";
import { createHash } from "node:crypto";
import { prisma } from "./db";
import type { Repo } from "./repo";
import type { CourseCard, CourseDetail, Length, PriceMap, ScheduleDTO } from "./types";
import { addDays, assertWeekdayOnly, buildSchedule, nairobiToday, toISODate } from "./schedules/dates";
import { toCard as postCard, toDetail as postDetail, type PostRow } from "./blog/mapping";
import { courseContentHash } from "./faq/hash";
import { ensureCourseSchedules, listUnscheduledCourses } from "./schedules/engine";

const LEAD_DAYS = Number(process.env.SCHEDULE_LEAD_DAYS ?? 1);
const upcomingCutoff = () => addDays(nairobiToday(), LEAD_DAYS);
const published = { status: "PUBLISHED" as const };

const cardSelect = {
  id: true, name: true, slug: true, summary: true, description: true, lengths: true,
  category: { select: { name: true, slug: true, iconKey: true } },
  image: { select: { url: true } },
  prices: { select: { length: true, currency: true, amount: true } },
} satisfies Prisma.CourseSelect;

type CardRow = Prisma.CourseGetPayload<{ select: typeof cardSelect }>;

function priceFrom(prices: CardRow["prices"]): PriceMap {
  const out: PriceMap = {};
  for (const p of prices) {
    const n = Number(p.amount);
    out[p.currency] = out[p.currency] == null ? n : Math.min(out[p.currency]!, n);
  }
  return out;
}

const toCard = (c: CardRow): CourseCard => ({
  id: c.id, name: c.name, slug: c.slug,
  summary: c.summary ?? c.description.replace(/<[^>]+>/g, " ").replace(/\s+/g, " ").trim().slice(0, 160),
  categoryName: c.category.name, categorySlug: c.category.slug, iconKey: c.category.iconKey,
  imageUrl: c.image?.url, lengths: c.lengths, priceFrom: priceFrom(c.prices),
});


const LENGTHS: CourseLength[] = ["FIVE_DAY", "TEN_DAY"];
const CURRENCIES: Currency[] = ["KES", "USD"];

/** One row per course × length × currency; a blank field removes the price. */
async function writePrices(tx: Prisma.TransactionClient, courseId: string, prices: Partial<Record<Length, PriceMap>>) {
  for (const length of LENGTHS) for (const currency of CURRENCIES) {
    const amount = prices[length]?.[currency];
    if (amount == null) await tx.coursePrice.deleteMany({ where: { courseId, length, currency } });
    else await tx.coursePrice.upsert({ where: { courseId_length_currency: { courseId, length, currency } }, update: { amount }, create: { courseId, length, currency, amount } });
  }
}

/** Images are referenced by URL until file storage (R2/Cloudinary) is connected. */
async function mediaFor(url?: string) {
  if (!url) return null;
  const key = `url:${createHash("sha1").update(url).digest("hex")}`;
  return prisma.media.upsert({ where: { key }, update: {}, create: { key, url, kind: "image" }, select: { id: true } });
}

const isUnique = (e: unknown) => e instanceof Prisma.PrismaClientKnownRequestError && e.code === "P2002";

const visiblePost = () => ({ status: "PUBLISHED" as const, publishedAt: { lte: new Date() } });
const postSelect = { slug: true, title: true, excerpt: true, body: true, format: true, tags: true, publishedAt: true, updatedAt: true, metaTitle: true, metaDescription: true, cover: { select: { url: true } }, author: { select: { name: true } } } satisfies Prisma.BlogPostSelect;
type PostSel = Prisma.BlogPostGetPayload<{ select: typeof postSelect }>;
const toRow = (r: Omit<PostSel, "publishedAt"> & { publishedAt: Date | null }): PostRow => ({ ...r, publishedAt: r.publishedAt ?? r.updatedAt, coverUrl: r.cover?.url, author: r.author?.name });

export const prismaRepo: Repo = {
  async listCategories() {
    const rows = await prisma.category.findMany({
      where: published, orderBy: [{ sortOrder: "asc" }, { name: "asc" }],
      include: { image: { select: { url: true } }, _count: { select: { courses: { where: published } } } },
    });
    return rows.map((c) => ({ id: c.id, name: c.name, slug: c.slug, description: c.description, iconKey: c.iconKey, imageUrl: c.image?.url, courseCount: c._count.courses }));
  },

  async getCategory(slug) {
    const c = await prisma.category.findFirst({
      where: { slug, ...published },
      include: { image: { select: { url: true } }, _count: { select: { courses: { where: published } } } },
    });
    return c && { id: c.id, name: c.name, slug: c.slug, description: c.description, iconKey: c.iconKey, imageUrl: c.image?.url, courseCount: c._count.courses };
  },

  async listCourses({ categorySlug, q } = {}) {
    const rows = await prisma.course.findMany({
      where: {
        ...published,
        ...(categorySlug && { category: { slug: categorySlug } }),
        ...(q && { OR: [{ name: { contains: q, mode: "insensitive" } }, { summary: { contains: q, mode: "insensitive" } }] }),
      },
      select: cardSelect, orderBy: { name: "asc" },
    });
    return rows.map(toCard);
  },

  async getCourse(slug) {
    const c = await prisma.course.findFirst({
      where: { slug, ...published },
      select: {
        ...cardSelect, objectives: true, targetAudience: true, methodology: true, metaTitle: true, metaDescription: true,
        outline: { orderBy: { sortOrder: "asc" }, select: { title: true, body: true } },
        faqs: { where: { status: "PUBLISHED" }, orderBy: { sortOrder: "asc" }, select: { question: true, answer: true } },
        schedules: {
          where: { status: "OPEN", startDate: { gte: upcomingCutoff() } },
          orderBy: { startDate: "asc" }, take: 80, select: { id: true, length: true, startDate: true, endDate: true },
        },
      },
    });
    if (!c) return null;
    const prices: CourseDetail["prices"] = {};
    for (const p of c.prices) (prices[p.length as Length] ??= {})[p.currency] = Number(p.amount);
    const schedules: ScheduleDTO[] = c.schedules.filter((s) => c.lengths.includes(s.length)).map((s) => ({
      id: s.id, length: s.length, startDate: toISODate(s.startDate), endDate: toISODate(s.endDate),
    }));
    return {
      ...toCard(c), description: c.description, objectives: c.objectives, targetAudience: c.targetAudience,
      methodology: c.methodology, outline: c.outline, prices, schedules, faqs: c.faqs,
      metaTitle: c.metaTitle, metaDescription: c.metaDescription,
    };
  },

  async getHomeData() {
    const [categories, featured, next, courses, categoriesCount, centers] = await Promise.all([
      this.listCategories(),
      prisma.course.findMany({ where: { ...published, lengths: { isEmpty: false } }, select: cardSelect, orderBy: { updatedAt: "desc" }, take: 6 }),
      prisma.schedule.findMany({
        where: { status: "OPEN", startDate: { gte: upcomingCutoff() }, course: published },
        orderBy: [{ startDate: "asc" }, { course: { name: "asc" } }], take: 8,
        select: { id: true, length: true, startDate: true, endDate: true, course: { select: { name: true, slug: true, prices: { select: { length: true, currency: true, amount: true } } } } },
      }),
      prisma.course.count({ where: published }),
      prisma.category.count({ where: published }),
      prisma.center.count({ where: { isActive: true } }),
    ]);
    return {
      categories, featured: featured.map(toCard),
      upcoming: next.map((s) => ({
        scheduleId: s.id, courseName: s.course.name, courseSlug: s.course.slug, length: s.length,
        startDate: toISODate(s.startDate), endDate: toISODate(s.endDate),
        price: priceFrom(s.course.prices.filter((p) => p.length === s.length)),
      })),
      totals: { courses, categories: categoriesCount, centers },
    };
  },

  async listCenters() {
    const rows = await prisma.center.findMany({ where: { isActive: true }, orderBy: { name: "asc" } });
    return rows.map((c) => ({ id: c.id, name: c.name }));
  },

  async createLead(i) {
    const course = await prisma.course.findFirst({ where: { slug: i.courseSlug, ...published }, select: { id: true, name: true } });
    if (!course) return { ok: false, error: "Course not found" };
    const lead = await prisma.lead.create({
      data: { courseId: course.id, fullName: i.fullName, email: i.email, phone: i.phone, country: i.country, company: i.company, ipHash: i.ipHash },
      select: { id: true },
    });
    return { ok: true, leadId: lead.id, courseName: course.name };
  },

  async createRegistration(i) {
    const course = await prisma.course.findFirst({ where: { slug: i.courseSlug, ...published }, select: { id: true, name: true } });
    const schedule = course && await prisma.schedule.findFirst({ where: { id: i.scheduleId, courseId: course.id, status: "OPEN" }, select: { id: true, startDate: true, endDate: true, length: true } });
    if (!course || !schedule) return { ok: false, error: "That start date is no longer available. Please pick another." };
    const center = i.deliveryMode === "CLASSROOM" && i.centerId ? await prisma.center.findUnique({ where: { id: i.centerId }, select: { id: true, name: true } }) : null;

    const student = await prisma.student.upsert({
      where: { email: i.email },
      update: { phone: i.phone, organisation: i.organisation },
      create: { firstName: i.firstName, lastName: i.lastName, email: i.email, phone: i.phone, organisation: i.organisation },
    });
    let registrationId: string;
    try {
      registrationId = (await prisma.registration.create({
        data: {
          studentId: student.id, courseId: course.id, scheduleId: schedule.id, deliveryMode: i.deliveryMode,
          centerId: center?.id ?? null, participants: i.participants,
          needsAccommodation: i.needsAccommodation, needsAirportPickup: i.needsAirportPickup, notes: i.notes,
        },
        select: { id: true },
      })).id;
    } catch (e) {
      if (e instanceof Prisma.PrismaClientKnownRequestError && e.code === "P2002") return { ok: false, error: "You are already registered for this date." };
      throw e;
    }
    return {
      ok: true,
      summary: {
        registrationId, email: i.email, name: `${i.firstName} ${i.lastName}`, phone: i.phone, courseSlug: i.courseSlug, courseName: course.name,
        startDate: toISODate(schedule.startDate), endDate: toISODate(schedule.endDate), length: schedule.length,
        deliveryMode: i.deliveryMode, centerName: center?.name, participants: i.participants,
      },
    };
  },

  async recordBrochureDownload(leadId) {
    await prisma.lead.updateMany({ where: { id: leadId }, data: { downloadCount: { increment: 1 }, lastDownloadedAt: new Date() } });
  },

  async listLeads({ q, limit }) {
    const rows = await prisma.lead.findMany({
      where: q ? { OR: [{ email: { contains: q, mode: "insensitive" } }, { fullName: { contains: q, mode: "insensitive" } }] } : {},
      orderBy: { createdAt: "desc" }, take: limit, include: { course: { select: { name: true, slug: true } } },
    });
    return rows.map((l) => ({
      id: l.id, name: l.fullName, email: l.email, phone: l.phone, company: l.company, country: l.country, course: l.course.name, courseSlug: l.course.slug,
      createdAt: l.createdAt.toISOString(), downloadCount: l.downloadCount, lastDownloadedAt: l.lastDownloadedAt?.toISOString() ?? null,
    }));
  },

  async listStudents({ q, limit }) {
    const rows = await prisma.student.findMany({
      where: q ? { OR: [{ email: { contains: q, mode: "insensitive" } }, { firstName: { contains: q, mode: "insensitive" } }, { lastName: { contains: q, mode: "insensitive" } }] } : {},
      orderBy: { createdAt: "desc" }, take: limit,
      include: { registrations: { orderBy: { createdAt: "desc" }, include: { course: { select: { name: true, slug: true } }, schedule: { select: { startDate: true, endDate: true, length: true } }, center: { select: { name: true } } } } },
    });
    return rows.map((s) => ({
      id: s.id, name: `${s.firstName} ${s.lastName}`, email: s.email, phone: s.phone, organisation: s.organisation, createdAt: s.createdAt.toISOString(),
      registrations: s.registrations.map((r) => ({
        id: r.id, course: r.course.name, courseSlug: r.course.slug, startDate: toISODate(r.schedule.startDate), endDate: toISODate(r.schedule.endDate),
        length: r.schedule.length, status: r.status, mode: r.deliveryMode, center: r.center?.name, registeredAt: r.createdAt.toISOString(),
      })),
    }));
  },

  async getDashboardStats() {
    const since = addDays(new Date(), -30);
    const [students, registrations, regs30, courses, categories, leads, leads30, recentRegs, recentLeads] = await Promise.all([
      prisma.student.count(), prisma.registration.count(), prisma.registration.count({ where: { createdAt: { gte: since } } }),
      prisma.course.count({ where: published }), prisma.category.count({ where: published }),
      prisma.lead.count(), prisma.lead.count({ where: { createdAt: { gte: since } } }),
      prisma.registration.findMany({ orderBy: { createdAt: "desc" }, take: 6, select: { id: true, createdAt: true, student: { select: { firstName: true, lastName: true } }, course: { select: { name: true } }, schedule: { select: { startDate: true } } } }),
      prisma.lead.findMany({ orderBy: { createdAt: "desc" }, take: 6, select: { id: true, fullName: true, email: true, createdAt: true, course: { select: { name: true } } } }),
    ]);
    return {
      students, registrations, registrationsLast30: regs30, publishedCourses: courses, categories,
      brochureDownloads: leads, brochureDownloadsLast30: leads30,
      recentRegistrations: recentRegs.map((r) => ({ id: r.id, student: `${r.student.firstName} ${r.student.lastName}`, course: r.course.name, startDate: toISODate(r.schedule.startDate), createdAt: r.createdAt.toISOString() })),
      recentLeads: recentLeads.map((l) => ({ id: l.id, name: l.fullName, email: l.email, course: l.course.name, createdAt: l.createdAt.toISOString() })),
    };
  },

  async adminListCourses() {
    const rows = await prisma.course.findMany({
      orderBy: { name: "asc" },
      select: {
        id: true, name: true, slug: true, lengths: true, status: true, category: { select: { name: true } },
        _count: { select: { schedules: { where: { status: "OPEN", startDate: { gte: upcomingCutoff() } } } } },
      },
    });
    return rows.map((c) => ({ id: c.id, name: c.name, slug: c.slug, category: c.category.name, lengths: c.lengths, status: c.status, upcoming: c._count.schedules }));
  },

  async listUnscheduled() {
    return listUnscheduledCourses(prisma);
  },


  async getCourseForEdit(id) {
    const c = await prisma.course.findUnique({ where: { id }, include: { outline: { orderBy: { sortOrder: "asc" } }, prices: true, image: { select: { url: true } } } });
    if (!c) return null;
    const prices: Partial<Record<Length, PriceMap>> = {};
    for (const p of c.prices) (prices[p.length] ??= {})[p.currency] = Number(p.amount);
    return {
      id: c.id, name: c.name, slug: c.slug, categoryId: c.categoryId, summary: c.summary ?? undefined, description: c.description,
      objectives: c.objectives ?? undefined, targetAudience: c.targetAudience ?? undefined, methodology: c.methodology ?? undefined,
      imageUrl: c.image?.url, lengths: c.lengths, deliveryModes: c.deliveryModes, autoSchedule: c.autoSchedule, status: c.status,
      metaTitle: c.metaTitle ?? undefined, metaDescription: c.metaDescription ?? undefined, metaKeywords: c.metaKeywords ?? undefined,
      outline: c.outline.map((o) => ({ title: o.title, body: o.body ?? undefined })), prices,
    };
  },

  async saveCourse(i) {
    const cat = await prisma.category.findUnique({ where: { id: i.categoryId }, select: { id: true } });
    if (!cat) return { ok: false, error: "Category not found", fieldErrors: { categoryId: ["Choose a category"] } };
    const image = await mediaFor(i.imageUrl);
    const data = {
      name: i.name, summary: i.summary ?? null, description: i.description, objectives: i.objectives ?? null, targetAudience: i.targetAudience ?? null,
      methodology: i.methodology ?? null, lengths: i.lengths, deliveryModes: i.deliveryModes, autoSchedule: i.autoSchedule, status: i.status,
      metaTitle: i.metaTitle ?? null, metaDescription: i.metaDescription ?? null, metaKeywords: i.metaKeywords ?? null,
      categoryId: i.categoryId, imageId: image?.id ?? null,
      contentHash: courseContentHash(i),
    };
    try {
      const course = await prisma.$transaction(async (tx) => {
        const c = i.id ? await tx.course.update({ where: { id: i.id }, data }) : await tx.course.create({ data: { ...data, slug: i.slug } });
        await tx.courseOutlineItem.deleteMany({ where: { courseId: c.id } });
        if (i.outline.length) await tx.courseOutlineItem.createMany({ data: i.outline.map((o, n) => ({ courseId: c.id, title: o.title, body: o.body ?? null, sortOrder: n })) });
        await writePrices(tx, c.id, i.prices);
        return c;
      });
      // Saving is what creates the 52 / 26 weekday schedules for newly chosen lengths
      if (course.status !== "ARCHIVED") await ensureCourseSchedules(prisma, course.id);
      return { ok: true, id: course.id, slug: course.slug };
    } catch (e) {
      if (isUnique(e)) return { ok: false, error: "A course with this URL already exists", fieldErrors: { slug: ["Already used by another course"] } };
      throw e;
    }
  },

  async listCategoryOptions() {
    return prisma.category.findMany({ where: { status: { not: "ARCHIVED" } }, orderBy: [{ sortOrder: "asc" }, { name: "asc" }], select: { id: true, name: true } });
  },

  async adminListCategories() {
    const rows = await prisma.category.findMany({ orderBy: [{ sortOrder: "asc" }, { name: "asc" }], include: { _count: { select: { courses: true } } } });
    return rows.map((c) => ({ id: c.id, name: c.name, slug: c.slug, iconKey: c.iconKey, status: c.status, courses: c._count.courses, sortOrder: c.sortOrder }));
  },

  async getCategoryForEdit(id) {
    const c = await prisma.category.findUnique({ where: { id }, include: { image: { select: { url: true } } } });
    return c && {
      id: c.id, name: c.name, slug: c.slug, description: c.description ?? undefined, iconKey: c.iconKey ?? undefined, imageUrl: c.image?.url,
      metaTitle: c.metaTitle ?? undefined, metaDescription: c.metaDescription ?? undefined, metaKeywords: c.metaKeywords ?? undefined, sortOrder: c.sortOrder, status: c.status,
    };
  },

  async saveCategory(i) {
    const image = await mediaFor(i.imageUrl);
    const data = {
      name: i.name, description: i.description ?? null, iconKey: i.iconKey ?? null, imageId: image?.id ?? null,
      metaTitle: i.metaTitle ?? null, metaDescription: i.metaDescription ?? null, metaKeywords: i.metaKeywords ?? null, sortOrder: i.sortOrder, status: i.status,
    };
    try {
      const c = i.id ? await prisma.category.update({ where: { id: i.id }, data }) : await prisma.category.create({ data: { ...data, slug: i.slug } });
      return { ok: true, id: c.id, slug: c.slug };
    } catch (e) {
      if (isUnique(e)) return { ok: false, error: "A category with this URL already exists", fieldErrors: { slug: ["Already used by another category"] } };
      throw e;
    }
  },

  async listPriceRows() {
    const rows = await prisma.course.findMany({ where: { status: { not: "ARCHIVED" } }, orderBy: [{ category: { name: "asc" } }, { name: "asc" }], select: { id: true, name: true, lengths: true, category: { select: { name: true } }, prices: true } });
    return rows.map((c) => {
      const prices: Partial<Record<Length, PriceMap>> = {};
      for (const p of c.prices) (prices[p.length] ??= {})[p.currency] = Number(p.amount);
      return { courseId: c.id, name: c.name, category: c.category.name, lengths: c.lengths, prices };
    });
  },

  async setCoursePrices(courseId, prices) {
    await prisma.$transaction((tx) => writePrices(tx, courseId, prices));
  },


  async listSchedulesAdmin({ courseId, from, limit }) {
    const rows = await prisma.schedule.findMany({
      where: { ...(courseId ? { courseId } : {}), ...(from ? { startDate: { gte: new Date(`${from}T00:00:00Z`) } } : {}) },
      orderBy: [{ startDate: "asc" }, { course: { name: "asc" } }], take: limit,
      select: { id: true, courseId: true, length: true, startDate: true, endDate: true, status: true, generated: true, isLegacy: true, course: { select: { name: true, slug: true } }, _count: { select: { registrations: true } } },
    });
    return rows.map((r) => ({ id: r.id, courseId: r.courseId, course: r.course.name, courseSlug: r.course.slug, length: r.length, startDate: toISODate(r.startDate), endDate: toISODate(r.endDate), status: r.status, generated: r.generated, legacy: r.isLegacy, registrations: r._count.registrations }));
  },

  async addSchedule({ courseId, length, startDate }) {
    const course = await prisma.course.findUnique({ where: { id: courseId }, select: { slug: true, lengths: true } });
    if (!course) return { ok: false, error: "Course not found" };
    if (!course.lengths.includes(length)) return { ok: false, error: "This course is not offered in that length. Change it on the course page first." };
    const plan = buildSchedule(length, new Date(`${startDate}T00:00:00Z`));
    try { assertWeekdayOnly(plan); } catch (e) { return { ok: false, error: e instanceof Error ? e.message : "Invalid dates" }; }
    if (plan.startDate.getTime() <= nairobiToday().getTime()) return { ok: false, error: "The start date must be in the future." };
    try {
      await prisma.schedule.create({ data: { courseId, length, startDate: plan.startDate, endDate: plan.endDate, generated: false } });
    } catch (e) {
      if (isUnique(e)) return { ok: false, error: "A schedule already exists for that course, length and start date." };
      throw e;
    }
    return { ok: true, courseSlug: course.slug };
  },

  async setScheduleStatus(id, status) {
    const s = await prisma.schedule.update({ where: { id }, data: { status }, select: { course: { select: { slug: true } } } }).catch(() => null);
    return s ? { ok: true, courseSlug: s.course.slug } : { ok: false, error: "Schedule not found" };
  },


  async getFaqContext(courseId) {
    const course = await this.getCourseForEdit(courseId);
    if (!course) return null;
    const [cat, faqs, row] = await Promise.all([
      prisma.category.findUnique({ where: { id: course.categoryId }, select: { name: true } }),
      prisma.courseFaq.findMany({ where: { courseId, status: { in: ["PUBLISHED", "REJECTED"] } }, select: { question: true } }), // never regenerate what was published or rejected
      prisma.course.findUnique({ where: { id: courseId }, select: { faqSourceHash: true } }),
    ]);
    return { course, categoryName: cat?.name ?? "", existingQuestions: faqs.map((f) => f.question), faqSourceHash: row?.faqSourceHash ?? null };
  },

  async listFaqCandidates() {
    const rows = await prisma.course.findMany({
      where: { status: "PUBLISHED" },
      select: { id: true, slug: true, name: true, contentHash: true, faqSourceHash: true, _count: { select: { faqRuns: { where: { status: "FAILED", createdAt: { gte: new Date(Date.now() - 86_400_000) } } } } } },
    });
    return rows.map((r) => ({ id: r.id, slug: r.slug, name: r.name, contentHash: r.contentHash, faqSourceHash: r.faqSourceHash, recentFailures: r._count.faqRuns }));
  },

  async saveGeneratedFaqs({ courseId, hash, faqs, model, publish }) {
    return prisma.$transaction(async (tx) => {
      await tx.courseFaq.deleteMany({ where: { courseId, aiGenerated: true, status: "DRAFT" } });
      const last = await tx.courseFaq.aggregate({ where: { courseId }, _max: { sortOrder: true } });
      const start = (last._max.sortOrder ?? -1) + 1;
      await tx.courseFaq.createMany({ data: faqs.map((f, i) => ({ courseId, question: f.question, answer: f.answer, sortOrder: start + i, status: publish ? "PUBLISHED" as const : "DRAFT" as const, aiGenerated: true, aiModel: model })) });
      await tx.course.update({ where: { id: courseId }, data: { faqSourceHash: hash } });
      await tx.course.updateMany({ where: { id: courseId, contentHash: null }, data: { contentHash: hash } });
      return faqs.length;
    });
  },

  async logFaqRun(r) {
    await prisma.faqGenerationRun.create({ data: { courseId: r.courseId, status: r.status, model: r.model, promptTokens: r.promptTokens, completionTokens: r.completionTokens, durationMs: r.durationMs, error: r.error?.slice(0, 1000) } });
  },

  async listFaqsAdmin({ status, courseId, limit }) {
    const rows = await prisma.courseFaq.findMany({
      where: { ...(status ? { status } : {}), ...(courseId ? { courseId } : {}) },
      orderBy: [{ course: { name: "asc" } }, { sortOrder: "asc" }], take: limit, include: { course: { select: { name: true, slug: true } } },
    });
    return rows.map((f) => ({ id: f.id, courseId: f.courseId, course: f.course.name, courseSlug: f.course.slug, question: f.question, answer: f.answer, status: f.status, aiGenerated: f.aiGenerated, model: f.aiModel, createdAt: f.createdAt.toISOString() }));
  },

  async faqCounts() {
    const [groups, courses] = await Promise.all([prisma.courseFaq.groupBy({ by: ["status"], _count: true }), prisma.courseFaq.groupBy({ by: ["courseId"], where: { status: "PUBLISHED" } })]);
    const n = (s: string) => groups.find((g) => g.status === s)?._count ?? 0;
    return { published: n("PUBLISHED"), draft: n("DRAFT"), rejected: n("REJECTED"), coursesWithPublished: courses.length };
  },

  async updateFaq(id, patch) {
    const f = await prisma.courseFaq.update({ where: { id }, data: patch, select: { course: { select: { slug: true } } } }).catch(() => null);
    return f ? { ok: true, courseSlug: f.course.slug } : { ok: false, error: "FAQ not found" };
  },

  async addFaq(courseId, question, answer) {
    const course = await prisma.course.findUnique({ where: { id: courseId }, select: { slug: true } });
    if (!course) return { ok: false, error: "Course not found" };
    const last = await prisma.courseFaq.aggregate({ where: { courseId }, _max: { sortOrder: true } });
    await prisma.courseFaq.create({ data: { courseId, question, answer, sortOrder: (last._max.sortOrder ?? -1) + 1, status: "PUBLISHED", aiGenerated: false } });
    return { ok: true, courseSlug: course.slug };
  },

  async setCourseFaqsStatus(courseId, from, to) {
    const course = await prisma.course.findUnique({ where: { id: courseId }, select: { slug: true } });
    if (!course) return { ok: false, error: "Course not found" };
    const r = await prisma.courseFaq.updateMany({ where: { courseId, status: from }, data: { status: to } });
    return { ok: true, courseSlug: course.slug, count: r.count };
  },


  async listPosts({ page, pageSize, tag }) {
    const where = { ...visiblePost(), ...(tag ? { tags: { has: tag } } : {}) };
    const [rows, total] = await Promise.all([
      prisma.blogPost.findMany({ where, orderBy: { publishedAt: "desc" }, skip: (page - 1) * pageSize, take: pageSize, select: postSelect }),
      prisma.blogPost.count({ where }),
    ]);
    return { posts: rows.map((r) => postCard(toRow(r))), total };
  },

  async getPost(slug) {
    const r = await prisma.blogPost.findFirst({ where: { slug, ...visiblePost() }, select: postSelect });
    if (!r) return null;
    const related = await prisma.blogPost.findMany({ where: { ...visiblePost(), slug: { not: slug }, ...(r.tags.length ? { tags: { hasSome: r.tags } } : {}) }, orderBy: { publishedAt: "desc" }, take: 3, select: postSelect });
    const fill = related.length >= 3 ? related : [...related, ...(await prisma.blogPost.findMany({ where: { ...visiblePost(), slug: { notIn: [slug, ...related.map((x) => x.slug)] } }, orderBy: { publishedAt: "desc" }, take: 3 - related.length, select: postSelect }))];
    return postDetail(toRow(r), fill.map(toRow));
  },

  async listPostTags() {
    const rows = await prisma.blogPost.findMany({ where: visiblePost(), select: { tags: true } });
    const m = new Map<string, number>();
    for (const r of rows) for (const t of r.tags) m.set(t, (m.get(t) ?? 0) + 1);
    return [...m].map(([tag, count]) => ({ tag, count })).sort((a, b) => b.count - a.count || a.tag.localeCompare(b.tag));
  },

  async listPostSlugs() {
    return (await prisma.blogPost.findMany({ where: visiblePost(), select: { slug: true, updatedAt: true }, orderBy: { publishedAt: "desc" } })).map((r) => ({ slug: r.slug, updatedAt: r.updatedAt.toISOString() }));
  },

  async adminListPosts({ status, q, limit }) {
    const now = new Date();
    const rows = await prisma.blogPost.findMany({
      where: { ...(status ? { status } : {}), ...(q ? { title: { contains: q, mode: "insensitive" as const } } : {}) },
      orderBy: { updatedAt: "desc" }, take: limit, select: { id: true, title: true, slug: true, status: true, publishedAt: true, tags: true, updatedAt: true, author: { select: { name: true } } },
    });
    return rows.map((r) => ({ id: r.id, title: r.title, slug: r.slug, status: r.status, publishedAt: r.publishedAt?.toISOString() ?? null, tags: r.tags, author: r.author?.name ?? "", updatedAt: r.updatedAt.toISOString(), scheduled: r.status === "PUBLISHED" && !!r.publishedAt && r.publishedAt > now }));
  },

  async getPostForEdit(id) {
    const r = await prisma.blogPost.findUnique({ where: { id }, include: { cover: { select: { url: true } }, author: { select: { name: true } } } });
    return r && { id: r.id, title: r.title, slug: r.slug, excerpt: r.excerpt ?? undefined, body: r.body, format: r.format, coverUrl: r.cover?.url, tags: r.tags, metaTitle: r.metaTitle ?? undefined,
      metaDescription: r.metaDescription ?? undefined, metaKeywords: r.metaKeywords ?? undefined, status: r.status, publishedAt: r.publishedAt?.toISOString(), author: r.author?.name ?? "" };
  },

  async getPostPreview(id) {
    const r = await prisma.blogPost.findUnique({ where: { id }, select: { ...postSelect, publishedAt: true } });
    return r ? postDetail(toRow({ ...r, publishedAt: r.publishedAt ?? new Date() }), []) : null;
  },

  async savePost(i, author) {
    const media = await mediaFor(i.coverUrl);
    const data = {
      title: i.title, excerpt: i.excerpt ?? null, body: i.body, format: i.format, coverId: media?.id ?? null, tags: i.tags,
      metaTitle: i.metaTitle ?? null, metaDescription: i.metaDescription ?? null, metaKeywords: i.metaKeywords ?? null, status: i.status,
      ...(i.publishedAt ? { publishedAt: new Date(i.publishedAt) } : {}),
    };
    try {
      const p = i.id ? await prisma.blogPost.update({ where: { id: i.id }, data }) : await prisma.blogPost.create({ data: { ...data, slug: i.slug, authorId: author.id } });
      return { ok: true, id: p.id, slug: p.slug };
    } catch (e) {
      if (isUnique(e)) return { ok: false, error: "A post with this URL already exists", fieldErrors: { slug: ["Already used by another post"] } };
      throw e;
    }
  },

  async findRedirect(path) {
    const candidates = [...new Set([path, path.replace(/\/+$/, ""), `${path.replace(/\/+$/, "")}/`])];
    const r = await prisma.redirect.findFirst({ where: { fromPath: { in: candidates } }, select: { toPath: true } });
    return r?.toPath ?? null;
  },

  async generateSchedules(courseId) {
    const r = await ensureCourseSchedules(prisma, courseId);
    return r.created.FIVE_DAY + r.created.TEN_DAY;
  },
};
