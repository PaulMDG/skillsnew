import type { Currency, Length, PriceMap } from "./types";

const dm = new Intl.DateTimeFormat("en-GB", { day: "numeric", month: "short", timeZone: "UTC" });
const dmy = new Intl.DateTimeFormat("en-GB", { day: "numeric", month: "short", year: "numeric", timeZone: "UTC" });
const month = new Intl.DateTimeFormat("en-GB", { month: "long", year: "numeric", timeZone: "UTC" });

export const formatRange = (startISO: string, endISO: string) =>
  `${dm.format(new Date(startISO))} – ${dmy.format(new Date(endISO))}`;
export const formatDate = (iso: string) => dmy.format(new Date(iso));
export const formatMonth = (iso: string) => month.format(new Date(iso));

export const lengthLabel: Record<Length, string> = { FIVE_DAY: "5 days", TEN_DAY: "10 days" };

export function money(amount: number, currency: Currency): string {
  return new Intl.NumberFormat(currency === "KES" ? "en-KE" : "en-US", {
    style: "currency", currency, maximumFractionDigits: 0,
  }).format(amount).replace(/\u00a0/g, " ");
}

export function priceText(p: PriceMap | undefined): string {
  if (!p) return "On request";
  const parts = [p.KES != null && money(p.KES, "KES"), p.USD != null && money(p.USD, "USD")].filter(Boolean);
  return parts.length ? parts.join(" · ") : "On request";
}

const postDay = new Intl.DateTimeFormat("en-GB", { day: "numeric", month: "long", year: "numeric", timeZone: "Africa/Nairobi" });
/** Blog dates are shown in Nairobi time, matching how the editor schedules them. */
export const formatPostDate = (iso: string) => postDay.format(new Date(iso));
