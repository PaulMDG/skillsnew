import { PDFDocument, PDFFont, PDFPage, StandardFonts, rgb } from "pdf-lib";
import type { CourseDetail, Length } from "../types";
import { formatRange, lengthLabel, priceText } from "../format";
import { abs, site } from "../site";

const A4: [number, number] = [595.28, 841.89];
const M = 48; // margin
const C = {
  brand: rgb(0.043, 0.514, 0.361), dark: rgb(0.031, 0.22, 0.165), ink: rgb(0.067, 0.141, 0.114),
  muted: rgb(0.333, 0.4, 0.37), line: rgb(0.886, 0.918, 0.902), surface: rgb(0.961, 0.973, 0.965), accent: rgb(0.933, 0.624, 0.039), white: rgb(1, 1, 1),
};

/** Standard PDF fonts only cover WinAnsi: swap look-alikes, drop anything else instead of crashing. */
function clean(s: string, font: PDFFont): string {
  const map: Record<string, string> = { "→": "->", "✓": "-", "≥": ">=", "≤": "<=", "\u00a0": " ", "\u200b": "" };
  const allowed = new Set(font.getCharacterSet());
  return Array.from(s.replace(/[→✓≥≤\u00a0\u200b]/g, (c) => map[c]))
    .map((ch) => (allowed.has(ch.codePointAt(0)!) || ch === "\n" ? ch : ""))
    .join("");
}

function wrap(text: string, font: PDFFont, size: number, maxWidth: number): string[] {
  const lines: string[] = [];
  for (const para of clean(text, font).split(/\r?\n/)) {
    let line = "";
    for (const word of para.split(/\s+/).filter(Boolean)) {
      const test = line ? `${line} ${word}` : word;
      if (font.widthOfTextAtSize(test, size) <= maxWidth) line = test;
      else { if (line) lines.push(line); line = word; }
    }
    lines.push(line);
  }
  return lines;
}

export async function buildBrochure(course: CourseDetail, now = new Date()): Promise<Uint8Array> {
  const doc = await PDFDocument.create();
  doc.setTitle(`${course.name} – Course brochure`);
  doc.setAuthor(site.name);
  doc.setCreator(site.name);
  const reg = await doc.embedFont(StandardFonts.Helvetica);
  const bold = await doc.embedFont(StandardFonts.HelveticaBold);

  let page!: PDFPage;
  let y = 0;
  const W = A4[0] - 2 * M;

  const footer = (p: PDFPage, n: number) => {
    p.drawLine({ start: { x: M, y: 40 }, end: { x: A4[0] - M, y: 40 }, thickness: 0.5, color: C.line });
    p.drawText(clean(`${site.name}  |  ${site.email}  |  ${site.phone}`, reg), { x: M, y: 26, size: 8, font: reg, color: C.muted });
    p.drawText(`Page ${n}`, { x: A4[0] - M - 30, y: 26, size: 8, font: reg, color: C.muted });
  };

  const newPage = (first = false) => {
    page = doc.addPage(A4);
    const n = doc.getPageCount();
    if (first) {
      page.drawRectangle({ x: 0, y: A4[1] - 150, width: A4[0], height: 150, color: C.dark });
      page.drawRectangle({ x: 0, y: A4[1] - 154, width: A4[0], height: 4, color: C.accent });
      page.drawText(clean(site.name.toUpperCase(), bold), { x: M, y: A4[1] - 44, size: 11, font: bold, color: C.accent });
      let ty = A4[1] - 76;
      for (const l of wrap(course.name, bold, 24, W).slice(0, 3)) { page.drawText(l, { x: M, y: ty, size: 24, font: bold, color: C.white }); ty -= 29; }
      page.drawText(clean(course.categoryName, reg), { x: M, y: A4[1] - 140, size: 10, font: reg, color: rgb(0.66, 0.89, 0.78) });
      y = A4[1] - 154 - 30;
    } else {
      page.drawRectangle({ x: 0, y: A4[1] - 8, width: A4[0], height: 8, color: C.brand });
      y = A4[1] - 48;
    }
    footer(page, n);
  };
  const ensure = (h: number) => { if (y - h < 60) newPage(); };

  const heading = (t: string, keepWith = 50) => {
    ensure(keepWith); // keeps a heading together with the start of its content
    page.drawText(clean(t, bold), { x: M, y, size: 14, font: bold, color: C.dark });
    page.drawRectangle({ x: M, y: y - 6, width: 28, height: 2.5, color: C.brand });
    y -= 26;
  };
  const para = (t: string, size = 10.5, color = C.ink, indent = 0) => {
    for (const l of wrap(t, reg, size, W - indent)) { ensure(size + 6); page.drawText(l, { x: M + indent, y, size, font: reg, color }); y -= size + 5; }
    y -= 4;
  };
  const bullet = (t: string) => {
    const lines = wrap(t, reg, 10.5, W - 16);
    ensure(lines.length * 15 + 4);
    page.drawCircle({ x: M + 4, y: y + 3.5, size: 2.2, color: C.brand });
    for (const l of lines) { page.drawText(l, { x: M + 16, y, size: 10.5, font: reg, color: C.ink }); y -= 15; }
    y -= 2;
  };

  newPage(true);

  // key facts strip
  const facts: [string, string][] = [
    ["Duration", course.lengths.map((l) => lengthLabel[l]).join(" or ") || "On request"],
    ["Format", "Classroom & live online"],
    ["Starts", "Every Monday (Mon-Fri)"],
    ["Award", "Certificate of completion"],
  ];
  page.drawRectangle({ x: M, y: y - 44, width: W, height: 50, color: C.surface });
  facts.forEach(([k, v], i) => {
    const x = M + 14 + i * (W / 4);
    page.drawText(k.toUpperCase(), { x, y: y - 8, size: 7.5, font: bold, color: C.muted });
    for (const [j, l] of wrap(v, bold, 9.5, W / 4 - 18).slice(0, 2).entries()) page.drawText(l, { x, y: y - 22 - j * 11, size: 9.5, font: bold, color: C.ink });
  });
  y -= 70;

  heading("Course overview");
  para(course.description);

  const objectives = (course.objectives ?? "").split(/\r?\n/).map((s) => s.trim()).filter(Boolean);
  if (objectives.length) { heading("What you will learn"); objectives.forEach(bullet); y -= 6; }
  if (course.targetAudience) { heading("Who should attend"); para(course.targetAudience); }
  if (course.methodology) { heading("How it is delivered"); para(course.methodology); }

  if (course.outline.length) {
    heading("Course outline", 90);
    for (const m of course.outline) {
      ensure(40);
      page.drawText(clean(m.title, bold), { x: M, y, size: 11, font: bold, color: C.brand }); y -= 16;
      if (m.body) para(m.body, 10, C.muted, 0);
    }
    y -= 4;
  }

  // schedules + fees
  heading("Upcoming dates & fees", 150);
  const lengths: Length[] = course.lengths.length ? course.lengths : [];
  if (!lengths.length || !course.schedules.length) para("Dates are being confirmed. Contact us for the next available start.");
  for (const l of lengths) {
    const rows = course.schedules.filter((s) => s.length === l).slice(0, 8);
    if (!rows.length) continue;
    ensure(30 + rows.length * 20);
    page.drawText(clean(`${lengthLabel[l]} programme  -  ${priceText(course.prices[l])}`, bold), { x: M, y, size: 10.5, font: bold, color: C.ink }); y -= 19;
    rows.forEach((s, i) => {
      ensure(20);
      if (i % 2 === 0) page.drawRectangle({ x: M, y: y - 6, width: W, height: 19, color: C.surface });
      page.drawText(clean(formatRange(s.startDate, s.endDate), reg), { x: M + 10, y, size: 10, font: reg, color: C.ink });
      page.drawText("Monday - Friday", { x: M + 250, y, size: 9, font: reg, color: C.muted });
      y -= 19;
    });
    y -= 10;
  }
  para(`Brochure generated ${formatRange(now.toISOString().slice(0, 10), now.toISOString().slice(0, 10)).split(" – ")[1]}. Dates and fees are updated weekly; see the website for the latest.`, 8.5, C.muted);

  // call to action
  ensure(95);
  y -= 6;
  page.drawRectangle({ x: M, y: y - 74, width: W, height: 80, color: C.dark });
  page.drawText("Ready to register?", { x: M + 18, y: y - 20, size: 14, font: bold, color: C.white });
  page.drawText(clean(`Book online: ${abs(`/courses/${course.slug}`)}`, reg), { x: M + 18, y: y - 40, size: 10, font: reg, color: rgb(0.66, 0.89, 0.78) });
  page.drawText(clean(`Email ${site.email}   |   Call ${site.phone}`, reg), { x: M + 18, y: y - 56, size: 10, font: reg, color: C.white });

  return doc.save();
}
