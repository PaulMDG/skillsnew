import { createHmac, timingSafeEqual } from "node:crypto";

const DAYS = 86_400;
const secret = () => {
  const s = process.env.BROCHURE_LINK_SECRET ?? process.env.AUTH_SECRET;
  if (s && s.length >= 32) return s;
  if (process.env.NODE_ENV !== "production") return "dev-only-brochure-secret-0000000000";
  throw new Error("BROCHURE_LINK_SECRET (or AUTH_SECRET) must be set");
};

const mac = (slug: string, leadId: string, exp: number) =>
  createHmac("sha256", secret()).update(`${slug}.${leadId}.${exp}`).digest("base64url");

/** Signed, expiring brochure URL (path + query). Only people who submitted the form (or got the email) have one. */
export function brochurePath(slug: string, leadId: string, ttlDays = 30, now = Date.now()): string {
  const exp = Math.floor(now / 1000) + ttlDays * DAYS;
  return `/brochure/${encodeURIComponent(slug)}?lead=${encodeURIComponent(leadId)}&exp=${exp}&sig=${mac(slug, leadId, exp)}`;
}

export function verifyBrochureLink(slug: string, p: { lead?: string | null; exp?: string | null; sig?: string | null }, now = Date.now()): string | null {
  if (!p.lead || !p.exp || !p.sig) return null;
  const exp = Number(p.exp);
  if (!Number.isInteger(exp) || exp < Math.floor(now / 1000)) return null;
  const a = Buffer.from(mac(slug, p.lead, exp)), b = Buffer.from(p.sig);
  return a.length === b.length && timingSafeEqual(a, b) ? p.lead : null;
}
