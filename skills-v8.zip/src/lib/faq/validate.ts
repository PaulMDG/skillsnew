export interface RawFaq { question: string; answer: string }
export interface Rejection { question: string; reason: string }

const MONTHS = "jan(?:uary)?|feb(?:ruary)?|mar(?:ch)?|apr(?:il)?|may|jun(?:e)?|jul(?:y)?|aug(?:ust)?|sep(?:t(?:ember)?)?|oct(?:ober)?|nov(?:ember)?|dec(?:ember)?";

/** Things an FAQ must never state: they change, and a wrong price/date/claim on a public page is worse than no FAQ. */
const FORBIDDEN: [RegExp, string][] = [
  [/(?:\b(?:kes|ksh|ksh\.|usd|eur|gbp|us\$)\b|[$€£])\s?\d|\d[\d,.]*\s?(?:kes|ksh|usd|eur|gbp|dollars?|shillings?|euros?)\b/i, "mentions a price"],
  [/\b20\d{2}\b/, "mentions a year"],
  [new RegExp(`\\b(?:${MONTHS})\\.?\\s+\\d{1,2}\\b|\\b\\d{1,2}(?:st|nd|rd|th)?\\s+(?:${MONTHS})\\b`, "i"), "mentions a specific date"],
  [/https?:\/\/|www\./i, "contains a link"],
  [/[^\s@]+@[^\s@]+\.[a-z]{2,}/i, "contains an email address"],
  [/\+?\d[\d\s().-]{8,}\d/, "contains a phone number"],
  [/<[^>]+>|&[a-z]+;/i, "contains markup"],
  [/\b(?:accredit\w*|guarantee\w*|certified by|approved by|endorsed by|recognised by|recognized by|ranked|best in|#1|number one)\b/i, "makes a claim we cannot verify"],
];

const norm = (q: string) => q.toLowerCase().replace(/[^a-z0-9 ]+/g, " ").replace(/\s+/g, " ").trim();

export function validateFaqs(raw: RawFaq[], existingQuestions: string[] = [], max = 8): { valid: RawFaq[]; rejected: Rejection[] } {
  const seen = new Set(existingQuestions.map(norm));
  const valid: RawFaq[] = [], rejected: Rejection[] = [];
  for (const f of raw) {
    const question = (f?.question ?? "").replace(/\s+/g, " ").trim();
    const answer = (f?.answer ?? "").replace(/[ \t]+/g, " ").replace(/\n{3,}/g, "\n\n").trim();
    const reject = (reason: string) => rejected.push({ question: question.slice(0, 120) || "(empty)", reason });
    if (question.length < 15 || question.length > 200) { reject("question length"); continue; }
    if (!question.endsWith("?")) { reject("question is not phrased as a question"); continue; }
    if (answer.length < 60) { reject("answer too short"); continue; }
    if (answer.length > 1000) { reject("answer too long"); continue; }
    const bad = FORBIDDEN.find(([re]) => re.test(question) || re.test(answer));
    if (bad) { reject(bad[1]); continue; }
    const key = norm(question);
    if (seen.has(key)) { reject("duplicate question"); continue; }
    if (valid.length >= max) { reject("over the limit"); continue; }
    seen.add(key);
    valid.push({ question, answer });
  }
  return { valid, rejected };
}
