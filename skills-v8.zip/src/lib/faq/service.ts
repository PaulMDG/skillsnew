import type { Repo } from "../repo";
import type { FaqCandidate } from "../types";
import { courseContentHash } from "./hash";
import type { Llm } from "./openai";
import { buildMessages } from "./prompt";
import { validateFaqs } from "./validate";

export const MIN_USABLE = 3;       // fewer than this after validation = the run failed, nothing is stored
export const MAX_RETRIES_PER_DAY = 3;

export type FaqRepo = Pick<Repo, "getFaqContext" | "listFaqCandidates" | "saveGeneratedFaqs" | "logFaqRun">;
export interface FaqDeps { repo: FaqRepo; llm: Llm; /** true = skip the review queue (FAQ_AUTO_PUBLISH=1) */ publish?: boolean }
export type GenResult = { status: "generated"; count: number; rejected: number } | { status: "skipped" | "failed"; reason: string };

export function createFaqService({ repo, llm, publish = false }: FaqDeps) {
  async function generateForCourse(courseId: string, opts: { force?: boolean } = {}): Promise<GenResult> {
    const ctx = await repo.getFaqContext(courseId);
    if (!ctx) return { status: "skipped", reason: "course not found" };
    const hash = courseContentHash(ctx.course);
    if (!opts.force && ctx.faqSourceHash === hash) return { status: "skipped", reason: "course text unchanged since the last generation" };

    const t0 = Date.now();
    try {
      const out = await llm(buildMessages({ course: ctx.course, categoryName: ctx.categoryName, existingQuestions: ctx.existingQuestions }));
      const { valid, rejected } = validateFaqs(out.faqs, ctx.existingQuestions);
      const base = { courseId, model: out.model, promptTokens: out.promptTokens, completionTokens: out.completionTokens, durationMs: Date.now() - t0 };
      if (valid.length < MIN_USABLE) {
        const why = `only ${valid.length} usable FAQs; rejected: ${rejected.map((r) => r.reason).join(", ") || "none"}`;
        await repo.logFaqRun({ ...base, status: "FAILED", error: why });
        return { status: "failed", reason: why };
      }
      await repo.saveGeneratedFaqs({ courseId, hash, faqs: valid, model: out.model, publish });
      await repo.logFaqRun({ ...base, status: "SUCCESS", error: rejected.length ? `${rejected.length} rejected: ${rejected.map((r) => r.reason).join(", ")}` : undefined });
      return { status: "generated", count: valid.length, rejected: rejected.length };
    } catch (e) {
      const msg = e instanceof Error ? e.message : String(e);
      await repo.logFaqRun({ courseId, status: "FAILED", durationMs: Date.now() - t0, error: msg });
      return { status: "failed", reason: msg };
    }
  }

  /** Published courses whose text is new or has changed since their FAQs were written (and that are not failing repeatedly). */
  async function needing(): Promise<FaqCandidate[]> {
    return (await repo.listFaqCandidates()).filter((c) =>
      c.recentFailures < MAX_RETRIES_PER_DAY && (c.faqSourceHash == null || (c.contentHash != null && c.contentHash !== c.faqSourceHash)));
  }

  /** Works through courses that need FAQs, within a count and a time budget (serverless functions have time limits). */
  async function runBatch({ limit = 5, budgetMs = 50_000 }: { limit?: number; budgetMs?: number } = {}) {
    const todo = await needing();
    const t0 = Date.now();
    const res = { needing: todo.length, attempted: 0, generated: 0, failed: 0, skipped: 0 };
    for (const c of todo.slice(0, limit)) {
      if (Date.now() - t0 > budgetMs) break;
      res.attempted++;
      const r = await generateForCourse(c.id);
      if (r.status === "generated") res.generated++; else if (r.status === "failed") res.failed++; else res.skipped++;
    }
    return res;
  }

  return { generateForCourse, needing, runBatch };
}
export type FaqService = ReturnType<typeof createFaqService>;

let cached: FaqService | undefined;
export async function faqService(): Promise<FaqService> {
  if (cached) return cached;
  const [{ getRepo }, { openAiLlm }] = await Promise.all([import("../repo"), import("./openai")]);
  cached = createFaqService({ repo: await getRepo(), llm: openAiLlm(), publish: process.env.FAQ_AUTO_PUBLISH === "1" });
  return cached;
}
