import { FAQ_SCHEMA } from "./prompt";
import type { RawFaq } from "./validate";

export interface LlmResult { faqs: RawFaq[]; model: string; promptTokens?: number; completionTokens?: number }
export type Llm = (m: { system: string; user: string }) => Promise<LlmResult>;

export const openAiConfigured = () => !!process.env.OPENAI_API_KEY;
const wait = (ms: number) => new Promise((r) => setTimeout(r, ms));

/** OpenAI Chat Completions with Structured Outputs (strict JSON schema). No SDK: one fetch. */
export function openAiLlm(): Llm {
  return async ({ system, user }) => {
    const key = process.env.OPENAI_API_KEY;
    if (!key) throw new Error("OPENAI_API_KEY is not set");
    const base = (process.env.OPENAI_BASE_URL ?? "https://api.openai.com/v1").replace(/\/$/, "");
    const model = process.env.OPENAI_MODEL ?? "gpt-4o-mini";
    const body = JSON.stringify({
      model, max_completion_tokens: 2000,
      messages: [{ role: "system", content: system }, { role: "user", content: user }],
      response_format: { type: "json_schema", json_schema: { name: "course_faqs", strict: true, schema: FAQ_SCHEMA } },
    });

    let res: Response | undefined;
    for (let attempt = 0; attempt < 2; attempt++) {
      res = await fetch(`${base}/chat/completions`, { method: "POST", headers: { Authorization: `Bearer ${key}`, "Content-Type": "application/json" }, body, signal: AbortSignal.timeout(45_000) });
      if (res.ok || ![429, 500, 502, 503, 504].includes(res.status)) break;
      await wait(Math.min(Number(res.headers.get("retry-after")) * 1000 || 2000, 8000)); // one polite retry
    }
    const json = (await res!.json().catch(() => ({}))) as {
      error?: { message?: string }; model?: string; usage?: { prompt_tokens?: number; completion_tokens?: number };
      choices?: { message?: { content?: string | null; refusal?: string | null } }[];
    };
    if (!res!.ok) throw new Error(`OpenAI ${res!.status}: ${json.error?.message ?? "request failed"}`);
    const msg = json.choices?.[0]?.message;
    if (msg?.refusal) throw new Error(`OpenAI refused: ${msg.refusal.slice(0, 200)}`);
    let parsed: { faqs?: RawFaq[] };
    try { parsed = JSON.parse(msg?.content ?? ""); } catch { throw new Error("OpenAI returned invalid JSON"); }
    if (!Array.isArray(parsed.faqs)) throw new Error("OpenAI response had no faqs array");
    return { faqs: parsed.faqs, model: json.model ?? model, promptTokens: json.usage?.prompt_tokens, completionTokens: json.usage?.completion_tokens };
  };
}
