import { createHash } from "node:crypto";

export interface HashableCourse {
  name: string; summary?: string | null; description: string; objectives?: string | null; targetAudience?: string | null; methodology?: string | null;
  outline: { title: string; body?: string | null }[]; lengths: string[]; deliveryModes: string[];
}

/** Fingerprint of everything an FAQ could be about. Prices, dates, SEO fields and status are deliberately excluded. */
export function courseContentHash(c: HashableCourse): string {
  const canon = JSON.stringify([
    c.name, c.summary ?? "", c.description, c.objectives ?? "", c.targetAudience ?? "", c.methodology ?? "",
    c.outline.map((o) => [o.title, o.body ?? ""]), [...c.lengths].sort(), [...c.deliveryModes].sort(),
  ]);
  return createHash("sha256").update(canon).digest("hex").slice(0, 32);
}
