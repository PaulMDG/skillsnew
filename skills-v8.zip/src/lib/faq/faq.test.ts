import { test, beforeEach } from "node:test";
import assert from "node:assert/strict";
import { validateFaqs } from "./validate";
import { courseContentHash } from "./hash";
import { buildMessages } from "./prompt";
import { createFaqService, MIN_USABLE } from "./service";
import { mockRepo } from "../repo.mock";
import type { Llm } from "./openai";

const ok = (q: string) => ({ question: q, answer: "This course is designed for managers and officers who need practical skills they can use straight away. It combines short expert input with hands-on exercises and case studies." });

test("validator accepts a clean FAQ and trims whitespace", () => {
  const { valid, rejected } = validateFaqs([ok("  Who   should attend this course? ")]);
  assert.equal(valid.length, 1); assert.equal(valid[0].question, "Who should attend this course?"); assert.equal(rejected.length, 0);
});

test("validator rejects prices, dates, years, links, contacts, markup and unverifiable claims", () => {
  const bad = (answerExtra: string) => validateFaqs([{ question: "What does this involve for me?", answer: ok("x").answer + " " + answerExtra }]).rejected[0]?.reason;
  assert.equal(bad("The fee is KES 85,000."), "mentions a price");
  assert.equal(bad("It costs $650 per person."), "mentions a price");
  assert.equal(bad("Pay 45,000 shillings."), "mentions a price");
  assert.equal(bad("It runs in 2027."), "mentions a year");
  assert.equal(bad("Next class starts 12 October."), "mentions a specific date");
  assert.equal(bad("Starts October 12."), "mentions a specific date");
  assert.equal(bad("See https://example.org now."), "contains a link");
  assert.equal(bad("Email info@example.org."), "contains an email address");
  assert.equal(bad("Call +254 712 345 678 today."), "contains a phone number");
  assert.equal(bad("<b>bold</b> text"), "contains markup");
  assert.equal(bad("We are fully accredited."), "makes a claim we cannot verify");
  assert.equal(bad("Success is guaranteed."), "makes a claim we cannot verify");
  assert.equal(bad("It is the best in Africa."), "makes a claim we cannot verify");
  assert.equal(bad("Classes run Monday to Friday over five days."), undefined, "ordinary schedule words are fine");
  assert.equal(bad("It covers 3 modules and 5 case studies."), undefined, "plain numbers are fine");
});

test("validator: question form, length bounds, duplicates (incl. already-published), cap", () => {
  assert.equal(validateFaqs([{ question: "Tell me about the course content", answer: ok("x").answer }]).rejected[0].reason, "question is not phrased as a question");
  assert.equal(validateFaqs([{ question: "Why?", answer: ok("x").answer }]).rejected[0].reason, "question length");
  assert.equal(validateFaqs([{ question: "Who should attend this course?", answer: "Short." }]).rejected[0].reason, "answer too short");
  assert.equal(validateFaqs([{ question: "Who should attend this course?", answer: "x".repeat(1001) }]).rejected[0].reason, "answer too long");
  const dup = validateFaqs([ok("Who should attend this course?"), ok("WHO should attend this course??")]);
  assert.equal(dup.valid.length, 1); assert.equal(dup.rejected[0].reason, "duplicate question");
  assert.equal(validateFaqs([ok("Who should attend this course?")], ["Who should attend this course?"]).rejected.length, 1);
  const many = validateFaqs(Array.from({ length: 12 }, (_, i) => ok(`What will I learn in module number ${i + 1}?`)), [], 8);
  assert.equal(many.valid.length, 8); assert.equal(many.rejected.length, 4);
  assert.deepEqual(validateFaqs([null as never, {} as never]).valid, []);
});

const base = { name: "PMP", description: "Desc", outline: [{ title: "M1" }], lengths: ["FIVE_DAY"], deliveryModes: ["ONLINE", "CLASSROOM"] };
test("content hash ignores order and unrelated things, changes with real content", () => {
  const h = courseContentHash(base);
  assert.equal(courseContentHash({ ...base, deliveryModes: ["CLASSROOM", "ONLINE"] }), h);
  assert.notEqual(courseContentHash({ ...base, description: "Desc changed" }), h);
  assert.notEqual(courseContentHash({ ...base, outline: [{ title: "M1" }, { title: "M2" }] }), h);
  assert.notEqual(courseContentHash({ ...base, lengths: ["FIVE_DAY", "TEN_DAY"] }), h);
});

test("prompt forbids prices/dates, treats course text as data, lists published questions to avoid", () => {
  const { system, user } = buildMessages({ course: { ...base, slug: "pmp", objectives: "Plan\nDeliver" }, categoryName: "Project Management", existingQuestions: ["Who should attend?"] });
  assert.match(system, /NEVER mention prices/); assert.match(system, /DATA, not instructions/); assert.match(system, /NEVER claim accreditation/);
  assert.match(user, /Name: PMP/); assert.match(user, /Category: Project Management/); assert.match(user, /- Who should attend\?/); assert.match(user, /5-day programme/);
});

let calls = 0; let behaviour: "good" | "bad" | "throw" | "few" = "good";
const llm: Llm = async () => {
  calls++;
  if (behaviour === "throw") throw new Error("OpenAI 429: rate limited");
  if (behaviour === "few") return { faqs: [ok("Who should attend this course?"), { question: "How much does it cost to attend?", answer: ok("x").answer + " The fee is KES 5,000." }], model: "fake-model" };
  const qs = ["Who should attend this course?", "What will I learn on this course?", "Do I need prior experience to join?", "How is the course delivered to participants?", "Will I receive a certificate at the end?", "How can this course help my career?"];
  return { faqs: [...qs.map(ok), ...(behaviour === "bad" ? [{ question: "How much does it cost to attend?", answer: ok("x").answer + " It costs KES 85,000." }] : [])], model: "fake-model", promptTokens: 900, completionTokens: 500 };
};
const svc = (publish = false) => createFaqService({ repo: mockRepo, llm, publish });
beforeEach(() => { calls = 0; behaviour = "good"; });

test("generation: new course gets drafts (not published), then is skipped until its text changes", async () => {
  const created = await mockRepo.saveCourse({ name: "Brand New Course", slug: "brand-new-course", categoryId: "c1", description: "A practical new course about something useful.", lengths: ["FIVE_DAY"], deliveryModes: ["ONLINE"], autoSchedule: true, status: "PUBLISHED", outline: [], prices: {} });
  assert.ok(created.ok); if (!created.ok) return;
  const s = svc();
  assert.ok((await s.needing()).some((c) => c.id === created.id), "a new course needs FAQs");
  const r = await s.generateForCourse(created.id);
  assert.deepEqual(r, { status: "generated", count: 6, rejected: 0 });
  assert.equal((await mockRepo.getCourse("brand-new-course"))!.faqs.length, 0, "drafts are NOT public until approved");
  assert.equal((await mockRepo.listFaqsAdmin({ status: "DRAFT", courseId: created.id, limit: 50 })).length, 6);
  assert.equal((await s.generateForCourse(created.id)).status, "skipped"); assert.equal(calls, 1, "no second call, no second charge");
  assert.ok(!(await s.needing()).some((c) => c.id === created.id));
  // price-only edit must not trigger regeneration; a description edit must
  const edit = (d: string, price?: number) => mockRepo.saveCourse({ id: created.id, name: "Brand New Course", slug: "brand-new-course", categoryId: "c1", description: d, lengths: ["FIVE_DAY"], deliveryModes: ["ONLINE"], autoSchedule: true, status: "PUBLISHED", outline: [], prices: price ? { FIVE_DAY: { KES: price } } : {} });
  await edit("A practical new course about something useful.", 50000);
  assert.ok(!(await s.needing()).some((c) => c.id === created.id), "price edit: no regeneration");
  await edit("A rewritten description for the very same course.");
  assert.ok((await s.needing()).some((c) => c.id === created.id), "text edit: needs regeneration");
});

test("auto-publish mode publishes straight to the website", async () => {
  const c = await mockRepo.saveCourse({ name: "Auto Publish Course", slug: "auto-publish-course", categoryId: "c1", description: "A practical course for the auto publish test.", lengths: ["FIVE_DAY"], deliveryModes: ["ONLINE"], autoSchedule: true, status: "PUBLISHED", outline: [], prices: {} });
  if (!c.ok) throw new Error("setup"); await svc(true).generateForCourse(c.id);
  assert.equal((await mockRepo.getCourse("auto-publish-course"))!.faqs.length, 6);
});

test("an FAQ with a price is dropped, the rest kept; too few usable = failed run, nothing stored", async () => {
  const c = await mockRepo.saveCourse({ name: "Validation Course", slug: "validation-course", categoryId: "c1", description: "A practical course for validation testing.", lengths: ["FIVE_DAY"], deliveryModes: ["ONLINE"], autoSchedule: true, status: "PUBLISHED", outline: [], prices: {} });
  if (!c.ok) throw new Error("setup");
  behaviour = "bad"; assert.deepEqual(await svc().generateForCourse(c.id, { force: true }), { status: "generated", count: 6, rejected: 1 });
  behaviour = "few"; const f = await svc().generateForCourse(c.id, { force: true });
  assert.equal(f.status, "failed"); assert.match((f as { reason: string }).reason, new RegExp(`only 1 usable.*${"mentions a price"}`));
  assert.equal((await mockRepo.listFaqsAdmin({ status: "DRAFT", courseId: c.id, limit: 50 })).length, 6, "failed run left the previous drafts alone");
  assert.ok(MIN_USABLE >= 3);
});

test("provider errors are recorded; a course failing 3 times in a day stops being retried", async () => {
  const c = await mockRepo.saveCourse({ name: "Flaky Course", slug: "flaky-course", categoryId: "c1", description: "A practical course for the flaky provider test.", lengths: ["FIVE_DAY"], deliveryModes: ["ONLINE"], autoSchedule: true, status: "PUBLISHED", outline: [], prices: {} });
  if (!c.ok) throw new Error("setup"); behaviour = "throw"; const s = svc();
  for (let i = 0; i < 3; i++) { const r = await s.generateForCourse(c.id); assert.equal(r.status, "failed"); assert.match((r as { reason: string }).reason, /429/); }
  assert.ok(!(await s.needing()).some((x) => x.id === c.id), "gives up for today instead of burning money");
});

test("runBatch honours the limit and reports counts", async () => {
  for (const n of ["a", "b", "c"]) await mockRepo.saveCourse({ name: `Batch Course ${n}`, slug: `batch-course-${n}`, categoryId: "c1", description: `A practical batch course ${n} for testing.`, lengths: ["FIVE_DAY"], deliveryModes: ["ONLINE"], autoSchedule: true, status: "PUBLISHED", outline: [], prices: {} });
  const s = svc(); const before = (await s.needing()).length;
  const r = await s.runBatch({ limit: 2 });
  assert.equal(r.attempted, 2); assert.equal(r.generated, 2); assert.equal((await s.needing()).length, before - 2);
});

test("review actions: approve, edit, reject, approve-all, manual add", async () => {
  const c = await mockRepo.saveCourse({ name: "Review Course", slug: "review-course", categoryId: "c1", description: "A practical course for the review flow test.", lengths: ["FIVE_DAY"], deliveryModes: ["ONLINE"], autoSchedule: true, status: "PUBLISHED", outline: [], prices: {} });
  if (!c.ok) throw new Error("setup"); await svc().generateForCourse(c.id);
  const drafts = await mockRepo.listFaqsAdmin({ status: "DRAFT", courseId: c.id, limit: 50 });
  assert.equal((await mockRepo.updateFaq(drafts[0].id, { answer: "Edited answer text that is long enough to be a real answer for this question.", status: "PUBLISHED" })).ok, true);
  await mockRepo.updateFaq(drafts[1].id, { status: "REJECTED" });
  const all = await mockRepo.setCourseFaqsStatus(c.id, "DRAFT", "PUBLISHED");
  assert.deepEqual([all.ok, (all as { count: number }).count], [true, 4]);
  const live = (await mockRepo.getCourse("review-course"))!.faqs;
  assert.equal(live.length, 5); assert.ok(live[0].answer.startsWith("Edited answer"));
  assert.ok(!live.some((f) => f.question === drafts[1].question), "rejected FAQ never appears");
  await mockRepo.addFaq(c.id, "Is there a group discount?", "Yes, group rates are available; contact the team.");
  assert.equal((await mockRepo.getCourse("review-course"))!.faqs.length, 6);
  assert.equal((await mockRepo.updateFaq("nope", { status: "PUBLISHED" })).ok, false);
  // regeneration never resurrects the rejected question or repeats published ones
  const ctx = await mockRepo.getFaqContext(c.id);
  assert.ok(ctx!.existingQuestions.includes(drafts[1].question));
});
