import Link from "next/link";

export function Pagination({ basePath, page, totalPages }: { basePath: string; page: number; totalPages: number }) {
  if (totalPages <= 1) return null;
  const href = (n: number) => (n === 1 ? basePath : `${basePath}?page=${n}`);
  const pages = Array.from({ length: totalPages }, (_, i) => i + 1).filter((n) => n === 1 || n === totalPages || Math.abs(n - page) <= 1);
  const cls = "rounded-lg border border-line px-3.5 py-2 text-sm font-semibold hover:border-brand-500";
  return (
    <nav aria-label="Pagination" className="mt-10 flex flex-wrap items-center justify-center gap-2">
      {page > 1 && <Link href={href(page - 1)} rel="prev" className={cls}>← Newer</Link>}
      {pages.map((n, i) => (
        <span key={n} className="flex items-center gap-2">
          {i > 0 && n - pages[i - 1] > 1 && <span className="text-muted">…</span>}
          <Link href={href(n)} aria-current={n === page ? "page" : undefined} className={n === page ? "rounded-lg bg-brand-600 px-3.5 py-2 text-sm font-semibold text-white" : cls}>{n}</Link>
        </span>
      ))}
      {page < totalPages && <Link href={href(page + 1)} rel="next" className={cls}>Older →</Link>}
    </nav>
  );
}
