"use client";

import Link from "next/link";
import { useMemo, useState } from "react";
import { CalendarDays } from "lucide-react";
import type { Length, ScheduleDTO, CourseDetail } from "@/lib/types";
import { formatMonth, formatRange, lengthLabel, priceText } from "@/lib/format";

export function ScheduleTable({ slug, lengths, schedules, prices }: {
  slug: string; lengths: Length[]; schedules: ScheduleDTO[]; prices: CourseDetail["prices"];
}) {
  const [length, setLength] = useState<Length>(lengths[0]);
  const [showAll, setShowAll] = useState(false);
  const rows = useMemo(() => schedules.filter((s) => s.length === length), [schedules, length]);
  const visible = showAll ? rows : rows.slice(0, 8);
  let lastMonth = "";

  if (!lengths.length || !schedules.length) {
    return <p className="rounded-xl border border-dashed border-line p-6 text-sm text-muted">Dates for this course are being finalised. Please contact us and we&apos;ll confirm the next available start.</p>;
  }

  return (
    <div>
      {lengths.length > 1 && (
        <div role="tablist" aria-label="Course length" className="mb-4 inline-flex rounded-lg bg-surface p-1">
          {lengths.map((l) => (
            <button key={l} role="tab" aria-selected={l === length} onClick={() => { setLength(l); setShowAll(false); }}
              className={`rounded-md px-4 py-1.5 text-sm font-semibold transition ${l === length ? "bg-white text-brand-800 shadow-sm" : "text-muted hover:text-ink"}`}>
              {lengthLabel[l]}
            </button>
          ))}
        </div>
      )}
      <div className="overflow-hidden rounded-xl border border-line">
        <ul className="divide-y divide-line">
          {visible.map((s) => {
            const m = formatMonth(s.startDate);
            const header = m !== lastMonth ? m : null;
            lastMonth = m;
            return (
              <li key={s.id}>
                {header && <div className="bg-surface px-4 py-2 text-xs font-semibold uppercase tracking-wide text-muted">{header}</div>}
                <div className="flex flex-wrap items-center justify-between gap-3 px-4 py-3.5">
                  <div className="flex items-center gap-3">
                    <CalendarDays className="h-5 w-5 text-brand-600" aria-hidden="true" />
                    <div>
                      <div className="text-sm font-semibold">{formatRange(s.startDate, s.endDate)}</div>
                      <div className="text-xs text-muted">Mon – Fri · {lengthLabel[s.length]} · {priceText(prices[s.length])}</div>
                    </div>
                  </div>
                  <Link href={`/register?course=${slug}&schedule=${encodeURIComponent(s.id)}`} className="rounded-lg bg-brand-600 px-4 py-2 text-sm font-semibold text-white transition hover:bg-brand-700">Register</Link>
                </div>
              </li>
            );
          })}
        </ul>
      </div>
      {rows.length > 8 && (
        <button onClick={() => setShowAll((v) => !v)} className="mt-3 text-sm font-semibold text-brand-700 hover:underline">
          {showAll ? "Show fewer dates" : `Show all ${rows.length} dates`}
        </button>
      )}
    </div>
  );
}
