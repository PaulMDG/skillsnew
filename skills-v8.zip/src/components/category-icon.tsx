import { BarChart3, BookOpen, Briefcase, Cpu, HeartPulse, Landmark, Truck, Users, type LucideIcon } from "lucide-react";

const icons: Record<string, LucideIcon> = {
  briefcase: Briefcase, chart: BarChart3, landmark: Landmark, cpu: Cpu, users: Users, truck: Truck, health: HeartPulse,
};

export function CategoryIcon({ name, className }: { name?: string | null; className?: string }) {
  const Icon = (name && icons[name]) || BookOpen;
  return <Icon className={className} aria-hidden="true" />;
}
