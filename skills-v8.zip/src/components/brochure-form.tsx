"use client";

import { useActionState, useEffect } from "react";
import { Download } from "lucide-react";
import { requestBrochure } from "@/app/actions";
import type { FormState } from "@/lib/validation";
import { Field, FormMessage, Honeypot, inputCls, useKeepValues } from "./form-bits";

export function BrochureForm({ courseSlug }: { courseSlug: string }) {
  const [state, action, pending] = useActionState<FormState, FormData>(requestBrochure, { status: "idle" });
  const onSubmit = useKeepValues(action);
  const e = state.fieldErrors ?? {};

  // Start the download automatically; the button below is the fallback if the browser blocks it
  useEffect(() => { if (state.downloadUrl) window.location.assign(state.downloadUrl); }, [state.downloadUrl]);

  if (state.status === "success") {
    return (
      <div className="space-y-3">
        <FormMessage state={state} />
        {state.downloadUrl && (
          <a href={state.downloadUrl} className="flex w-full items-center justify-center gap-2 rounded-lg bg-brand-600 px-4 py-2.5 text-sm font-semibold text-white transition hover:bg-brand-700">
            <Download className="h-4 w-4" />Download brochure (PDF)
          </a>
        )}
      </div>
    );
  }

  return (
    <form onSubmit={onSubmit} className="relative space-y-3" noValidate>
      <input type="hidden" name="courseSlug" value={courseSlug} />
      <Honeypot />
      <Field label="Full name" name="fullName" errors={e.fullName}><input id="fullName" name="fullName" autoComplete="name" required className={inputCls} /></Field>
      <Field label="Email" name="email" errors={e.email}><input id="email" name="email" type="email" autoComplete="email" required className={inputCls} /></Field>
      <Field label="Phone (optional)" name="phone" errors={e.phone}><input id="phone" name="phone" type="tel" autoComplete="tel" className={inputCls} /></Field>
      <FormMessage state={state} />
      <button disabled={pending} className="flex w-full items-center justify-center gap-2 rounded-lg border border-brand-600 px-4 py-2.5 text-sm font-semibold text-brand-700 transition hover:bg-brand-50 disabled:opacity-60">
        <Download className="h-4 w-4" />{pending ? "Sending…" : "Get the brochure"}
      </button>
    </form>
  );
}
