"use client";

import { useActionState, useState } from "react";
import { registerForCourse } from "@/app/actions";
import type { FormState } from "@/lib/validation";
import type { CenterDTO, ScheduleDTO } from "@/lib/types";
import { formatRange, lengthLabel } from "@/lib/format";
import { Field, FormMessage, Honeypot, inputCls, useKeepValues } from "./form-bits";

export function RegisterForm({ courseSlug, schedules, selectedId, centers }: {
  courseSlug: string; schedules: ScheduleDTO[]; selectedId?: string; centers: CenterDTO[];
}) {
  const [state, action, pending] = useActionState<FormState, FormData>(registerForCourse, { status: "idle" });
  const [mode, setMode] = useState<"CLASSROOM" | "ONLINE">("CLASSROOM");
  const onSubmit = useKeepValues(action);
  const e = state.fieldErrors ?? {};

  if (state.status === "success") {
    return <div className="rounded-2xl border border-brand-200 bg-brand-50 p-8 text-center"><h2 className="text-xl font-bold text-brand-900">You&apos;re registered</h2><p className="mt-2 text-sm text-brand-800">{state.message}</p></div>;
  }

  return (
    <form onSubmit={onSubmit} className="relative space-y-5" noValidate>
      <input type="hidden" name="courseSlug" value={courseSlug} />
      <Honeypot />
      <Field label="Start date" name="scheduleId" errors={e.scheduleId}>
        <select id="scheduleId" name="scheduleId" defaultValue={selectedId} required className={inputCls}>
          <option value="" disabled={!!selectedId}>Choose a start date…</option>
          {schedules.map((s) => <option key={s.id} value={s.id}>{formatRange(s.startDate, s.endDate)} · {lengthLabel[s.length]}</option>)}
        </select>
      </Field>
      <div className="grid gap-4 sm:grid-cols-2">
        <Field label="First name" name="firstName" errors={e.firstName}><input id="firstName" name="firstName" autoComplete="given-name" required className={inputCls} /></Field>
        <Field label="Last name" name="lastName" errors={e.lastName}><input id="lastName" name="lastName" autoComplete="family-name" required className={inputCls} /></Field>
        <Field label="Email" name="email" errors={e.email}><input id="email" name="email" type="email" autoComplete="email" required className={inputCls} /></Field>
        <Field label="Phone" name="phone" errors={e.phone}><input id="phone" name="phone" type="tel" autoComplete="tel" required className={inputCls} /></Field>
        <Field label="Organisation (optional)" name="organisation" errors={e.organisation}><input id="organisation" name="organisation" autoComplete="organization" className={inputCls} /></Field>
        <Field label="Number of participants" name="participants" errors={e.participants}><input id="participants" name="participants" type="number" min={1} max={200} defaultValue={1} className={inputCls} /></Field>
      </div>
      <fieldset>
        <legend className="mb-2 text-sm font-medium">How would you like to attend?</legend>
        <div className="flex gap-3">
          {(["CLASSROOM", "ONLINE"] as const).map((m) => (
            <label key={m} className={`flex-1 cursor-pointer rounded-lg border px-4 py-3 text-sm font-medium transition ${mode === m ? "border-brand-600 bg-brand-50 text-brand-800" : "border-line"}`}>
              <input type="radio" name="deliveryMode" value={m} checked={mode === m} onChange={() => setMode(m)} className="sr-only" />
              {m === "CLASSROOM" ? "In the classroom" : "Live online"}
            </label>
          ))}
        </div>
      </fieldset>
      {mode === "CLASSROOM" && (
        <>
          <Field label="Training centre" name="centerId" errors={e.centerId}>
            <select id="centerId" name="centerId" className={inputCls} defaultValue={centers[0]?.id}>{centers.map((c) => <option key={c.id} value={c.id}>{c.name}</option>)}</select>
          </Field>
          <div className="flex flex-wrap gap-6 text-sm">
            <label className="flex items-center gap-2"><input type="checkbox" name="needsAccommodation" className="h-4 w-4 accent-brand-600" />I need accommodation</label>
            <label className="flex items-center gap-2"><input type="checkbox" name="needsAirportPickup" className="h-4 w-4 accent-brand-600" />I need airport pickup</label>
          </div>
        </>
      )}
      <Field label="Anything we should know? (optional)" name="notes" errors={e.notes}><textarea id="notes" name="notes" rows={3} className={inputCls} /></Field>
      <FormMessage state={state} />
      <button disabled={pending} className="w-full rounded-lg bg-brand-600 px-5 py-3 text-sm font-semibold text-white shadow-sm transition hover:bg-brand-700 disabled:opacity-60">
        {pending ? "Submitting…" : "Complete registration"}
      </button>
      <p className="text-center text-xs text-muted">We&apos;ll email you a confirmation and reminders about your course. You can unsubscribe at any time.</p>
    </form>
  );
}
