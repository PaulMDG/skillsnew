"use client";

import { useActionState } from "react";
import { savePricesAction, type PriceState } from "@/app/admin/(panel)/prices/actions";
import { useKeepValues } from "@/components/form-bits";
import type { Length, PriceMap } from "@/lib/types";

const cell = "w-28 rounded-lg border border-line px-2.5 py-1.5 text-sm disabled:bg-surface disabled:text-muted/50";

export function PriceRow({ courseId, name, category, lengths, prices }: { courseId: string; name: string; category: string; lengths: Length[]; prices: Partial<Record<Length, PriceMap>> }) {
  const [state, action, pending] = useActionState<PriceState, FormData>(savePricesAction, {});
  const onSubmit = useKeepValues(action);
  const form = `pf-${courseId}`;
  const has5 = lengths.includes("FIVE_DAY"), has10 = lengths.includes("TEN_DAY");
  const inp = (n: string, off: boolean, v: number | undefined, label: string) => (
    <td className="px-3 py-3"><input form={form} name={n} disabled={off} defaultValue={v ?? ""} inputMode="decimal" aria-label={`${name} ${label}`} className={cell} /></td>
  );
  return (
    <tr>
      <td className="px-5 py-3"><div className="font-semibold">{name}</div><div className="text-xs text-muted">{category}</div></td>
      {inp("p5Kes", !has5, prices.FIVE_DAY?.KES, "5-day KES")}{inp("p5Usd", !has5, prices.FIVE_DAY?.USD, "5-day USD")}
      {inp("p10Kes", !has10, prices.TEN_DAY?.KES, "10-day KES")}{inp("p10Usd", !has10, prices.TEN_DAY?.USD, "10-day USD")}
      <td className="px-3 py-3 text-right">
        <form id={form} onSubmit={onSubmit} className="flex items-center justify-end gap-2">
          <input type="hidden" name="courseId" value={courseId} />
          {state.ok && <span role="status" className="text-xs font-semibold text-brand-700">Saved</span>}
          {state.error && <span role="alert" className="text-xs font-semibold text-red-600">{state.error}</span>}
          <button disabled={pending} className="rounded-lg border border-brand-600 px-3 py-1.5 text-xs font-semibold text-brand-700 hover:bg-brand-50 disabled:opacity-60">{pending ? "…" : "Save"}</button>
        </form>
      </td>
    </tr>
  );
}
