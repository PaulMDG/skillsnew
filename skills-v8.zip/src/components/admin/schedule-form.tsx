"use client";

import { useActionState } from "react";
import { addScheduleAction, type ScheduleFormState } from "@/app/admin/(panel)/schedules/actions";
import { inputCls, useKeepValues } from "@/components/form-bits";

export function ScheduleForm({ courses }: { courses: { id: string; name: string }[] }) {
  const [state, action, pending] = useActionState<ScheduleFormState, FormData>(addScheduleAction, {});
  const onSubmit = useKeepValues(action);
  return (
    <form onSubmit={onSubmit} className="rounded-2xl border border-line bg-white p-5">
      <h2 className="font-bold">Add a schedule</h2>
      <p className="mt-1 text-sm text-muted">Classes always run Monday to Friday. Choose the <strong>Monday</strong> the class starts; the finishing Friday is worked out for you (next week for 10-day courses).</p>
      <div className="mt-4 grid gap-3 md:grid-cols-[1fr_150px_170px_auto]">
        <select name="courseId" required aria-label="Course" defaultValue="" className={inputCls}><option value="" disabled>Choose a course…</option>{courses.map((c) => <option key={c.id} value={c.id}>{c.name}</option>)}</select>
        <select name="length" aria-label="Length" className={inputCls}><option value="FIVE_DAY">5-day</option><option value="TEN_DAY">10-day</option></select>
        <input type="date" name="startDate" required aria-label="Start date (Monday)" className={inputCls} />
        <button disabled={pending} className="rounded-lg bg-brand-600 px-5 py-2.5 text-sm font-semibold text-white hover:bg-brand-700 disabled:opacity-60">{pending ? "Adding…" : "Add schedule"}</button>
      </div>
      {state.error && <p role="alert" className="mt-3 rounded-lg bg-red-50 px-3.5 py-2.5 text-sm font-medium text-red-700">{state.error}</p>}
      {state.ok && <p role="status" className="mt-3 rounded-lg bg-brand-50 px-3.5 py-2.5 text-sm font-medium text-brand-800">Schedule added.</p>}
    </form>
  );
}
