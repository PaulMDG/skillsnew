"use client";

import { useActionState } from "react";
import { verifyCodeAction } from "@/app/admin/(auth)/actions";
import type { AuthFormState } from "@/lib/auth/types";
import { Field, inputCls } from "@/components/form-bits";

export function CodeForm({ next, submitLabel = "Verify" }: { next?: string; submitLabel?: string }) {
  const [state, action, pending] = useActionState<AuthFormState, FormData>(verifyCodeAction, {});
  return (
    <form action={action} className="space-y-4">
      <input type="hidden" name="next" value={next ?? ""} />
      <Field label="6-digit code" name="code">
        <input id="code" name="code" inputMode="numeric" autoComplete="one-time-code" pattern="[0-9 ]*" maxLength={7} required autoFocus
          className={`${inputCls} text-center font-mono text-2xl tracking-[0.4em]`} />
      </Field>
      {state.error && <p role="alert" className="rounded-lg bg-red-50 px-3.5 py-2.5 text-sm font-medium text-red-700">{state.error}</p>}
      <button disabled={pending} className="w-full rounded-lg bg-brand-600 px-5 py-3 text-sm font-semibold text-white transition hover:bg-brand-700 disabled:opacity-60">{pending ? "Verifying…" : submitLabel}</button>
    </form>
  );
}
