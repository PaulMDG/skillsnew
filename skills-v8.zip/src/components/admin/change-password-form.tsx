"use client";

import { useActionState } from "react";
import { changePasswordAction } from "@/app/admin/(panel)/account/actions";
import type { AuthFormState } from "@/lib/auth/types";
import { Field, inputCls, useKeepValues } from "@/components/form-bits";

export function ChangePasswordForm() {
  const [state, action, pending] = useActionState<AuthFormState, FormData>(changePasswordAction, {});
  const onSubmit = useKeepValues(action);
  return (
    <form onSubmit={onSubmit} className="mt-4 space-y-4">
      <Field label="Current password" name="current"><input id="current" name="current" type="password" autoComplete="current-password" required className={inputCls} /></Field>
      <Field label="New password (12+ characters)" name="next"><input id="next" name="next" type="password" autoComplete="new-password" minLength={12} required className={inputCls} /></Field>
      <Field label="Confirm new password" name="confirm"><input id="confirm" name="confirm" type="password" autoComplete="new-password" required className={inputCls} /></Field>
      {state.error && <p role="alert" className="rounded-lg bg-red-50 px-3.5 py-2.5 text-sm font-medium text-red-700">{state.error}</p>}
      {state.success && <p role="status" className="rounded-lg bg-brand-50 px-3.5 py-2.5 text-sm font-medium text-brand-800">{state.success}</p>}
      <button disabled={pending} className="rounded-lg bg-brand-600 px-5 py-2.5 text-sm font-semibold text-white hover:bg-brand-700 disabled:opacity-60">{pending ? "Saving…" : "Update password"}</button>
    </form>
  );
}
