"use client";

import { useActionState, useState } from "react";
import { saveCategoryAction } from "@/app/admin/(panel)/categories/actions";
import { ICON_LIBRARY } from "@/lib/admin-schemas";
import type { CategoryEditDTO } from "@/lib/types";
import type { FormState } from "@/lib/validation";
import { Field, FormMessage, inputCls, useKeepValues } from "@/components/form-bits";
import { CategoryIcon } from "@/components/category-icon";
import { Section } from "./course-form";

export function CategoryForm({ category, saved }: { category?: CategoryEditDTO; saved?: boolean }) {
  const [state, action, pending] = useActionState<FormState, FormData>(saveCategoryAction, { status: "idle" });
  const [icon, setIcon] = useState(category?.iconKey ?? "");
  const onSubmit = useKeepValues(action);
  const e = state.fieldErrors ?? {};
  const c = category;

  return (
    <form onSubmit={onSubmit} className="space-y-6" noValidate>
      {c && <><input type="hidden" name="id" value={c.id} /><input type="hidden" name="slug" value={c.slug} /></>}
      {saved && state.status === "idle" && <p role="status" className="rounded-lg bg-brand-50 px-4 py-3 text-sm font-semibold text-brand-800">Saved. Public pages have been refreshed.</p>}
      <Section title="Category">
        <Field label="Name" name="name" errors={e.name}><input id="name" name="name" defaultValue={c?.name} required className={inputCls} /></Field>
        {!c && <Field label="Page address (optional)" name="slug" errors={e.slug}><input id="slug" name="slug" className={inputCls} /></Field>}
        {c && <p className="text-sm text-muted">Page address: <code className="rounded bg-surface px-1.5 py-0.5">/categories/{c.slug}</code></p>}
        <Field label="Description" name="description" errors={e.description}><textarea id="description" name="description" rows={3} defaultValue={c?.description} className={inputCls} /></Field>
        <div className="grid gap-4 sm:grid-cols-2">
          <Field label="Display order (lowest first)" name="sortOrder" errors={e.sortOrder}><input id="sortOrder" name="sortOrder" type="number" min={0} defaultValue={c?.sortOrder ?? 0} className={inputCls} /></Field>
          <Field label="Status" name="status" errors={e.status}>
            <select id="status" name="status" defaultValue={c?.status ?? "PUBLISHED"} className={inputCls}><option value="PUBLISHED">Published</option><option value="DRAFT">Draft (hidden)</option><option value="ARCHIVED">Archived</option></select>
          </Field>
        </div>
      </Section>
      <Section title="Icon or image" hint="Pick an icon from the library, or paste an image link (it takes priority on the website when set).">
        <input type="hidden" name="iconKey" value={icon} />
        <div role="radiogroup" aria-label="Icon" className="flex flex-wrap gap-2">
          {ICON_LIBRARY.map((k) => (
            <button type="button" key={k} role="radio" aria-checked={icon === k} onClick={() => setIcon(k)} title={k}
              className={`grid h-12 w-12 place-items-center rounded-xl border transition ${icon === k ? "border-brand-600 bg-brand-50 text-brand-700 ring-2 ring-brand-200" : "border-line text-muted hover:border-brand-500"}`}>
              <CategoryIcon name={k} className="h-5 w-5" />
            </button>
          ))}
        </div>
        <Field label="Image link (https://…)" name="imageUrl" errors={e.imageUrl}><input id="imageUrl" name="imageUrl" type="url" defaultValue={c?.imageUrl} className={inputCls} /></Field>
      </Section>
      <Section title="Search appearance (SEO)">
        <Field label="Page title" name="metaTitle" errors={e.metaTitle}><input id="metaTitle" name="metaTitle" maxLength={70} defaultValue={c?.metaTitle} className={inputCls} /></Field>
        <Field label="Meta description" name="metaDescription" errors={e.metaDescription}><textarea id="metaDescription" name="metaDescription" rows={2} maxLength={320} defaultValue={c?.metaDescription} className={inputCls} /></Field>
        <Field label="Keywords" name="metaKeywords" errors={e.metaKeywords}><input id="metaKeywords" name="metaKeywords" defaultValue={c?.metaKeywords} className={inputCls} /></Field>
      </Section>
      <div className="flex items-center gap-4">
        <button disabled={pending} className="rounded-lg bg-brand-600 px-6 py-2.5 text-sm font-semibold text-white hover:bg-brand-700 disabled:opacity-60">{pending ? "Saving…" : c ? "Save changes" : "Create category"}</button>
        <div className="min-w-0 flex-1"><FormMessage state={state} /></div>
      </div>
    </form>
  );
}
