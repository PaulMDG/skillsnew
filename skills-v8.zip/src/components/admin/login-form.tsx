"use client";

import { useActionState } from "react";
import { loginAction } from "@/app/admin/(auth)/actions";
import type { AuthFormState } from "@/lib/auth/types";
import { Field, inputCls } from "@/components/form-bits";

export function LoginForm({ next }: { next?: string }) {
  const [state, action, pending] = useActionState<AuthFormState, FormData>(loginAction, {});
  return (
    <form action={action} className="mt-6 space-y-4">
      <input type="hidden" name="next" value={next ?? ""} />
      <Field label="Email" name="email"><input id="email" name="email" type="email" autoComplete="username" required autoFocus className={inputCls} /></Field>
      <Field label="Password" name="password"><input id="password" name="password" type="password" autoComplete="current-password" required className={inputCls} /></Field>
      {state.error && <p role="alert" className="rounded-lg bg-red-50 px-3.5 py-2.5 text-sm font-medium text-red-700">{state.error}</p>}
      <button disabled={pending} className="w-full rounded-lg bg-brand-600 px-5 py-3 text-sm font-semibold text-white transition hover:bg-brand-700 disabled:opacity-60">{pending ? "Checking…" : "Continue"}</button>
    </form>
  );
}
