"use client";

import { useActionState } from "react";
import { saveCourseAction } from "@/app/admin/(panel)/courses/actions";
import { outlineToText } from "@/lib/admin-schemas";
import type { CourseEditDTO } from "@/lib/types";
import type { FormState } from "@/lib/validation";
import { Field, FormMessage, inputCls, useKeepValues } from "@/components/form-bits";

export function Section({ title, hint, children }: { title: string; hint?: string; children: React.ReactNode }) {
  return (
    <section className="rounded-2xl border border-line bg-white p-6">
      <h2 className="text-lg font-bold">{title}</h2>
      {hint && <p className="mt-1 text-sm text-muted">{hint}</p>}
      <div className="mt-5 space-y-5">{children}</div>
    </section>
  );
}

const Check = ({ name, value, label, defaultChecked }: { name: string; value?: string; label: string; defaultChecked?: boolean }) => (
  <label className="flex cursor-pointer items-center gap-2 text-sm"><input type="checkbox" name={name} value={value} defaultChecked={defaultChecked} className="h-4 w-4 accent-brand-600" />{label}</label>
);

export function CourseForm({ course, categories, saved }: { course?: CourseEditDTO; categories: { id: string; name: string }[]; saved?: boolean }) {
  const [state, action, pending] = useActionState<FormState, FormData>(saveCourseAction, { status: "idle" });
  const onSubmit = useKeepValues(action);
  const e = state.fieldErrors ?? {};
  const c = course;
  const price = (l: "FIVE_DAY" | "TEN_DAY", cur: "KES" | "USD") => c?.prices[l]?.[cur] ?? "";

  return (
    <form onSubmit={onSubmit} className="space-y-6" noValidate>
      {c && <input type="hidden" name="id" value={c.id} />}
      {c && <input type="hidden" name="slug" value={c.slug} />}
      {saved && state.status === "idle" && <p role="status" className="rounded-lg bg-brand-50 px-4 py-3 text-sm font-semibold text-brand-800">Saved. Public pages have been refreshed.</p>}

      <Section title="Basics">
        <Field label="Course name" name="name" errors={e.name}><input id="name" name="name" defaultValue={c?.name} required className={inputCls} /></Field>
        {!c && <Field label="Page address (optional – made from the name if blank)" name="slug" errors={e.slug}><input id="slug" name="slug" placeholder="e.g. data-analysis-excel" className={inputCls} /></Field>}
        {c && <p className="text-sm text-muted">Page address: <code className="rounded bg-surface px-1.5 py-0.5">/courses/{c.slug}</code> (fixed after creation so existing links and rankings keep working)</p>}
        <Field label="Category" name="categoryId" errors={e.categoryId}>
          <select id="categoryId" name="categoryId" defaultValue={c?.categoryId ?? ""} required className={inputCls}>
            <option value="" disabled>Choose a category…</option>
            {categories.map((k) => <option key={k.id} value={k.id}>{k.name}</option>)}
          </select>
        </Field>
        <Field label="One-line summary (shown on cards and in search results)" name="summary" errors={e.summary}><input id="summary" name="summary" maxLength={300} defaultValue={c?.summary} className={inputCls} /></Field>
        <Field label="Image link (https://…)" name="imageUrl" errors={e.imageUrl}><input id="imageUrl" name="imageUrl" type="url" defaultValue={c?.imageUrl} placeholder="https://…" className={inputCls} /></Field>
        <p className="-mt-2 text-xs text-muted">Direct uploads arrive once file storage is connected; paste an image link for now.</p>
      </Section>

      <Section title="Content" hint="Separate paragraphs with a blank line. Put each objective on its own line.">
        <Field label="Description" name="description" errors={e.description}><textarea id="description" name="description" rows={7} defaultValue={c?.description} required className={inputCls} /></Field>
        <Field label="What participants will learn (one per line)" name="objectives" errors={e.objectives}><textarea id="objectives" name="objectives" rows={5} defaultValue={c?.objectives} className={inputCls} /></Field>
        <Field label="Who should attend" name="targetAudience" errors={e.targetAudience}><textarea id="targetAudience" name="targetAudience" rows={3} defaultValue={c?.targetAudience} className={inputCls} /></Field>
        <Field label="How it is delivered" name="methodology" errors={e.methodology}><textarea id="methodology" name="methodology" rows={3} defaultValue={c?.methodology} className={inputCls} /></Field>
        <Field label="Course outline" name="outline" errors={e.outline}>
          <textarea id="outline" name="outline" rows={9} defaultValue={c ? outlineToText(c.outline) : ""} className={`${inputCls} font-mono text-[13px]`} placeholder={"Module 1 – Foundations\nKey concepts and terminology.\n\nModule 2 – Core methods\nStep-by-step techniques."} />
        </Field>
        <p className="-mt-2 text-xs text-muted">One module per block: first line is the title, the lines under it the description. Leave a blank line between modules.</p>
      </Section>

      <Section title="Format & schedule" hint="Schedules are created automatically: 52 weekly Monday–Friday dates for 5-day courses, 26 fortnightly dates for 10-day courses, topped up every night.">
        <fieldset>
          <legend className="mb-2 text-sm font-medium">Offered as</legend>
          <div className="flex flex-wrap gap-6"><Check name="lengths" value="FIVE_DAY" label="5-day (one week)" defaultChecked={c?.lengths.includes("FIVE_DAY")} /><Check name="lengths" value="TEN_DAY" label="10-day (two weeks)" defaultChecked={c?.lengths.includes("TEN_DAY")} /></div>
          {e.lengths && <p role="alert" className="mt-1 text-xs font-medium text-red-600">{e.lengths[0]}</p>}
        </fieldset>
        <fieldset>
          <legend className="mb-2 text-sm font-medium">Delivery</legend>
          <div className="flex flex-wrap gap-6"><Check name="deliveryModes" value="CLASSROOM" label="Classroom" defaultChecked={c ? c.deliveryModes.includes("CLASSROOM") : true} /><Check name="deliveryModes" value="ONLINE" label="Live online" defaultChecked={c ? c.deliveryModes.includes("ONLINE") : true} /></div>
          {e.deliveryModes && <p role="alert" className="mt-1 text-xs font-medium text-red-600">{e.deliveryModes[0]}</p>}
        </fieldset>
        <Check name="autoSchedule" label="Create and maintain schedules automatically" defaultChecked={c ? c.autoSchedule : true} />
      </Section>

      <Section title="Fees" hint="Leave a field empty to show “On request”. Amounts are per participant.">
        <div className="grid gap-4 sm:grid-cols-2">
          <Field label="5-day fee (KES)" name="price5Kes" errors={e.price5Kes}><input id="price5Kes" name="price5Kes" inputMode="decimal" defaultValue={price("FIVE_DAY", "KES")} className={inputCls} /></Field>
          <Field label="5-day fee (USD)" name="price5Usd" errors={e.price5Usd}><input id="price5Usd" name="price5Usd" inputMode="decimal" defaultValue={price("FIVE_DAY", "USD")} className={inputCls} /></Field>
          <Field label="10-day fee (KES)" name="price10Kes" errors={e.price10Kes}><input id="price10Kes" name="price10Kes" inputMode="decimal" defaultValue={price("TEN_DAY", "KES")} className={inputCls} /></Field>
          <Field label="10-day fee (USD)" name="price10Usd" errors={e.price10Usd}><input id="price10Usd" name="price10Usd" inputMode="decimal" defaultValue={price("TEN_DAY", "USD")} className={inputCls} /></Field>
        </div>
      </Section>

      <Section title="Search appearance (SEO)" hint="Leave blank to use the course name and summary.">
        <Field label="Page title (max 70 characters)" name="metaTitle" errors={e.metaTitle}><input id="metaTitle" name="metaTitle" maxLength={70} defaultValue={c?.metaTitle} className={inputCls} /></Field>
        <Field label="Meta description (max 320 characters)" name="metaDescription" errors={e.metaDescription}><textarea id="metaDescription" name="metaDescription" rows={3} maxLength={320} defaultValue={c?.metaDescription} className={inputCls} /></Field>
        <Field label="Keywords (comma separated)" name="metaKeywords" errors={e.metaKeywords}><input id="metaKeywords" name="metaKeywords" defaultValue={c?.metaKeywords} className={inputCls} /></Field>
      </Section>

      <div className="sticky bottom-0 -mx-4 flex flex-wrap items-center gap-4 border-t border-line bg-white/95 px-4 py-4 backdrop-blur sm:-mx-8 sm:px-8">
        <Field label="" name="status" errors={e.status}>
          <select id="status" name="status" defaultValue={c?.status ?? "DRAFT"} className={`${inputCls} !w-auto`} aria-label="Status">
            <option value="DRAFT">Draft (hidden)</option><option value="PUBLISHED">Published</option><option value="ARCHIVED">Archived</option>
          </select>
        </Field>
        <button disabled={pending} className="rounded-lg bg-brand-600 px-6 py-2.5 text-sm font-semibold text-white hover:bg-brand-700 disabled:opacity-60">{pending ? "Saving…" : c ? "Save changes" : "Create course"}</button>
        <div className="min-w-0 flex-1"><FormMessage state={state} /></div>
      </div>
    </form>
  );
}
