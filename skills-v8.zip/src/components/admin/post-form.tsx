"use client";

import { useActionState } from "react";
import { savePostAction } from "@/app/admin/(panel)/blog/actions";
import { isoToEat } from "@/lib/blog/schema";
import type { PostEditDTO } from "@/lib/types";
import type { FormState } from "@/lib/validation";
import { Field, FormMessage, inputCls, useKeepValues } from "@/components/form-bits";
import { Section } from "./course-form";

export function PostForm({ post, saved }: { post?: PostEditDTO; saved?: boolean }) {
  const [state, action, pending] = useActionState<FormState, FormData>(savePostAction, { status: "idle" });
  const onSubmit = useKeepValues(action);
  const e = state.fieldErrors ?? {};
  const p = post;
  const html = p?.format === "HTML";

  return (
    <form onSubmit={onSubmit} className="space-y-6" noValidate>
      {p && <><input type="hidden" name="id" value={p.id} /><input type="hidden" name="slug" value={p.slug} /></>}
      <input type="hidden" name="format" value={p?.format ?? "MARKDOWN"} />
      <input type="hidden" name="publishedAtOrig" value={p?.publishedAt ?? ""} />
      {saved && state.status === "idle" && <p role="status" className="rounded-lg bg-brand-50 px-4 py-3 text-sm font-semibold text-brand-800">Saved.</p>}

      <Section title="Article">
        <Field label="Title" name="title" errors={e.title}><input id="title" name="title" defaultValue={p?.title} required className={`${inputCls} text-lg font-semibold`} /></Field>
        {!p && <Field label="Page address (optional – made from the title if blank)" name="slug" errors={e.slug}><input id="slug" name="slug" className={inputCls} /></Field>}
        {p && <p className="text-sm text-muted">Page address: <code className="rounded bg-surface px-1.5 py-0.5">/blog/{p.slug}</code> (fixed once created so shared links keep working)</p>}
        <Field label="Summary (shown in listings and search results; leave blank to use the opening lines)" name="excerpt" errors={e.excerpt}><textarea id="excerpt" name="excerpt" rows={2} maxLength={320} defaultValue={p?.excerpt} className={inputCls} /></Field>
        <Field label={html ? "Body (HTML – imported from the old website)" : "Body (Markdown)"} name="body" errors={e.body}>
          <textarea id="body" name="body" rows={24} defaultValue={p?.body} required spellCheck className={`${inputCls} font-mono text-[13px] leading-relaxed`} />
        </Field>
        {!html && (
          <details className="rounded-lg bg-surface p-4 text-sm">
            <summary className="cursor-pointer font-semibold text-brand-700">Formatting help</summary>
            <pre className="mt-3 overflow-x-auto whitespace-pre-wrap font-mono text-[12px] leading-6 text-muted">{`## A section heading        ### A smaller heading
**bold**   *italic*   [link text](https://example.org)
[a course](/courses/pmp-prep)       ← link to your own pages with a path
- bullet point              1. numbered step
> a highlighted quote
![describe the image](https://…/picture.jpg)   ← https images only

| Column A | Column B |
|----------|----------|
| text     | text     |`}</pre>
            <p className="mt-2 text-muted">Start sections with <code>##</code>: they become the “In this article” contents. Scripts, embeds and styling are removed automatically for safety.</p>
          </details>
        )}
        <Field label="Cover image link (https://…)" name="coverUrl" errors={e.coverUrl}><input id="coverUrl" name="coverUrl" type="url" defaultValue={p?.coverUrl} className={inputCls} /></Field>
      </Section>

      <Section title="Topics & timing">
        <Field label="Topics (comma separated, up to 8)" name="tags" errors={e.tags}><input id="tags" name="tags" defaultValue={p?.tags.join(", ")} placeholder="leadership, monitoring and evaluation" className={inputCls} /></Field>
        <Field label="Publish date & time (Nairobi time; leave empty to publish now, or choose a future time to schedule)" name="publishAt" errors={e.publishAt}>
          <input id="publishAt" name="publishAt" type="datetime-local" defaultValue={isoToEat(p?.publishedAt)} className={`${inputCls} !w-auto`} />
        </Field>
      </Section>

      <Section title="Search appearance (SEO)" hint="Leave blank to use the title and summary.">
        <Field label="Page title (max 70 characters)" name="metaTitle" errors={e.metaTitle}><input id="metaTitle" name="metaTitle" maxLength={70} defaultValue={p?.metaTitle} className={inputCls} /></Field>
        <Field label="Meta description (max 320 characters)" name="metaDescription" errors={e.metaDescription}><textarea id="metaDescription" name="metaDescription" rows={2} maxLength={320} defaultValue={p?.metaDescription} className={inputCls} /></Field>
        <Field label="Keywords" name="metaKeywords" errors={e.metaKeywords}><input id="metaKeywords" name="metaKeywords" defaultValue={p?.metaKeywords} className={inputCls} /></Field>
      </Section>

      <div className="sticky bottom-0 -mx-4 flex flex-wrap items-center gap-4 border-t border-line bg-white/95 px-4 py-4 backdrop-blur sm:-mx-8 sm:px-8">
        <Field label="" name="status" errors={e.status}>
          <select id="status" name="status" defaultValue={p?.status ?? "DRAFT"} aria-label="Status" className={`${inputCls} !w-auto`}>
            <option value="DRAFT">Draft (hidden)</option><option value="PUBLISHED">Published</option><option value="ARCHIVED">Archived (hidden)</option>
          </select>
        </Field>
        <button disabled={pending} className="rounded-lg bg-brand-600 px-6 py-2.5 text-sm font-semibold text-white hover:bg-brand-700 disabled:opacity-60">{pending ? "Saving…" : p ? "Save changes" : "Create post"}</button>
        {p && <a href={`/admin/blog/${p.id}/preview`} target="_blank" rel="noopener" className="text-sm font-semibold text-brand-700 hover:underline">Preview saved version ↗</a>}
        <div className="min-w-0 flex-1"><FormMessage state={state} /></div>
      </div>
    </form>
  );
}
