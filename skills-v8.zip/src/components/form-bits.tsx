"use client";

import { useTransition, type FormEvent } from "react";
import type { FormState } from "@/lib/validation";

/**
 * React 19 clears every field in a <form action> once the action finishes – even when the server reported
 * a validation error, which would wipe what the person typed. Submitting through a transition keeps the values.
 */
export function useKeepValues(action: (fd: FormData) => void) {
  const [, startTransition] = useTransition();
  return (e: FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    const fd = new FormData(e.currentTarget);
    startTransition(() => action(fd));
  };
}

export function Field({ label, name, errors, children }: { label: string; name: string; errors?: string[]; children: React.ReactNode }) {
  return (
    <div>
      <label htmlFor={name} className="mb-1.5 block text-sm font-medium text-ink">{label}</label>
      {children}
      {errors?.[0] && <p role="alert" className="mt-1 text-xs font-medium text-red-600">{errors[0]}</p>}
    </div>
  );
}

export const inputCls =
  "w-full rounded-lg border border-line bg-white px-3.5 py-2.5 text-sm text-ink placeholder:text-muted/60 transition focus:border-brand-500 focus:outline-none focus:ring-2 focus:ring-brand-200";

/** Hidden from people, irresistible to bots. */
export function Honeypot() {
  return (
    <div aria-hidden="true" className="absolute -left-[9999px] h-0 w-0 overflow-hidden">
      <label>Website<input type="text" name="website" tabIndex={-1} autoComplete="off" /></label>
    </div>
  );
}

export function FormMessage({ state }: { state: FormState }) {
  if (state.status === "idle" || !state.message) return null;
  const ok = state.status === "success";
  return (
    <p role={ok ? "status" : "alert"} className={`rounded-lg px-3.5 py-2.5 text-sm font-medium ${ok ? "bg-brand-50 text-brand-800" : "bg-red-50 text-red-700"}`}>
      {state.message}
    </p>
  );
}
