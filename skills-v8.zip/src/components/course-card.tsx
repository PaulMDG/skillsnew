import Link from "next/link";
import Image from "next/image";
import { Clock, ArrowRight } from "lucide-react";
import type { CourseCard } from "@/lib/types";
import { lengthLabel, money } from "@/lib/format";
import { CategoryIcon } from "./category-icon";

export function CourseCardView({ course, priority = false }: { course: CourseCard; priority?: boolean }) {
  return (
    <Link href={`/courses/${course.slug}`} className="group flex h-full flex-col overflow-hidden rounded-2xl border border-line bg-white transition hover:-translate-y-0.5 hover:border-brand-200 hover:shadow-lg">
      <div className="relative aspect-[16/9] overflow-hidden bg-gradient-to-br from-brand-700 to-brand-900">
        {course.imageUrl ? (
          <Image src={course.imageUrl} alt="" fill sizes="(min-width:1024px) 33vw, (min-width:640px) 50vw, 100vw" priority={priority} className="object-cover transition duration-500 group-hover:scale-105" />
        ) : (
          <div className="grid h-full place-items-center">
            <CategoryIcon name={course.iconKey} className="h-14 w-14 text-white/25" />
          </div>
        )}
        <span className="absolute left-3 top-3 rounded-full bg-white/95 px-2.5 py-1 text-xs font-semibold text-brand-800">{course.categoryName}</span>
      </div>
      <div className="flex flex-1 flex-col p-5">
        <h3 className="text-base font-semibold leading-snug text-ink group-hover:text-brand-700">{course.name}</h3>
        <p className="mt-2 line-clamp-2 text-sm leading-relaxed text-muted">{course.summary}</p>
        <div className="mt-auto flex items-end justify-between gap-3 pt-5">
          <div>
            <div className="flex items-center gap-1.5 text-xs font-medium text-muted"><Clock className="h-3.5 w-3.5" />{course.lengths.map((l) => lengthLabel[l]).join(" or ") || "Contact us"}</div>
            {course.priceFrom.KES != null && <div className="mt-1 text-sm font-bold text-ink"><span className="text-xs font-medium text-muted">from </span>{money(course.priceFrom.KES, "KES")}</div>}
          </div>
          <span className="grid h-9 w-9 place-items-center rounded-full bg-brand-50 text-brand-700 transition group-hover:bg-brand-600 group-hover:text-white"><ArrowRight className="h-4 w-4" /></span>
        </div>
      </div>
    </Link>
  );
}
