import Link from "next/link";
import { Mail, Phone } from "lucide-react";
import { Logo } from "./site-header";
import { site } from "@/lib/site";

export function SiteFooter() {
  return (
    <footer className="mt-24 bg-brand-900 text-brand-100">
      <div className="mx-auto grid max-w-7xl gap-10 px-4 py-14 sm:px-6 md:grid-cols-4">
        <div className="md:col-span-2">
          <Logo light />
          <p className="mt-4 max-w-md text-sm leading-relaxed text-brand-200">{site.tagline}. Instructor-led courses in classroom and online formats, with new start dates every week.</p>
          <div className="mt-5 space-y-2 text-sm">
            <a className="flex items-center gap-2 hover:text-white" href={`mailto:${site.email}`}><Mail className="h-4 w-4" />{site.email}</a>
            <a className="flex items-center gap-2 hover:text-white" href={`tel:${site.phone.replace(/\s/g, "")}`}><Phone className="h-4 w-4" />{site.phone}</a>
          </div>
        </div>
        <div>
          <h2 className="text-sm font-semibold text-white">Explore</h2>
          <ul className="mt-4 space-y-2 text-sm">
            <li><Link className="hover:text-white" href="/courses">All courses</Link></li>
            <li><Link className="hover:text-white" href="/#categories">Categories</Link></li>
            <li><Link className="hover:text-white" href="/#upcoming">Training calendar</Link></li>
            <li><Link className="hover:text-white" href="/blog">Insights</Link></li>
          </ul>
        </div>
        <div>
          <h2 className="text-sm font-semibold text-white">Company</h2>
          <ul className="mt-4 space-y-2 text-sm">
            <li><Link className="hover:text-white" href="/about">About us</Link></li>
            <li><Link className="hover:text-white" href="/contact">Contact</Link></li>
            <li><Link className="hover:text-white" href="/privacy">Privacy policy</Link></li>
          </ul>
        </div>
      </div>
      <div className="border-t border-brand-800 py-5 text-center text-xs text-brand-200">© {new Date().getFullYear()} {site.name}. All rights reserved.</div>
    </footer>
  );
}
