import Link from "next/link";
import { Menu } from "lucide-react";
import { site } from "@/lib/site";

const nav = [
  { href: "/courses", label: "Courses" },
  { href: "/#categories", label: "Categories" },
  { href: "/#upcoming", label: "Training calendar" },
  { href: "/blog", label: "Insights" },
  { href: "/contact", label: "Contact" },
];

export function Logo({ light = false }: { light?: boolean }) {
  return (
    <span className="flex items-center gap-2.5">
      <span className="grid h-9 w-9 place-items-center rounded-xl bg-brand-600 text-sm font-bold text-white shadow-sm">SA</span>
      <span className={`text-lg font-bold tracking-tight ${light ? "text-white" : "text-ink"}`}>{site.name}</span>
    </span>
  );
}

export function SiteHeader() {
  return (
    <header className="sticky top-0 z-40 border-b border-line bg-white/90 backdrop-blur">
      <div className="mx-auto flex h-16 max-w-7xl items-center justify-between px-4 sm:px-6">
        <Link href="/" aria-label={`${site.name} home`}><Logo /></Link>
        <nav aria-label="Main" className="hidden items-center gap-1 md:flex">
          {nav.map((n) => (
            <Link key={n.href} href={n.href} className="rounded-lg px-3.5 py-2 text-sm font-medium text-muted transition hover:bg-brand-50 hover:text-brand-800">{n.label}</Link>
          ))}
          <Link href="/courses" className="ml-3 rounded-lg bg-brand-600 px-4 py-2 text-sm font-semibold text-white shadow-sm transition hover:bg-brand-700">Find a course</Link>
        </nav>
        <details className="relative md:hidden">
          <summary aria-label="Open menu" className="grid h-10 w-10 place-items-center rounded-lg border border-line"><Menu className="h-5 w-5" /></summary>
          <div className="absolute right-0 mt-2 w-60 rounded-xl border border-line bg-white p-2 shadow-xl">
            {nav.map((n) => <Link key={n.href} href={n.href} className="block rounded-lg px-3 py-2.5 text-sm font-medium hover:bg-brand-50">{n.label}</Link>)}
            <Link href="/courses" className="mt-1 block rounded-lg bg-brand-600 px-3 py-2.5 text-center text-sm font-semibold text-white">Find a course</Link>
          </div>
        </details>
      </div>
    </header>
  );
}
