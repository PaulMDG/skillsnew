import Link from "next/link";
import { Clock } from "lucide-react";
import type { PostCard } from "@/lib/types";
import { formatPostDate } from "@/lib/format";

export function PostCardView({ post }: { post: PostCard }) {
  return (
    <article className="group flex h-full flex-col overflow-hidden rounded-2xl border border-line bg-white transition hover:-translate-y-0.5 hover:border-brand-200 hover:shadow-lg">
      <Link href={`/blog/${post.slug}`} className="flex flex-1 flex-col" aria-label={post.title}>
        <div className="aspect-[16/9] overflow-hidden bg-gradient-to-br from-brand-700 to-brand-900">
          {/* eslint-disable-next-line @next/next/no-img-element */}
          {post.coverUrl ? <img src={post.coverUrl} alt="" loading="lazy" decoding="async" className="h-full w-full object-cover transition duration-500 group-hover:scale-105" /> : <div className="grid h-full place-items-center text-4xl font-black text-white/20">SA</div>}
        </div>
        <div className="flex flex-1 flex-col p-5">
          {post.tags[0] && <span className="mb-2 text-xs font-semibold uppercase tracking-wide text-brand-700">{post.tags[0].replace(/-/g, " ")}</span>}
          <h2 className="text-lg font-semibold leading-snug group-hover:text-brand-700">{post.title}</h2>
          <p className="mt-2 line-clamp-3 text-sm leading-relaxed text-muted">{post.excerpt}</p>
          <div className="mt-auto flex items-center gap-3 pt-4 text-xs text-muted"><time dateTime={post.publishedAt}>{formatPostDate(post.publishedAt)}</time><span className="flex items-center gap-1"><Clock className="h-3.5 w-3.5" />{post.readingMinutes} min read</span></div>
        </div>
      </Link>
    </article>
  );
}
