import Link from "next/link";
import { Clock } from "lucide-react";
import { renderPost } from "@/lib/blog/render";
import { formatPostDate } from "@/lib/format";
import type { PostDetail } from "@/lib/types";
import { PostCardView } from "./post-card";

/** One layout for the public article and the staff preview, so what you preview is what readers get. */
export function PostArticle({ post, preview = false }: { post: PostDetail; preview?: boolean }) {
  const { html, toc } = renderPost(post.body, post.format);
  return (
    <div className="mx-auto max-w-7xl px-4 py-10 sm:px-6">
      {preview && <p role="status" className="mb-6 rounded-lg bg-amber-50 px-4 py-3 text-sm font-semibold text-amber-900">Staff preview. This is how the post will look; it may not be public yet.</p>}
      <nav aria-label="Breadcrumb" className="text-sm text-muted"><Link href="/blog" className="hover:underline">Insights</Link> / <span className="text-ink">{post.title}</span></nav>
      <div className="mx-auto mt-6 max-w-3xl">
        <header>
          {post.tags.length > 0 && <div className="mb-3 flex flex-wrap gap-2">{post.tags.map((t) => <Link key={t} href={`/blog/tag/${t}`} className="rounded-full bg-brand-50 px-3 py-1 text-xs font-semibold text-brand-800 hover:bg-brand-100">{t.replace(/-/g, " ")}</Link>)}</div>}
          <h1 className="text-3xl font-extrabold leading-tight tracking-tight sm:text-4xl">{post.title}</h1>
          <p className="mt-4 text-lg leading-relaxed text-muted">{post.excerpt}</p>
          <div className="mt-5 flex flex-wrap items-center gap-x-4 gap-y-1 text-sm text-muted"><span className="font-medium text-ink">{post.author}</span><time dateTime={post.publishedAt}>{formatPostDate(post.publishedAt)}</time><span className="flex items-center gap-1"><Clock className="h-4 w-4" />{post.readingMinutes} min read</span></div>
        </header>
        {post.coverUrl && /* eslint-disable-next-line @next/next/no-img-element */ <img src={post.coverUrl} alt="" fetchPriority="high" decoding="async" className="mt-8 aspect-[16/9] w-full rounded-2xl object-cover" />}
        {toc.length >= 3 && (
          <nav aria-label="Contents" className="mt-8 rounded-xl border border-line bg-surface p-5">
            <p className="text-sm font-bold">In this article</p>
            <ol className="mt-2 space-y-1 text-sm">{toc.map((t) => <li key={t.id} className={t.level === 3 ? "ml-4" : ""}><a href={`#${t.id}`} className="text-brand-700 hover:underline">{t.text}</a></li>)}</ol>
          </nav>
        )}
        <div className="prose-blog mt-8" dangerouslySetInnerHTML={{ __html: html }} />
        <aside className="mt-12 rounded-2xl bg-gradient-to-r from-brand-700 to-brand-900 p-8 text-white">
          <h2 className="text-xl font-bold">Turn what you read into a skill</h2>
          <p className="mt-2 text-brand-100">Instructor-led courses start every Monday, in the classroom and online.</p>
          <Link href="/courses" className="mt-4 inline-block rounded-lg bg-accent-500 px-5 py-2.5 font-semibold text-brand-900 hover:bg-accent-400">Browse courses</Link>
        </aside>
      </div>
      {post.related.length > 0 && (
        <section aria-labelledby="related" className="mt-16">
          <h2 id="related" className="text-2xl font-bold">Keep reading</h2>
          <div className="mt-6 grid gap-6 sm:grid-cols-2 lg:grid-cols-3">{post.related.map((p) => <PostCardView key={p.slug} post={p} />)}</div>
        </section>
      )}
    </div>
  );
}
