# Staging → production checklist

Everything below the line "Only you can verify" cannot be tested from a developer machine. Everything above it already has
automated tests, so you do not need to re-test it by hand.

## 1. Provision
| What | Notes |
|---|---|
| PostgreSQL 14+ (Neon, Supabase, RDS …) | Create **two** connection strings: pooled → `DATABASE_URL`, direct → `DIRECT_URL` (migrations only). |
| Hosting (Vercel recommended) | Node 20+. Crons in `vercel.json`: schedules nightly, FAQs nightly, **emails hourly (needs Vercel Pro; on the free plan call `/api/cron/emails` hourly from cron-job.org with the bearer secret)**. |
| Resend account + verified sending domain | Add the SPF, DKIM and DMARC records Resend shows you. |
| OpenAI API key | Optional. Without it everything works; FAQs are written by hand. |

## 2. Environment variables (Production *and* Preview)
Required: `DATABASE_URL`, `DIRECT_URL`, `NEXT_PUBLIC_SITE_URL`, `AUTH_SECRET` (`openssl rand -base64 48`),
`AUTH_ENCRYPTION_KEY` (`openssl rand -base64 32` – **back it up**: losing it forces every staff member to re-enrol 2FA),
`IP_HASH_SALT`, `CRON_SECRET`, `RESEND_API_KEY`, `RESEND_WEBHOOK_SECRET`, `EMAIL_FROM`, `EMAIL_REPLY_TO`.
Optional: `EMAIL_NOTIFY_TO`, `OPENAI_API_KEY`, `OPENAI_MODEL`, `FAQ_AUTO_PUBLISH` (leave 0), `FAQ_MAX_PER_RUN`, `FOLLOWUP_MAX_STAGE`, `DB_POOL_MAX`.
**Never set** `AUTH_ALLOW_MEMORY_STORE`, `EMAIL_DRY_RUN` or `ALLOW_DEMO_STAFF` in production.

## 3. First deployment, in this order
1. `npx prisma migrate deploy` (run from your machine with `DIRECT_URL` set, or as a Vercel build step).
2. `npx tsx scripts/create-admin.ts create you@org.org "Your Name" ADMIN` → sign in at `/admin`, enrol 2FA.
3. Deploy the app. (Optional on staging only: `npm run db:seed` for sample data.)
4. Resend → Webhooks → `https://YOUR-SITE/api/webhooks/resend`, all email events, paste the signing secret into `RESEND_WEBHOOK_SECRET`.
5. Migrate old data: follow **MIGRATION.md** (dry run → review `import-report.json` → `--commit` on staging first).
6. Admin → Unscheduled → generate schedules for any course the nightly job has not reached yet.
7. Switch DNS. The old URLs you passed to the importer (`--course-path` …) now 301 to the new pages.

## 4. Already covered by automated tests (162 browser checks, 77 unit tests, 39 PostgreSQL integration tests)
Weekday-only schedules and the 52/26 rolling top-up (including races and gap filling) · database refuses weekend schedules ·
login, mandatory 2FA, lockout, replay protection, roles · brochure PDF, signed links · registration · follow-up cadence,
one-send-only under concurrency, bounces/complaints/unsubscribes · webhooks (signature, duplicates, ordering) · FAQ generation
rules and review flow · course/category/price/schedule/blog editing · sanitising of all rich content · redirects · import.

## 5. Only you can verify
- [ ] **Email deliverability**: send a brochure request to a Gmail and an Outlook address and a [mail-tester.com](https://www.mail-tester.com) address; aim for 9+/10; check the unsubscribe link and the PDF attachment.
- [ ] **Resend webhook**: in Resend send a test event; confirm `/admin/emails` shows delivered/opened for a real message.
- [ ] **Hourly email cron** actually fires (Vercel → Cron Jobs → logs) and the follow-up window (Mon–Fri 08:00–17:59 Nairobi) behaves as you want.
- [ ] **OpenAI quality**: generate FAQs for 3 real courses; read them before approving. Tune `OPENAI_MODEL` if needed.
- [ ] **Your real data import**: dry run → read the anomaly table → staging commit → spot-check 10 courses, 10 students, 5 registrations, opt-outs.
- [ ] **Search**: submit `/sitemap.xml` in Google Search Console and Bing; inspect one course URL (Course/FAQ structured data valid in the Rich Results test); confirm 301s for 20 old URLs.
- [ ] **Performance**: run PageSpeed on `/`, a course page and an article (images are links to external hosts; consider R2/Cloudinary).
- [ ] **Backups and monitoring**: enable point-in-time recovery on the database; add error alerts (Vercel/Sentry); restore a backup once to prove it works.
- [ ] **Legal**: privacy policy and the lawful basis for follow-up emails (Kenya Data Protection Act); the unsubscribe link and suppression list are built in, the wording is yours.

## 6. Rollback
The app is stateless; redeploy the previous build. Migrations are additive; to undo a data import run it only on a disposable
copy first (the importer never writes to the old database and never overwrites existing rows).
