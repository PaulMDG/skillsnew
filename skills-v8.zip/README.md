# Skills for Africa – Next.js rebuild

## Run it now (no database, no email account needed)
    npm install
    npx prisma generate          # needs internet once, to fetch Prisma's engine
    npm run dev                  # sample data when DATABASE_URL is empty
    # /admin → admin@example.com / dev-password-123456 (preview only; 2FA enrolment is enforced)
    # Emails are NOT sent in development: HTML previews are written to .email-previews/

## Run against PostgreSQL
    cp .env.example .env         # DATABASE_URL, DIRECT_URL, AUTH_SECRET, AUTH_ENCRYPTION_KEY, CRON_SECRET, IP_HASH_SALT
    npm install                  # also runs `prisma generate` (the client needs no native engine file)
    npx prisma migrate deploy    # creates all tables AND the database-level Monday–Friday rules
    npx tsx scripts/create-admin.ts create you@org.org "Your Name" ADMIN   # prints a one-time password
    npm run db:seed              # OPTIONAL: sample categories/courses/schedules/FAQs/blog on an EMPTY database
    npm run dev
See **STAGING.md** for the full deployment and verification checklist.

## Going live with email (Resend)
1. Verify your sending domain in Resend; set RESEND_API_KEY and EMAIL_FROM.
2. Add a webhook in Resend → https://YOUR-SITE/api/webhooks/resend (events: sent, delivered, delivery_delayed,
   bounced, complained, opened, clicked). Put its signing secret in RESEND_WEBHOOK_SECRET.
3. Cron (vercel.json): schedules nightly, emails HOURLY. Hourly cron needs Vercel Pro; on Hobby use an external
   scheduler (e.g. cron-job.org) calling GET /api/cron/emails with `Authorization: Bearer $CRON_SECRET`.

## Account recovery
    npx tsx scripts/create-admin.ts reset-password you@org.org
    npx tsx scripts/create-admin.ts reset-2fa      you@org.org
    npx tsx scripts/create-admin.ts deactivate     you@org.org

## Tests
    npm test        # 74 unit tests: schedule engine, auth crypto, email cadence/service/webhooks, validation, legacy import, FAQ rules, blog rendering
    npx tsc --noEmit
    npm run test:integration   # 39 tests against a REAL PostgreSQL (needs DATABASE_URL; it WIPES that database – use a disposable one)

## AI FAQs (OpenAI)
1. Set `OPENAI_API_KEY` (and optionally `OPENAI_MODEL`). Without it everything else works; FAQs can be written by hand.
2. FAQ drafts are written automatically when a published course is created or its *text* changes (a price edit never triggers it),
   by the daily job (`/api/cron/faqs`), or on demand from **Admin → FAQs**.
3. Drafts wait in the review queue. Nothing reaches the website until someone approves it (set `FAQ_AUTO_PUBLISH=1` to skip review – not recommended).
4. Safeguards: answers that mention prices, dates, links, contact details, or unverifiable claims ("accredited", "guaranteed") are
   discarded automatically; approved/rejected questions are never regenerated; a failing course is retried at most 3 times a day;
   `FAQ_MAX_PER_RUN` caps how many courses are processed per run, so spend is bounded.
5. Approved FAQs appear on the course page and in its FAQPage structured data (Google rich results and AI search).

## Blog
- **Admin → Blog**: write in Markdown (a formatting help panel is built in), add topics, a cover image link, SEO fields, and either publish now,
  schedule for a future Nairobi time, or keep as a draft. **Preview** shows the exact public layout for any status.
- Everything is sanitised on output (scripts, embeds, inline styles, `javascript:` links and non-https images never reach a visitor);
  posts imported from the old site are stored as HTML and pass through the same filter.
- Public: `/blog` (paginated), `/blog/<slug>` (contents list, BlogPosting + breadcrumb markup, related posts), `/blog/tag/<topic>`,
  `/blog/feed.xml` (RSS), plus entries in `sitemap.xml`, `llms.txt` and a "Latest insights" strip on the home page.
- A post's address is fixed once created; its first publish time is kept exactly, however often you edit.

## Moving the old data
See MIGRATION.md.

## Known gaps (not built yet)
image upload (images are links for now) · staff management screen (create/disable staff, reset 2FA from the browser) ·
Upstash rate limiting for multi-server hosting.
