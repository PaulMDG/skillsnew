/**
 * Integration tests against a REAL PostgreSQL (DATABASE_URL, migrations applied). They TRUNCATE every table first, so never
 * point this at a database you care about.   npm run test:integration
 */
import { test, describe, before, after } from "node:test";
import assert from "node:assert/strict";
import { prisma } from "../../src/lib/db";
import { prismaRepo as repo } from "../../src/lib/repo.prisma";
import { seedDemo } from "../../src/lib/demo-seed";
import { ensureCourseSchedules, listUnscheduledCourses, rollAllSchedules } from "../../src/lib/schedules/engine";
import { prismaEmailStore as emails } from "../../src/lib/email/store.prisma";
import { prismaStaffStore as staff } from "../../src/lib/auth/store.prisma";
import { createEmailService } from "../../src/lib/email/service";
import { createFaqService } from "../../src/lib/faq/service";
import { buildPlan } from "../../src/lib/legacy/transform";
import { fixture, opts as legacyOpts } from "../../src/lib/legacy/fixture";
import { loadPlan } from "../../src/lib/legacy/load";
import type { CourseInput } from "../../src/lib/types";

if (!process.env.DATABASE_URL) throw new Error("DATABASE_URL is required");
const T0 = new Date("2026-10-12T07:00:00Z"); // a Monday, 10:00 in Nairobi
const day = (n: number, from = T0) => new Date(from.getTime() + n * 86_400_000);
const iso = (d: Date) => d.toISOString().slice(0, 10);

async function reset() {
  const t = await prisma.$queryRaw<{ tablename: string }[]>`select tablename::text as tablename from pg_tables where schemaname='public' and tablename <> '_prisma_migrations'`;
  await prisma.$executeRawUnsafe(`TRUNCATE ${t.map((x) => `"${x.tablename}"`).join(", ")} RESTART IDENTITY CASCADE`);
}
const courseId = async (slug: string) => (await prisma.course.findUniqueOrThrow({ where: { slug }, select: { id: true } })).id;
const upcoming = (id: string, length: "FIVE_DAY" | "TEN_DAY") => prisma.schedule.count({ where: { courseId: id, length, status: "OPEN", startDate: { gte: new Date() } } });
const mailer = () => { const sent: { to: string; subject: string; attachments?: unknown[]; headers?: Record<string, string> }[] = []; return { sent, send: async (m: (typeof sent)[number]) => { sent.push(m); return { providerId: `prov_${sent.length}_${Math.random().toString(36).slice(2, 8)}` }; } }; };

async function newCourse(slug: string, extra: Partial<CourseInput> = {}) {
  const [cat] = await repo.listCategoryOptions();
  const r = await repo.saveCourse({ name: `Course ${slug}`, slug, categoryId: cat.id, description: `A practical course called ${slug} for the integration tests.`, lengths: ["FIVE_DAY"], deliveryModes: ["ONLINE"], autoSchedule: true, status: "PUBLISHED", outline: [], prices: {}, ...extra });
  assert.ok(r.ok, JSON.stringify(r));
  return r.ok ? r : (undefined as never);
}

before(async () => { await reset(); await seedDemo({ demoStaff: true }); });
after(async () => { await prisma.$disconnect(); });

describe("seed + schedule engine", () => {
  test("seeded through the real write paths: counts", async () => {
    assert.deepEqual(await Promise.all([prisma.category.count(), prisma.course.count(), prisma.blogPost.count(), prisma.center.count(), prisma.staffUser.count()]), [6, 14, 11, 9, 3]);
  });

  test("every course with a length has exactly 52 five-day / 26 ten-day Mon–Fri schedules ahead", async () => {
    const g = await prisma.schedule.groupBy({ by: ["courseId", "length"], where: { status: "OPEN" }, _count: true });
    assert.equal(g.length, 17);
    for (const r of g) assert.equal(r._count, r.length === "FIVE_DAY" ? 52 : 26);
    const [bad] = await prisma.$queryRaw<{ n: bigint }[]>`select count(*) n from "Schedule" where extract(isodow from "startDate") <> 1 or extract(isodow from "endDate") <> 5`;
    assert.equal(Number(bad.n), 0);
  });

  test("10-day courses start every second Monday and span two weeks", async () => {
    const rows = await prisma.schedule.findMany({ where: { courseId: await courseId("pmp-prep"), length: "TEN_DAY" }, orderBy: { startDate: "asc" }, take: 5 });
    rows.forEach((r, i) => { assert.equal((r.endDate.getTime() - r.startDate.getTime()) / 86_400_000, 11); if (i) assert.equal((r.startDate.getTime() - rows[i - 1].startDate.getTime()) / 86_400_000, 14); });
  });

  test("the database itself refuses a weekend schedule, but accepts flagged history", async () => {
    const id = await courseId("pmp-prep");
    await assert.rejects(prisma.schedule.create({ data: { courseId: id, length: "FIVE_DAY", startDate: day(-2), endDate: day(2) } }), /schedule_(starts_monday|ends_friday|length_matches)/);
    await prisma.schedule.create({ data: { courseId: id, length: "FIVE_DAY", startDate: new Date("2020-01-04"), endDate: new Date("2020-01-08"), isLegacy: true } });
  });

  test("running the nightly job three times at once creates nothing extra and fails nothing", async () => {
    const before = await prisma.schedule.count();
    const r = await Promise.all([rollAllSchedules(prisma), rollAllSchedules(prisma), rollAllSchedules(prisma)]);
    assert.ok(r.every((x) => x.failures.length === 0));
    assert.equal(await prisma.schedule.count(), before);
  });

  test("two weeks later the engine appends exactly the lapsed weeks (2 five-day, 1 ten-day)", async () => {
    const id = (await newCourse("lapse-course", { lengths: ["FIVE_DAY", "TEN_DAY"] })).id;
    const r = await ensureCourseSchedules(prisma, id, {}, day(14, new Date()));
    assert.deepEqual(r.created, { FIVE_DAY: 2, TEN_DAY: 1 });
    assert.equal((await ensureCourseSchedules(prisma, id, {}, day(14, new Date()))).created.FIVE_DAY, 0);
  });

  test("a cancelled date is not recreated: one replacement is added at the end", async () => {
    const id = await courseId("ms-project-planning");
    const first = await prisma.schedule.findFirstOrThrow({ where: { courseId: id, status: "OPEN", startDate: { gte: new Date() } }, orderBy: { startDate: "asc" } });
    await prisma.schedule.update({ where: { id: first.id }, data: { status: "CANCELLED" } });
    const r = await ensureCourseSchedules(prisma, id);
    assert.equal(r.created.FIVE_DAY, 1);
    assert.equal(await upcoming(id, "FIVE_DAY"), 52);
    assert.equal((await prisma.schedule.findUniqueOrThrow({ where: { id: first.id } })).status, "CANCELLED");
  });

  test("unscheduled list: only the courses with no length", async () => {
    const rows = await listUnscheduledCourses(prisma);
    assert.deepEqual(rows.map((r) => r.slug).sort(), ["grant-writing-proposal-development", "occupational-health-safety"]);
    assert.ok(rows.every((r) => r.reason === "No course length selected"));
  });
});

describe("public reads", () => {
  test("categories, search, course detail (prices, outline, FAQs, 78 schedules)", async () => {
    const published = await prisma.course.count({ where: { status: "PUBLISHED" } });
    const cats = await repo.listCategories();
    assert.equal(cats.length, 6); assert.equal(cats.reduce((n, c) => n + c.courseCount, 0), published);
    assert.equal((await repo.getCategory("data-analytics"))?.name, "Data & Analytics");
    assert.deepEqual((await repo.listCourses({ q: "EXCEL" })).map((c) => c.slug), ["data-analysis-excel-power-bi"]);
    const pm = (await repo.listCourses({ categorySlug: "project-management" })).map((c) => c.slug);
    assert.ok(pm.includes("pmp-prep") && pm.includes("ms-project-planning") && !pm.includes("ifrs-financial-reporting"));
    const c = (await repo.getCourse("pmp-prep"))!;
    assert.deepEqual([c.lengths.length, c.outline.length, c.faqs.length, c.schedules.length], [2, 4, 4, 78]);
    assert.deepEqual(c.prices.FIVE_DAY, { KES: 85000, USD: 650 });
    assert.deepEqual(c.priceFrom, { KES: 85000, USD: 650 });
    assert.ok(c.schedules.every((s, i, a) => !i || a[i - 1].startDate <= s.startDate), "sorted by date");
    assert.equal(await repo.getCourse("nope"), null);
  });

  test("home page data", async () => {
    const h = await repo.getHomeData();
    assert.deepEqual([h.totals.courses, h.totals.categories, h.totals.centers, h.upcoming.length], [await prisma.course.count({ where: { status: "PUBLISHED" } }), 6, 9, 8]);
    assert.ok(h.upcoming.every((u, i, a) => !i || a[i - 1].startDate <= u.startDate));
  });

  test("cancelled dates and draft courses disappear from the public site", async () => {
    const c = (await repo.getCourse("pmp-prep"))!;
    await repo.setScheduleStatus(c.schedules[0].id, "CANCELLED");
    assert.equal((await repo.getCourse("pmp-prep"))!.schedules.length, 77);
    await repo.setScheduleStatus(c.schedules[0].id, "OPEN");
    assert.equal((await repo.getCourse("pmp-prep"))!.schedules.length, 78);
    await newCourse("hidden-draft", { status: "DRAFT" });
    assert.equal(await repo.getCourse("hidden-draft"), null);
    assert.ok(!(await repo.listCourses()).some((x) => x.slug === "hidden-draft"));
  });
});

describe("admin editing", () => {
  test("creating a published course generates 52 schedules; adding 10-day adds 26; fees, outline and image are stored", async () => {
    const r = await newCourse("edit-flow", { prices: { FIVE_DAY: { KES: 50000, USD: 380 } }, outline: [{ title: "M1", body: "b1" }, { title: "M2" }], imageUrl: "https://cdn.example.org/a.jpg" });
    assert.equal(await upcoming(r.id, "FIVE_DAY"), 52);
    const dto = (await repo.getCourseForEdit(r.id))!;
    assert.deepEqual([dto.outline.length, dto.prices.FIVE_DAY?.KES, dto.imageUrl], [2, 50000, "https://cdn.example.org/a.jpg"]);
    await repo.saveCourse({ ...dto, lengths: ["FIVE_DAY", "TEN_DAY"], outline: [{ title: "Only one" }], prices: { FIVE_DAY: { KES: 55000 } } });
    assert.equal(await upcoming(r.id, "TEN_DAY"), 26);
    const after = (await repo.getCourseForEdit(r.id))!;
    assert.deepEqual([after.outline.length, after.prices.FIVE_DAY, after.prices.TEN_DAY], [1, { KES: 55000 }, undefined], "outline replaced; blank USD fee removed");
  });

  test("dropping a length hides its dates publicly without deleting history; archived courses get no new schedules", async () => {
    const id = await courseId("edit-flow");
    const dto = (await repo.getCourseForEdit(id))!;
    await repo.saveCourse({ ...dto, lengths: ["TEN_DAY"] });
    const pub = (await repo.getCourse("edit-flow"))!;
    assert.ok(pub.schedules.every((s) => s.length === "TEN_DAY"));
    assert.equal(await prisma.schedule.count({ where: { courseId: id, length: "FIVE_DAY" } }), 52, "old rows kept");
    await newCourse("archived-one", { status: "ARCHIVED" }).then(async (a) => assert.equal(await prisma.schedule.count({ where: { courseId: a.id } }), 0));
  });

  test("duplicate address and unknown category are refused with field errors", async () => {
    const [cat] = await repo.listCategoryOptions();
    const dup = await repo.saveCourse({ name: "x", slug: "pmp-prep", categoryId: cat.id, description: "d".repeat(30), lengths: [], deliveryModes: [], autoSchedule: true, status: "DRAFT", outline: [], prices: {} });
    assert.ok(!dup.ok && dup.fieldErrors?.slug);
    const bad = await repo.saveCourse({ name: "x", slug: "zzz", categoryId: "nope", description: "d".repeat(30), lengths: [], deliveryModes: [], autoSchedule: true, status: "DRAFT", outline: [], prices: {} });
    assert.ok(!bad.ok && bad.fieldErrors?.categoryId);
  });

  test("categories: create, edit, duplicate; price manager", async () => {
    const c = await repo.saveCategory({ name: "Health", slug: "health", iconKey: "health", sortOrder: 3, status: "PUBLISHED" });
    assert.ok(c.ok); if (!c.ok) return;
    assert.ok(!(await repo.saveCategory({ name: "H2", slug: "health", sortOrder: 0, status: "DRAFT" })).ok);
    assert.equal((await repo.getCategoryForEdit(c.id))!.iconKey, "health");
    const id = await courseId("pmp-prep");
    await repo.setCoursePrices(id, { FIVE_DAY: { KES: 99000 }, TEN_DAY: { KES: 170000, USD: 1300 } });
    const rows = await repo.listPriceRows();
    assert.deepEqual(rows.find((r) => r.courseId === id)!.prices, { FIVE_DAY: { KES: 99000 }, TEN_DAY: { KES: 170000, USD: 1300 } });
  });
});

describe("manual schedules", () => {
  const monday = () => { const d = new Date(Date.now() + 500 * 86_400_000); d.setUTCDate(d.getUTCDate() + ((8 - d.getUTCDay()) % 7)); return iso(d); };
  test("only Monday starts in the future, once, for a length the course offers", async () => {
    const id = await courseId("ms-project-planning");
    const m = monday();
    assert.ok(!(await repo.addSchedule({ courseId: id, length: "FIVE_DAY", startDate: iso(day(-2)) })).ok);                // Saturday
    assert.ok(!(await repo.addSchedule({ courseId: id, length: "FIVE_DAY", startDate: "2020-01-06" })).ok);                // past Monday
    const notOffered = await repo.addSchedule({ courseId: id, length: "TEN_DAY", startDate: m });
    assert.ok(!notOffered.ok && /not offered/.test(notOffered.error));
    assert.ok((await repo.addSchedule({ courseId: id, length: "FIVE_DAY", startDate: m })).ok);
    const dup = await repo.addSchedule({ courseId: id, length: "FIVE_DAY", startDate: m });
    assert.ok(!dup.ok && /already exists/.test(dup.error));
    const row = (await repo.listSchedulesAdmin({ courseId: id, limit: 500 })).find((r) => r.startDate === m)!;
    assert.deepEqual([row.generated, row.status, row.endDate], [false, "OPEN", iso(new Date(new Date(`${m}T00:00:00Z`).getTime() + 4 * 86_400_000))]);
  });
});

describe("leads, registrations, dashboard", () => {
  test("brochure lead → downloads counted → searchable", async () => {
    const r = await repo.createLead({ courseSlug: "pmp-prep", fullName: "Amina Wanjiru", email: "amina@example.com", phone: "0712", company: "Acme", ipHash: "h" });
    assert.ok(r.ok); if (!r.ok) return;
    await repo.recordBrochureDownload(r.leadId); await repo.recordBrochureDownload(r.leadId);
    const l = (await repo.listLeads({ q: "amina", limit: 10 }))[0];
    assert.deepEqual([l.name, l.downloadCount, l.course, l.company], ["Amina Wanjiru", 2, "Project Management Professional (PMP) Prep", "Acme"]);
    assert.ok(!(await repo.createLead({ courseSlug: "nope", fullName: "x", email: "x@x.co" })).ok);
  });

  test("registration: student upserted, centre and dates kept, double booking refused, bad date refused", async () => {
    const c = (await repo.getCourse("pmp-prep"))!, centre = (await repo.listCenters())[0];
    const input = { courseSlug: "pmp-prep", scheduleId: c.schedules[0].id, firstName: "Amina", lastName: "Wanjiru", email: "amina@example.com", phone: "0712345678", deliveryMode: "CLASSROOM" as const, centerId: centre.id, participants: 2, needsAccommodation: true, needsAirportPickup: false };
    const r = await repo.createRegistration(input);
    assert.ok(r.ok); if (!r.ok) return;
    assert.deepEqual([r.summary.centerName, r.summary.startDate, r.summary.participants], [centre.name, c.schedules[0].startDate, 2]);
    const again = await repo.createRegistration(input); assert.ok(!again.ok && /already registered/.test(again.error));
    assert.ok(!(await repo.createRegistration({ ...input, scheduleId: "nope" })).ok);
    const s = (await repo.listStudents({ q: "amina", limit: 5 }))[0];
    assert.deepEqual([s.registrations.length, s.registrations[0].center, s.registrations[0].status], [1, centre.name, "PENDING"]);
    assert.equal(await prisma.student.count({ where: { email: "amina@example.com" } }), 1);
  });

  test("dashboard counts reflect the above", async () => {
    const d = await repo.getDashboardStats();
    assert.deepEqual([d.students, d.registrations, d.brochureDownloads, d.publishedCourses], [1, 1, 1, await prisma.course.count({ where: { status: "PUBLISHED" } })]);
    assert.equal(d.recentRegistrations[0].student, "Amina Wanjiru");
  });
});

describe("blog", () => {
  const admin = async () => { const u = await prisma.staffUser.findUniqueOrThrow({ where: { email: "admin@example.com" } }); return { id: u.id, name: u.name }; };
  const post = (slug: string, extra = {}) => ({ title: `Post ${slug}`, slug, body: "Body text. ".repeat(40), format: "MARKDOWN" as const, tags: ["alpha"], status: "DRAFT" as const, ...extra });

  test("drafts hidden; publish makes visible with author; preview shows drafts; schedule hides until its time", async () => {
    const a = await admin();
    const d = await repo.savePost(post("draft-one"), a); assert.ok(d.ok); if (!d.ok) return;
    assert.equal(await repo.getPost("draft-one"), null);
    assert.equal((await repo.getPostPreview(d.id))?.title, "Post draft-one");
    await repo.savePost({ ...post("draft-one"), id: d.id, status: "PUBLISHED", publishedAt: new Date().toISOString() }, a);
    assert.equal((await repo.getPost("draft-one"))?.author, "Preview Admin");
    const s = await repo.savePost(post("later", { status: "PUBLISHED", publishedAt: day(30, new Date()).toISOString() }), a); assert.ok(s.ok);
    assert.equal(await repo.getPost("later"), null);
    assert.ok((await repo.adminListPosts({ limit: 50 })).find((p) => p.slug === "later")!.scheduled);
    assert.ok(!(await repo.listPostSlugs()).some((p) => p.slug === "later"));
  });

  test("tags, pagination, related, duplicate address, exact publish time preserved", async () => {
    const a = await admin();
    const t = await repo.listPostTags(); assert.ok(t.length > 5 && t.every((x, i) => !i || t[i - 1].count >= x.count));
    const p1 = await repo.listPosts({ page: 1, pageSize: 9 }), p2 = await repo.listPosts({ page: 2, pageSize: 9 });
    assert.deepEqual([p1.posts.length, p2.posts.length, p1.total], [9, 3, 12]);
    assert.equal((await repo.listPosts({ page: 1, pageSize: 9, tag: "alpha" })).total, 1);
    const detail = (await repo.getPost("draft-one"))!; assert.ok(detail.related.length <= 3 && !detail.related.some((r) => r.slug === "draft-one"));
    const dup = await repo.savePost(post("draft-one"), a); assert.ok(!dup.ok && dup.fieldErrors?.slug);
    const exact = "2026-10-12T07:00:42.123Z";
    const e = await repo.savePost(post("exact-time", { status: "PUBLISHED", publishedAt: exact }), a); assert.ok(e.ok); if (!e.ok) return;
    assert.equal((await repo.getPostForEdit(e.id))!.publishedAt, exact);
  });
});

describe("redirects", () => {
  test("old URLs match with or without a trailing slash", async () => {
    await prisma.redirect.create({ data: { fromPath: "/course/pmp-prep", toPath: "/courses/pmp-prep" } });
    for (const p of ["/course/pmp-prep", "/course/pmp-prep/"]) assert.equal(await repo.findRedirect(p), "/courses/pmp-prep");
    assert.equal(await repo.findRedirect("/nothing"), null);
  });
});

describe("email system on PostgreSQL", () => {
  const mk = () => { const m = mailer(); return { m, svc: createEmailService({ store: emails, repo, mailer: m, notifyTo: "staff@org.test" }) }; };

  test("brochure: queued → leased → sent with the PDF attached; follow-up scheduled for day 3", async () => {
    const { m, svc } = mk();
    const ids = await svc.captureLead({ leadId: "L1", email: "Peter@Example.com", name: "Peter Kamau", courseSlug: "pmp-prep", courseName: "PMP" }, T0);
    for (const id of ids) assert.equal(await svc.deliverMessage(id, T0), "sent");
    const b = m.sent.find((x) => x.to === "peter@example.com")!;
    assert.match(b.subject, /Your brochure/); assert.equal((b.attachments as unknown[]).length, 1);
    const fu = await prisma.followUp.findFirstOrThrow({ where: { email: "peter@example.com" } });
    assert.deepEqual([fu.status, fu.source, fu.nextSendAt?.toISOString()], ["ACTIVE", "BROCHURE", day(3).toISOString()]);
    assert.equal((await prisma.emailMessage.findFirstOrThrow({ where: { toEmail: "peter@example.com" } })).status, "SENT");
  });

  test("six workers racing to send one message: exactly one wins the lease", async () => {
    const id = await emails.enqueueMessage({ toEmail: "race@example.com", template: "staff-notification", context: { kind: "brochure", name: "R", email: "r@x.co", courseName: "C" } });
    const claims = await Promise.all(Array.from({ length: 6 }, () => emails.claimMessage(id, T0, 3)));
    assert.equal(claims.filter(Boolean).length, 1);
  });

  test("full cadence on a real database: d3, d7, d14, +2m, +3m, monthly", async () => {
    const { svc } = mk();
    await svc.captureLead({ leadId: "L2", email: "cadence@example.com", name: "Cadence", courseSlug: "pmp-prep", courseName: "PMP" }, T0);
    const mine = () => prisma.emailMessage.count({ where: { toEmail: "cadence@example.com", template: "followup" } });
    const run = async (when: Date) => { const b = await mine(); await svc.runFollowUps(when); await svc.deliverQueued(new Date(when.getTime() + 60_000), 100); return (await mine()) - b; };
    assert.equal(await run(day(2)), 0);
    assert.equal(await run(day(3)), 1);
    assert.equal(await run(day(7)), 1);
    assert.equal(await run(day(14)), 1);
    assert.equal(await run(new Date("2026-12-14T07:00:00Z")), 1);
    assert.equal(await run(new Date("2027-01-12T07:00:00Z")), 1);
    assert.equal(await run(new Date("2027-02-12T07:00:00Z")), 1);
    const stages = (await prisma.emailMessage.findMany({ where: { toEmail: "cadence@example.com", template: "followup" } })).map((m) => m.stage).sort();
    assert.deepEqual(stages, [1, 2, 3, 4, 5, 6]);
  });

  test("two job runs at the same instant enqueue a stage once (atomic update)", async () => {
    const { svc } = mk();
    await svc.captureLead({ leadId: "L3", email: "twice@example.com", name: "Twice", courseSlug: "pmp-prep", courseName: "PMP" }, T0);
    const r = await Promise.all([svc.runFollowUps(day(3)), svc.runFollowUps(day(3)), svc.runFollowUps(day(3))]);
    assert.equal(await prisma.emailMessage.count({ where: { toEmail: "twice@example.com", template: "followup" } }), 1);
    assert.ok(r.reduce((n, x) => n + x.enqueued, 0) >= 1);
  });

  test("webhooks: delivered, duplicate ignored, opened, unmatched; a permanent bounce suppresses and stops sequences", async () => {
    const { svc } = mk();
    const [id] = await svc.captureLead({ leadId: "L4", email: "bounce@example.com", name: "Bounce", courseSlug: "pmp-prep", courseName: "PMP" }, T0);
    await svc.deliverMessage(id, T0);
    const pid = (await prisma.emailMessage.findUniqueOrThrow({ where: { id } })).providerId!;
    const ev = (n: string, type: "DELIVERED" | "OPENED" | "BOUNCED", extra = {}) => ({ providerEventId: n, providerMessageId: pid, type, occurredAt: new Date(), ...extra });
    assert.equal(await emails.applyEvent(ev("w1", "DELIVERED")), "applied");
    assert.equal(await emails.applyEvent(ev("w1", "DELIVERED")), "duplicate");
    assert.equal(await emails.applyEvent(ev("w2", "OPENED")), "applied");
    assert.equal(await emails.applyEvent({ ...ev("w3", "OPENED"), providerMessageId: "unknown" }), "unmatched");
    let m = await prisma.emailMessage.findUniqueOrThrow({ where: { id } });
    assert.ok(m.status === "DELIVERED" && m.deliveredAt && m.firstOpenedAt);
    await emails.applyEvent(ev("w4", "BOUNCED", { bounceType: "Transient" }));
    assert.equal(await prisma.emailSuppression.count({ where: { email: "bounce@example.com" } }), 0);
    await emails.applyEvent(ev("w5", "BOUNCED", { bounceType: "Permanent" }));
    await emails.applyEvent(ev("w6", "DELIVERED"));
    m = await prisma.emailMessage.findUniqueOrThrow({ where: { id } });
    assert.equal(m.status, "BOUNCED");
    assert.equal((await prisma.emailSuppression.findUniqueOrThrow({ where: { email: "bounce@example.com" } })).reason, "HARD_BOUNCE");
    assert.equal((await prisma.followUp.findFirstOrThrow({ where: { email: "bounce@example.com" } })).status, "SUPPRESSED");
    assert.equal(await prisma.emailEvent.count({ where: { messageId: id } }), 5, "duplicate webhook did not double count");
    const [id2] = await svc.captureLead({ leadId: "L5", email: "bounce@example.com", name: "Bounce", courseSlug: "pmp-prep", courseName: "PMP" }, T0);
    assert.equal(await svc.deliverMessage(id2, T0), "suppressed");
  });

  test("unsubscribe by token stops every sequence for the address", async () => {
    const { svc } = mk();
    await svc.captureLead({ leadId: "L6", email: "bye@example.com", name: "Bye", courseSlug: "pmp-prep", courseName: "PMP" }, T0);
    await svc.captureLead({ leadId: "L7", email: "bye@example.com", name: "Bye", courseSlug: "ifrs-financial-reporting", courseName: "IFRS" }, T0);
    const fu = await prisma.followUp.findFirstOrThrow({ where: { email: "bye@example.com" } });
    assert.deepEqual(await emails.unsubscribeByToken(fu.unsubscribeToken), { email: "bye@example.com" });
    assert.equal(await prisma.followUp.count({ where: { email: "bye@example.com", status: "UNSUBSCRIBED" } }), 2);
    assert.equal(await emails.unsubscribeByToken("nope"), null);
    assert.equal(await emails.isSuppressed("bye@example.com", "marketing"), true);
    assert.equal(await emails.isSuppressed("bye@example.com", "transactional"), false);
  });

  test("registration confirmation ends the brochure sequence for that course", async () => {
    const { svc } = mk();
    await svc.captureLead({ leadId: "L8", email: "conv@example.com", name: "Conv", courseSlug: "pmp-prep", courseName: "PMP" }, T0);
    await svc.captureRegistration({ email: "conv@example.com", name: "Conv", courseSlug: "pmp-prep", courseName: "PMP", startDate: "2026-10-19", endDate: "2026-10-23", length: "FIVE_DAY", deliveryMode: "ONLINE", participants: 1 }, T0);
    const f = await prisma.followUp.findMany({ where: { email: "conv@example.com" } });
    assert.deepEqual(f.map((x) => `${x.source}:${x.status}`).sort(), ["BROCHURE:CONVERTED", "REGISTRATION:ACTIVE"]);
  });

  test("stats summarise real rows", async () => {
    const s = await emails.stats();
    assert.ok(s.total > 10 && s.byStatus.SENT + s.byStatus.DELIVERED + s.byStatus.BOUNCED > 0 && s.followUps.active > 0 && s.suppressed >= 2 && s.opened >= 1);
  });
});

describe("staff accounts on PostgreSQL", () => {
  test("lockout after 5 failures; success clears it", async () => {
    const u = (await staff.findByEmail("marketing@example.com"))!;
    for (let i = 0; i < 5; i++) await staff.recordFailedLogin(u.id, 5, 15 * 60_000);
    const locked = (await staff.findById(u.id))!;
    assert.ok(locked.lockedUntil && locked.lockedUntil.getTime() > Date.now()); assert.equal(locked.failedLogins, 0);
    await staff.recordSuccessfulLogin(u.id);
    assert.equal((await staff.findById(u.id))!.lockedUntil, null);
  });

  test("a 2FA code can be used once, even when 8 requests race", async () => {
    const u = (await staff.findByEmail("editor@example.com"))!;
    const results = await Promise.all(Array.from({ length: 8 }, () => staff.consumeTotpStep(u.id, 1000)));
    assert.equal(results.filter(Boolean).length, 1);
    assert.equal(await staff.consumeTotpStep(u.id, 1000), false); assert.equal(await staff.consumeTotpStep(u.id, 999), false);
    assert.equal(await staff.consumeTotpStep(u.id, 1001), true);
  });

  test("password change bumps the session version; enabling 2FA; audit rows", async () => {
    const u = (await staff.findByEmail("editor@example.com"))!;
    assert.equal(await staff.setPassword(u.id, "hash1"), 1); assert.equal(await staff.setPassword(u.id, "hash2"), 2);
    await staff.enableTotp(u.id, "v1.enc"); assert.ok((await staff.findById(u.id))!.totpEnabled);
    await staff.audit({ actorId: u.id, action: "test.action", entity: "x", meta: { a: 1 } });
    const row = await prisma.auditLog.findFirstOrThrow({ where: { action: "test.action" } });
    assert.deepEqual([row.actorId, row.entity, row.diff], [u.id, "x", { a: 1 }]);
  });
});

describe("AI FAQs on PostgreSQL", () => {
  const ANS = "This course suits managers and officers who need practical skills they can apply straight away. It combines short expert input with hands-on exercises and case studies.";
  const Q = ["Who should attend this course?", "What will I learn on this course?", "Do I need prior experience to join?", "How is the course delivered to participants?", "Will I receive a certificate at the end?", "How can this course help my career?"];
  let mode: "ok" | "throw" = "ok";
  const llm = async () => { if (mode === "throw") throw new Error("OpenAI 500"); return { faqs: [...Q.map((question) => ({ question, answer: ANS })), { question: "How much does it cost to attend?", answer: `${ANS} The fee is KES 85,000.` }], model: "fake" }; };
  const svc = createFaqService({ repo, llm });

  test("new course needs FAQs → drafts (price answer dropped) → approve one / approve all → public; counts and run log", async () => {
    const c = await newCourse("faq-flow");
    assert.ok((await svc.needing()).some((x) => x.id === c.id));
    assert.deepEqual(await svc.generateForCourse(c.id), { status: "generated", count: 6, rejected: 1 });
    assert.equal((await repo.getCourse("faq-flow"))!.faqs.length, 0);
    const drafts = await repo.listFaqsAdmin({ status: "DRAFT", courseId: c.id, limit: 50 });
    assert.equal(drafts.length, 6); assert.ok(drafts.every((d) => d.aiGenerated && d.model === "fake"));
    assert.ok((await repo.updateFaq(drafts[0].id, { answer: "Edited " + ANS, status: "PUBLISHED" })).ok);
    assert.equal((await repo.getCourse("faq-flow"))!.faqs.length, 1);
    const all = await repo.setCourseFaqsStatus(c.id, "DRAFT", "PUBLISHED"); assert.equal((all as { count: number }).count, 5);
    assert.equal((await repo.getCourse("faq-flow"))!.faqs.length, 6);
    assert.equal((await svc.generateForCourse(c.id)).status, "skipped");
    assert.ok(!(await svc.needing()).some((x) => x.id === c.id));
    const run = await prisma.faqGenerationRun.findFirstOrThrow({ where: { courseId: c.id } });
    assert.deepEqual([run.status, run.model, run.promptTokens === null], ["SUCCESS", "fake", true]);
    const n = await repo.faqCounts(); assert.ok(n.published >= 62 && n.draft === 0);
  });

  test("a course whose provider keeps failing stops being retried after 3 failures in 24 h (SQL filtered count)", async () => {
    const c = await newCourse("faq-flaky"); mode = "throw";
    for (let i = 0; i < 3; i++) assert.equal((await svc.generateForCourse(c.id)).status, "failed");
    mode = "ok";
    assert.ok(!(await svc.needing()).some((x) => x.id === c.id));
    assert.equal(await prisma.faqGenerationRun.count({ where: { courseId: c.id, status: "FAILED" } }), 3);
  });

  test("editing course text makes it need FAQs again; a price edit does not", async () => {
    const id = await courseId("faq-flow"), dto = (await repo.getCourseForEdit(id))!;
    await repo.saveCourse({ ...dto, prices: { FIVE_DAY: { KES: 1 } } });
    assert.ok(!(await svc.needing()).some((x) => x.id === id));
    await repo.saveCourse({ ...dto, description: "Completely reworded description of this course for the test." });
    assert.ok((await svc.needing()).some((x) => x.id === id));
  });
});

describe("importing the old database (into an empty database)", () => {
  const plan = () => buildPlan(fixture(), legacyOpts);

  test("loads every entity; idempotent when run again", async () => {
    await reset();
    await loadPlan(prisma, plan(), () => {});
    const counts = async () => Object.fromEntries(await Promise.all((["category", "course", "courseOutlineItem", "coursePrice", "courseFaq", "schedule", "student", "registration", "lead", "followUp", "emailSuppression", "blogPost", "page", "redirect", "center"] as const).map(async (m) => [m, await (prisma[m] as unknown as { count(): Promise<number> }).count()])));
    const c1 = await counts();
    assert.deepEqual(c1, { category: 2, course: 3, courseOutlineItem: 2, coursePrice: 3, courseFaq: 1, schedule: 3, student: 2, registration: 3, lead: 2, followUp: 3, emailSuppression: 1, blogPost: 2, page: 1, redirect: 7, center: 1 });
    await loadPlan(prisma, plan(), () => {});
    assert.deepEqual(await counts(), c1, "second run created nothing");
  });

  test("details: opt-out stored, old tokens kept, off-rule history flagged, HTML posts, Uncategorised, no scripts", async () => {
    assert.equal((await prisma.emailSuppression.findUniqueOrThrow({ where: { email: "gone@example.com" } })).reason, "UNSUBSCRIBED");
    const f = await prisma.followUp.findMany({ orderBy: { email: "asc" } });
    assert.ok(f.some((x) => x.unsubscribeToken === "tok1" && x.lastSentStage === 2 && x.status === "ACTIVE"));
    assert.deepEqual(f.find((x) => x.email === "gone@example.com")!.status, "UNSUBSCRIBED");
    const s = await prisma.schedule.findMany({ orderBy: { startDate: "asc" } });
    assert.deepEqual(s.map((x) => [iso(x.startDate), x.isLegacy]), [["2026-09-26", true], ["2026-10-12", false], ["2026-12-07", false]]);
    assert.ok((await prisma.blogPost.findMany()).every((p) => p.format === "HTML" && !/script/i.test(p.body)));
    const cat = await prisma.category.findUniqueOrThrow({ where: { slug: "uncategorised" } });
    assert.equal((await prisma.course.findUniqueOrThrow({ where: { legacyId: 11 } })).categoryId, cat.id);
    assert.equal((await prisma.registration.findMany({ where: { status: "CANCELLED" } })).length, 1);
    assert.equal((await prisma.registration.findFirstOrThrow({ where: { student: { email: "amina@example.com" } } })).needsAccommodation, true);
  });

  test("old URLs redirect; then the engine fills the grid AROUND the imported Monday in December (no gap, no duplicate)", async () => {
    const repoRedirect = await repo.findRedirect("/course/pmp-prep");
    assert.equal(repoRedirect, "/courses/pmp-prep");
    const id = await courseId("pmp-prep");
    const r = await ensureCourseSchedules(prisma, id);
    assert.equal(r.created.FIVE_DAY, 51, "52 open in total, counting the imported December schedule");
    assert.equal(await upcoming(id, "FIVE_DAY"), 52);
    const dec = await prisma.schedule.findMany({ where: { courseId: id, startDate: new Date("2026-12-07") } });
    assert.equal(dec.length, 1);
    const first = await prisma.schedule.findFirstOrThrow({ where: { courseId: id, startDate: { gte: new Date() }, generated: true }, orderBy: { startDate: "asc" } });
    assert.ok(first.startDate.getTime() - Date.now() < 8 * 86_400_000, "the grid starts at the next Monday, not after December");
    assert.deepEqual((await repo.getCourse("pmp-prep"))!.schedules.length, 52);
  });
});
