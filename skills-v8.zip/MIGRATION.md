# Moving the old Skills for Africa data across

Do this on a **copy**/staging database first. The importer only READS the old MySQL database and never overwrites
anything already in the new one, so it is safe to re-run.

## 1. Prepare
    cp .env.example .env     # set DATABASE_URL (new Postgres) and OLD_DATABASE_URL=mysql://user:pass@host:3306/skills_connect
    npx prisma migrate deploy      # tables + the Monday–Friday rules

## 2. Dry run (writes nothing; produces import-report.json)
    npx tsx scripts/import-legacy.ts --student-type=-1

Read the **code distributions** at the bottom. The old `usertypes` table is empty so I could not tell which
`users.userType` means "student" – find the value with the most people (e.g. 3) and use it as `--student-type`.
Same for `courseapplications.status`: decide what each number means.

## 3. Real dry run with the right codes
    npx tsx scripts/import-legacy.ts --student-type=3 --status-map=1:CONFIRMED,2:CANCELLED \
      --media-base=https://OLD-SITE/uploads/ \
      --course-path=/course/ --category-path=/faculty/ --blog-path=/news/

Open `import-report.json`. Every "Things that need a human look" row is a decision, not an error:
| kind | what it means | what to do |
|---|---|---|
| course_no_category | course pointed at a category that no longer exists | it was put in "Uncategorised" (draft); move it |
| course_unmappable_duration | duration isn't 5 or 10 days / 1 or 2 weeks | set its length on the course page; until then it is under *Unscheduled* |
| course_needs_price | a length with no known price | enter it under *Manage prices* |
| course_duplicate_slug | two courses had the same URL | the second got `-2`; old URL still works only if you pass the matching --course-path |
| schedule_not_weekday | an old schedule starting on a weekend / not a Mon–Fri week | kept **only** because someone registered for it, tagged OLD SYSTEM |
| registration_orphan_schedule | an application pointing at a schedule that no longer exists | skipped; check the list |
| student_bad_email / student_duplicate_email | unusable or repeated emails | bad ones skipped; duplicates merged into one student |

## 4. Apply
    npx tsx scripts/import-legacy.ts --student-type=3 --status-map=… --media-base=… --course-path=… --commit

## What is and isn't carried over
- Carried: categories, courses (text converted from HTML to clean paragraphs), outlines, prices, group rates, FAQs, centres,
  students, registrations (merged from 3 tables, de-duplicated), brochure leads (merged from 3 tables), live follow-up
  sequences (resumed no sooner than tomorrow – nobody gets a burst), blog posts and pages (HTML sanitised),
  301 redirects from the old URLs.
- **Unsubscribes are imported first** and become a suppression list: those people are never emailed.
- Not carried: staff/trainer accounts (they set up new secure logins), the old email send logs, analytics tables,
  every *future* schedule (the nightly job regenerates a clean Monday–Friday grid), images (add `--media-base`
  and they are linked from the old server; move them to file storage later).
- After importing, run the app once: the nightly job (or "Generate schedules" on the Unscheduled page) creates the
  52 / 26 schedules for every course that has a length.

## Tested how
The transform has 13 unit tests; the dry run was verified end to end against a real MariaDB loaded from `skills_connect.sql`,
with every column name checked against that file; and the write step (`--commit`) is covered by an integration test against a real
PostgreSQL (idempotent re-run, opt-outs first, off-rule history kept, redirects, schedule grid filled around imported dates).
Still run it on a staging copy of YOUR data first: the real data will contain surprises the fixture cannot.
