-- Run after `prisma migrate dev`. Guarantees no schedule created by this application can ever start on a
-- non-Monday or end on a non-Friday, whichever code path writes the row (admin form, cron, import script).
-- Rows flagged "isLegacy" are historical records imported from the old system and are exempt.
ALTER TABLE "Schedule"
  ADD CONSTRAINT schedule_starts_monday  CHECK ("isLegacy" OR EXTRACT(ISODOW FROM "startDate") = 1),
  ADD CONSTRAINT schedule_ends_friday    CHECK ("isLegacy" OR EXTRACT(ISODOW FROM "endDate")   = 5),
  ADD CONSTRAINT schedule_length_matches CHECK ("isLegacy" OR (
    ("length" = 'FIVE_DAY' AND "endDate" - "startDate" = 4) OR
    ("length" = 'TEN_DAY'  AND "endDate" - "startDate" = 11)
  ));
