/**
 * One-off migration from the old MySQL database (CodeIgniter) into the new PostgreSQL database.
 *
 *   OLD_DATABASE_URL=mysql://user:pass@host:3306/skills_connect  DATABASE_URL=postgresql://…
 *   npx tsx scripts/import-legacy.ts --student-type=3                 # DRY RUN: writes import-report.json only
 *   npx tsx scripts/import-legacy.ts --student-type=3 --commit        # applies it
 *
 * Options:
 *   --student-type=N     users.userType meaning "student" (REQUIRED – see distribution in the dry-run report)
 *   --active-status=N    status value meaning live (default 1)
 *   --status-map=1:CONFIRMED,2:CANCELLED   courseapplications.status → registration status (default: all PENDING)
 *   --media-base=https://old-site.org/uploads/   where old image filenames can be fetched from
 *   --course-path=/course/ --category-path=/faculty/ --blog-path=/news/ --page-path=/   old URL prefixes → 301 redirects
 *
 * Safe to re-run: records are matched by their old id/unique keys and existing ones are never overwritten
 * (so edits made in the new admin are never lost). Never writes to the old database.
 */
import { writeFileSync } from "node:fs";
import { createPrismaClient } from "../src/lib/prisma-client";
import { loadPlan } from "../src/lib/legacy/load";
import mysql from "mysql2/promise";
import { buildPlan, type LegacyData, type Options } from "../src/lib/legacy/transform";

const arg = (n: string) => process.argv.find((a) => a.startsWith(`--${n}=`))?.split("=").slice(1).join("=");
const flag = (n: string) => process.argv.includes(`--${n}`);

const TABLES: (keyof LegacyData)[] = ["faculties", "courses", "courseoutlines", "groupcharges", "course_faqs", "centers", "courseschedules", "users", "courseapplications", "usersCourses", "usersCourses2", "brochure_requests", "download_leads", "pdf_downloads", "user_followups", "news", "pages"];

const REQUIRED: (keyof LegacyData)[] = ["faculties", "courses", "users", "courseschedules", "courseapplications"];

async function readLegacy(url: string): Promise<LegacyData> {
  const conn = await mysql.createConnection({ uri: url, dateStrings: true, multipleStatements: false });
  const data = {} as LegacyData;
  const sizes: Record<string, number | string> = {};
  try {
    for (const t of TABLES) {
      try { [data[t]] = (await conn.query(`SELECT * FROM \`${t}\``)) as unknown as [Record<string, unknown>[]]; sizes[t] = data[t].length; }
      catch (e) {
        // A missing core table means wrong database/permissions: stop rather than "successfully" import nothing.
        if (REQUIRED.includes(t)) throw new Error(`Cannot read required table "${t}": ${(e as Error).message}`);
        data[t] = []; sizes[t] = "MISSING (skipped)";
      }
    }
  } finally { await conn.end(); }
  console.log("Rows read from the old database:"); console.table(sizes);
  if (!data.courses.length) throw new Error("The old database has no courses – refusing to continue. Is OLD_DATABASE_URL pointing at the right database?");
  return data;
}

async function main() {
  const studentType = Number(arg("student-type"));
  if (!Number.isInteger(studentType)) throw new Error("--student-type=N is required. Run once without it against a copy to see users.userType values in a dry run (use --student-type=-1).");
  const statusMap: Options["statusMap"] = {};
  for (const pair of (arg("status-map") ?? "").split(",").filter(Boolean)) { const [k, v] = pair.split(":"); statusMap[Number(k)] = v as "PENDING"; }
  const opts: Options = {
    studentUserType: studentType, activeStatus: Number(arg("active-status") ?? 1), statusMap, mediaBase: arg("media-base"), now: new Date(),
    legacyPaths: { course: arg("course-path"), category: arg("category-path"), blog: arg("blog-path"), page: arg("page-path") },
  };
  const url = process.env.OLD_DATABASE_URL;
  if (!url) throw new Error("Set OLD_DATABASE_URL=mysql://user:pass@host:3306/skills_connect");

  console.log("Reading the old database (read-only)…");
  const plan = buildPlan(await readLegacy(url), opts);
  writeFileSync("import-report.json", JSON.stringify(plan.report, null, 2));
  console.log("\nWhat will be imported:"); console.table(plan.report.counts);
  const byKind = plan.report.anomalies.reduce<Record<string, number>>((m, a) => { m[a.kind] = (m[a.kind] ?? 0) + 1; return m; }, {});
  console.log("Things that need a human look:"); console.table(byKind);
  console.log("Code distributions (confirm --student-type / --status-map are right):"); console.log(JSON.stringify(plan.report.distributions, null, 2));
  console.log("\nFull detail written to import-report.json");
  if (!flag("commit")) return console.log("\nDRY RUN – nothing was written. Add --commit to apply.");
  if (!process.env.DATABASE_URL) throw new Error("DATABASE_URL (the NEW database) is required with --commit");
  const db = createPrismaClient();
  try { await loadPlan(db, plan); console.log("\nNext: start the app – the nightly job will create the 52/26 weekday schedules for every course with a length."); }
  finally { await db.$disconnect(); }
}

main().catch((e) => { console.error("\nImport failed:", e.message ?? e); process.exitCode = 1; });
