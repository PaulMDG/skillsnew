/**
 * Create the first staff account, or recover one.
 *
 *   npx tsx scripts/create-admin.ts create  you@org.org "Your Name" ADMIN
 *   npx tsx scripts/create-admin.ts reset-password you@org.org
 *   npx tsx scripts/create-admin.ts reset-2fa       you@org.org     (forces re-enrolment at next login)
 *   npx tsx scripts/create-admin.ts deactivate      you@org.org
 *
 * Needs DATABASE_URL. A strong random password is generated and printed ONCE (or set NEW_PASSWORD).
 */
import { randomBytes } from "node:crypto";
import { createPrismaClient } from "../src/lib/prisma-client";
import { hashPassword, validateNewPassword } from "../src/lib/auth/password";

const prisma = createPrismaClient();
const [cmd, emailArg, name, roleArg] = process.argv.slice(2);
const email = emailArg?.trim().toLowerCase();

const genPassword = () => randomBytes(18).toString("base64url");

async function main() {
  if (!cmd || !email) throw new Error("Usage: create-admin.ts <create|reset-password|reset-2fa|deactivate> <email> [name] [ADMIN|EDITOR|MARKETING]");

  if (cmd === "create") {
    const role = (roleArg ?? "ADMIN").toUpperCase();
    if (!["ADMIN", "EDITOR", "MARKETING"].includes(role)) throw new Error("Role must be ADMIN, EDITOR or MARKETING");
    if (!name) throw new Error("Provide a display name");
    const pw = process.env.NEW_PASSWORD ?? genPassword();
    const problem = validateNewPassword(pw, email);
    if (problem) throw new Error(problem);
    await prisma.staffUser.create({ data: { email, name, role: role as "ADMIN", passwordHash: await hashPassword(pw) } });
    console.log(`Created ${role} ${email}\nTemporary password (shown once): ${pw}\nThey will be asked to set up 2FA at first sign-in.`);
  } else if (cmd === "reset-password") {
    const pw = process.env.NEW_PASSWORD ?? genPassword();
    await prisma.staffUser.update({ where: { email }, data: { passwordHash: await hashPassword(pw), passwordChangedAt: new Date(), sessionVersion: { increment: 1 }, failedLogins: 0, lockedUntil: null } });
    console.log(`Password reset for ${email}\nNew password (shown once): ${pw}\nAll existing sessions were signed out.`);
  } else if (cmd === "reset-2fa") {
    await prisma.staffUser.update({ where: { email }, data: { totpEnabled: false, totpSecret: null, totpLastStep: null, sessionVersion: { increment: 1 } } });
    console.log(`2FA cleared for ${email}. They must enrol again at next sign-in.`);
  } else if (cmd === "deactivate") {
    await prisma.staffUser.update({ where: { email }, data: { isActive: false, sessionVersion: { increment: 1 } } });
    console.log(`${email} deactivated and signed out everywhere.`);
  } else throw new Error(`Unknown command ${cmd}`);
}

main().catch((e) => { console.error(e.message ?? e); process.exitCode = 1; }).finally(() => prisma.$disconnect());
