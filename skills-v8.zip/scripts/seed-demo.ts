/**
 *   DATABASE_URL=postgresql://… npx tsx scripts/seed-demo.ts [--demo-staff] [--force]
 * Fills an EMPTY database with sample categories, courses, schedules, FAQs and blog posts.
 * --demo-staff also creates admin@/marketing@/editor@example.com (password = $DEMO_PASSWORD or "dev-password-123456") for testing ONLY.
 */
import { seedDemo } from "../src/lib/demo-seed";
import { prisma } from "../src/lib/db";

seedDemo({ demoStaff: process.argv.includes("--demo-staff"), force: process.argv.includes("--force"), log: (s) => console.log(`  ${s}`) })
  .then(() => console.log("Seeded."))
  .catch((e) => { console.error("Seed failed:", e.message ?? e); process.exitCode = 1; })
  .finally(() => prisma.$disconnect());
